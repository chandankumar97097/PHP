<?php 

	$con = mysqli_connect("localhost","root","Test_pw9","chandan_ecommerce");
	
?>
