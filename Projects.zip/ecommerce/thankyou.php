<?php 
session_start();

if(!(isset ($_SESSION['customer_email'])) && ($_SESSION["customer_pass"]=1)){
	header("location:index.php");
}

?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Online Shopping</title>
		<link rel="stylesheet" href="css/bootstrap.min.css"/>
		<link rel="stylesheet" type="text/css" href="css/style.css">
	</head>
<body>
		<div class="container-fluid">
			<div class="col-sm-2"></div>		
			<div class="col-sm-8">
				<a class="panel panel-primary">Thank You! <br>Your Order Has Been Placed!<br></a>
				<a href="order.php" class="btn-btn-primary btn">View Your Order</a>
			</div>
			<div class="col-sm-2"></div>
		</div>
<script src="js/bootstrap.min.js"></script>
</body>
</html>
















































