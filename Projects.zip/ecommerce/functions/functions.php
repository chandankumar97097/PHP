<?php 
// Global Connection
$db = mysqli_connect("localhost","root","","ecommerce");

	// function for getting the IP address
	function getRealIpAddr(){
		
		@$http_client_ip = $_SERVER['HTTP_CLIENT_IP'];
		@$http_forwarded_for = $_SERVER['HTTP_X_FORWARDED_FOR'];
		$remote_addr = $_SERVER['REMOTE_ADDR'];
		
		// check ip from internet
		if (!empty($http_client_ip)){
			$ipaddress = $http_client_ip;
		}
		// check ip is pass from proxy and VPN
		elseif (!empty($http_forwarded_for)){
			$ipaddress = $http_forwarded_for;
		}
		// Local Machine ip address
		else{
			$ipaddress = $remote_addr;
		}
		return $ipaddress;
	}
	
	// Getting categories to display on the page 
	function getCat(){
		global $db;
        
			$get_cats = "select * from categories";
			$run_cats = mysqli_query($db, $get_cats);
						
				while($row_cats = mysqli_fetch_array($run_cats)){
					$cat_id = $row_cats['cat_id'];
					$cat_title = $row_cats['cat_title'];
							
					echo "<li><a href='index.php?cat=$cat_id'>$cat_title</a></li>";
							
				}
				
	}
		
	
	//  Getting the products to home page
	function getPro(){
		global $db;
		
		if(!isset($_GET['cat'])){
		
			$get_products = "select * from products order by rand() LIMIT 8";
			$run_products = mysqli_query($db, $get_products);
							
				while($row_products = mysqli_fetch_array($run_products)){
					$product_id = $row_products['product_id'];
					$product_title = $row_products['product_title'];
					$product_img = $row_products['product_img'];
					$p_sign = $row_products['p_sign'];
					$product_price = $row_products['product_price'];
					$product_desc = $row_products['product_desc'];
								
					echo "
						<div class='col-md-3'>
							<div class='panel panel-info'>
								<div class='panel-heading'>$product_title</div>
									<a href='details.php?product_id=$product_id'>
										<div class='panel-body'>
											<img src='product_images/$product_img'/ class='pro_img'>
										</div>
										<div class='panel-heading'>$p_sign.$product_price
											<a href='details.php?product_id=$product_id' style='float:right;' class='btn btn-danger btn-xs'>Buy Now</a>
										</div>
									</a>
								</div>
							</div>
						";
								
				}
			
		}
	}
	
	// Getting the Category Products
	function getCatPro(){
		global $db;
		
		if(isset($_GET['cat'])){
			
			$cat_id = $_GET['cat'];
			
			$get_cat_products = "select * from products where cat_id='$cat_id'";
			$run_cat_pro = mysqli_query($db, $get_cat_products);
			
				while($row_cat_pro = mysqli_fetch_array($run_cat_pro)){
					$product_id = $row_cat_pro['product_id'];
					$product_title = $row_cat_pro['product_title'];
					$product_img = $row_cat_pro['product_img'];
					$p_sign = $row_cat_pro['p_sign'];
					$product_price = $row_cat_pro['product_price'];
					$product_desc = $row_cat_pro['product_desc'];
								
					echo "
						<div class='col-md-3'>
							<div class='panel panel-info'>
								<div class='panel-heading'>$product_title</div>
									<a href='details.php?product_id=$product_id'>
										<div class='panel-body'>
											<img src='product_images/$product_img'/ class='pro_img'>
										</div>
										<div class='panel-heading'>$p_sign.$product_price
											<a href='details.php?product_id=$product_id' style='float:right;' class='btn btn-danger btn-xs'>Buy Now</a>
										</div>
									</a>
								</div>
							</div>
						";
								
				}
			
		}
	}
	
	// Insert Product into cart
	function cart(){
		if(isset($_GET['add_cart'])){
			
			global $db; 
			
			$qty = 1;
			$p_id = $_GET['add_cart'];
			
			$customer_session = $_SESSION['customer_email'];
			$get_customer_id = "select * from customers where customer_email='$customer_session'";
			$run_customer = mysqli_query($db, $get_customer_id); 
			$row_customer = mysqli_fetch_array($run_customer); 
			$customer_id = $row_customer['customer_id'];
			$ip_add = getRealIpAddr();
			$check_pro = "select * from cart where ip_add='$ip_add' AND p_id='$p_id'";
			
			$run_check = mysqli_query($db,$check_pro); 
			
			if(mysqli_num_rows($run_check)>0){
				
				echo "<script>alert('This product already added in your cart!');</script>";
				
				}
				else {
					$q = "insert into cart (p_id,ip_add,customer_id,qty) values ('$p_id','$ip_add','$customer_id','$qty')";
					
					$run_q = mysqli_query($db,$q);
					
					echo "<script>window.open('index.php','_self')</script>";
					
					}
		
			}

	}
	
	
	// Getting the numbers of items from the cart
	function items(){
		global $db;
		@$customer_session = $_SESSION['customer_email'];
		$get_customer_id = "select * from customers where customer_email='$customer_session'";
		$run_customer = mysqli_query($db, $get_customer_id); 
		$row_customer = mysqli_fetch_array($run_customer); 
		$customer_id = $row_customer['customer_id']; 
		$ip_add = getRealIpAddr();
		
		if(isset($_GET['add_cart'])){
			global $db;
			$get_items = "select * from cart where ip_add='$ip_add' AND customer_id='$customer_id'";
			$run_items = mysqli_query($db, $get_items);
			$count_items = mysqli_num_rows($run_items);
		}else{
			global $db;
			$get_items = "select * from cart where ip_add='$ip_add' AND customer_id='$customer_id'";
			$run_items = mysqli_query($db, $get_items);
			$count_items = mysqli_num_rows($run_items);
		}
		echo "$count_items";
	}
	
	// Insert Product into wishlist
	function wishlist(){
		
		if(isset($_GET['add_wishlist'])){
			
			global $db; 
			
			$customer_session = $_SESSION['customer_email'];
			$get_customer_id = "select * from customers where customer_email='$customer_session'";
			$run_customer = mysqli_query($db, $get_customer_id); 
			$row_customer = mysqli_fetch_array($run_customer); 
			$customer_id = $row_customer['customer_id'];
			$qty = 1;
			$p_id = $_GET['add_wishlist'];
			$ip_add = getRealIpAddr();
			$check_pro = "select * from wishlist where ip_add='$ip_add' AND p_id='$p_id'";
			
			$run_check = mysqli_query($db,$check_pro); 
			
			if(mysqli_num_rows($run_check)>0){
				
				echo "<script>alert('This product already added in your wishlist!');</script>";
				
				}
				else {
					$q = "insert into wishlist (p_id,ip_add,customer_id,qty) values ('$p_id','$ip_add','$customer_id','$qty')";
					
					$run_q = mysqli_query($db,$q);
					
					echo "<script>window.open('index.php','_self')</script>";
					
					}
		
			}
	}
	
	
	// Getting the numbers of items from the wishlist
	function wishlistItems(){
		global $db; 
		$ip_add = getRealIpAddr();
		@$customer_session = $_SESSION['customer_email'];
		$get_customer_id = "select * from customers where customer_email='$customer_session'";
		$run_customer = mysqli_query($db, $get_customer_id); 
		$row_customer = mysqli_fetch_array($run_customer); 
		$customer_id = $row_customer['customer_id']; 
			
		if(isset($_GET['add_wishlist'])){
			global $db;
			$get_items = "select * from wishlist where ip_add='$ip_add' AND customer_id='$customer_id'";
			$run_items = mysqli_query($db, $get_items);
			$count_items = mysqli_num_rows($run_items);
		}else{
			global $db;
			$get_items = "select * from wishlist where ip_add='$ip_add' AND customer_id='$customer_id'";
			$run_items = mysqli_query($db, $get_items);
			$count_items = mysqli_num_rows($run_items);
		}
		echo "$count_items";
	}
	
	
	// Customer Registration
	if(isset($_POST['register'])){
		
		$customer_name = $_POST['customer_name'];
		$customer_email = $_POST['customer_email'];
		$customer_pass = md5($_POST['customer_pass']);
		$customer_confirm_pass = md5($_POST['customer_confirm_pass']);
		$customer_contact = $_POST['customer_contact'];
		$customer_address = $_POST['customer_address'];
		$customer_country = $_POST['customer_country'];
		$customer_city = $_POST['customer_city'];
		$customer_id = $_POST['customer_id'];
		$customer_ip = getRealIpAddr();
		$customer_image = $_FILES['customer_image']['name'];
		$customer_image_tmp = $_FILES['customer_image']['tmp_name'];
		
		$sel_customers = "select * from customers where customer_id='$customer_id'";
		$run_customers = mysqli_query($con, $sel_customers);
		$check_customers = mysqli_num_rows($run_customers);
		
		if($check_customers==1){
			echo "<script>alert('You Are Already Registered! Please Login')</script>";
			echo "<script>window.open('login.php', '_self')</script>";
		}else{
			if($customer_pass == $customer_confirm_pass){
			$insert_customer = "insert into customers (customer_name,customer_email,customer_pass,customer_contact,customer_address,customer_country,customer_city,customer_image,customer_id,customer_ip) values ('$customer_name','$customer_email','$customer_pass','$customer_contact','$customer_address','$customer_country','$customer_city','$customer_image','$customer_id','$customer_ip')";
		
			$run_customer = mysqli_query($con, $insert_customer);
		
			move_uploaded_file($customer_image_tmp, "customer/customer_photos/$customer_image");
			
			echo "<script>alert('You Are Successfully Registered!');</script>";
			echo "<script>window.open('login.php', '_self')</script>";
			
		}else{
			echo "<script>alert('Password and Confirm Password not Match');</script>";
		}
		}
	}
	
	// Change Password 
	if(isset($_POST['signup_button'])){
		$customer_email = $_POST['customer_email'];
        $customer_pass = md5($_POST['customer_pass']);
        $new_password = md5($_POST['new_password']);
        $confirm_password = md5($_POST['confirm_password']);
        $result = mysqli_query($db, "SELECT customer_pass FROM customers WHERE customer_email='$customer_email'");
        if(!$result)
        {
        echo "<script>alert('The email you entered does not exist')</script>";
        }
        elseif($customer_pass= 1)
        {
			echo "";
        }
        if($new_password==$confirm_password)
        $sql=mysqli_query($db,"UPDATE customers SET customer_pass='$new_password' where customer_email='$customer_email'");
        if($sql)
        {
        echo "<script>alert('Congratulations You have successfully changed your password')</script>";
		echo "<script>window.location.href='../login.php'</script>";
		session_destroy();
        }
		else
        {
		echo "<script>alert('The new password and confirm new password fields must be the same')</script>";
		echo "<script>window.location.href='change_password.php'</script>";
		}
	}	
	
	// Forget Password
	if(isset($_POST['forget_password'])){
		$customer_email = $_POST['customer_email'];
		$result = mysqli_query($db, "SELECT * FROM customers where customer_email='" . $_POST['customer_email'] . "'");
		$row = mysqli_fetch_assoc($result);
		$fetch_customer_email=$row['customer_email'];
		$get_customer_pass=$row['customer_pass'];
		if($customer_email==$fetch_customer_email) {
					$to = $customer_email;
					$subject = "Password Changed!";
					$txt = "Your password is : $get_customer_pass.";
					$headers = "From: info@test.com";
					mail($to,$subject,$txt,$headers);
				}
					else{
						echo 'Sorry! You are not registered!';
					}
	}

	

	
	
	
	
	
?>