<?php 
session_start();

if(!(isset ($_SESSION['customer_email'])) && ($_SESSION["customer_pass"]=1)){
	header("location:index.php");
}

?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Online Shopping</title>
		<link rel="stylesheet" href="css/bootstrap.min.css"/>
		<link rel="stylesheet" type="text/css" href="css/style.css">
	</head>
<body>
		<div class="container-fluid">
			<div class="col-sm-2"></div>		
			<div class="col-sm-8">
				<a class="panel panel-success">Select Your Payment Method</a>
				<div class="col-sm-6 center">
					<a href="https://www.paypal.com/in/home" target="_blank"><img src="product_images/paypal.png"></a>
					<h4 class="text-center">Pay With Paypal</h4>
				</div>
				<div class="col-sm-6 center">
					<a href="checkout_form.php"><img src="product_images/offline.png"></a>
					<h4 class="text-center">Pay Offline</h4>
				</div>
			</div>
			<div class="col-sm-2"></div>
		</div>
<script src="js/bootstrap.min.js"></script>
</body>
</html>
















































