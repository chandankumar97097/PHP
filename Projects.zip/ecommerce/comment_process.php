<?php

session_start();
include("includes/db.php");
include("functions/functions.php");

if(!(isset ($_SESSION['customer_email'])) && ($_SESSION["customer_pass"]=1)){
	header("location:index.php");
}
?>

<?php

	if(!empty($_POST['postcomment'])){
		$_SESSION['error']=array();
		extract($_POST);
		
		if(empty($name)){
			$_SESSION['error']['name']="Please Enter Your Name";
		}
		if(empty($email)){
			$_SESSION['error']['name']="Please Enter Your Email";
		}
		if(empty($message)){
			$_SESSION['error']['name']="Please Enter Review";
		}
		if(!empty($_SESSION['error'])){
			header("Location: details.php");
		}else{
			include("includes/db.php");
					
			$ip = getRealIpAddr();
			$customer_session = $_SESSION['customer_email'];
			$get_customer = "select * from customers where customer_ip='$ip' AND customer_email='$customer_session'";
			$run_customer = mysqli_query($con, $get_customer);
			$customer = mysqli_fetch_array($run_customer);
			$customer_id = $customer['customer_id'];
			
			// Getting Product id
			
				
													
											
			//post customer info		
			$comment_id = $_POST['comment_id'];
			$t = date('Y-m-d');
			
			$q = "insert into comments (comment_id,user_id,p_id,date,name,email,message) values('$comment_id','$customer_id','$product_id','$t','$name','$email','$message')";
			
			mysqli_query($con, $q);
			
			header("Location: details.php");
		}
		
									
		
	}else{
		header("Location: details.php");
	}
?>