<?php 

session_start();
include("includes/db.php");

	if((isset ($_SESSION['customer_email'])) && ($_SESSION["customer_pass"]=1)){
		header("location:profile.php");
	}
	
	// Remember Password
	if(!empty($_POST["remember"])) {
		setcookie ("customer_email",$_POST["customer_email"],time()+ 3600);
		setcookie ("customer_password",$_POST["customer_password"],time()+ 3600);
	}
	
	// Login Script
	$msg = '';
	if (isset($_POST['login'])){
	// Assigning posted values to variables.
	$customer_email = $_POST['customer_email'];
	$customer_password = md5($_POST['customer_password']);
	// Checking the values are existing in the database or not
	$query = "SELECT * FROM customers WHERE customer_email='$customer_email' and customer_pass='$customer_password'";
	 
	$result = mysqli_query($con, $query);
	
	$count = mysqli_num_rows($result);
	
	// If the posted values are equal to the database values, then session will be created for the user.
	if ($count == 1){
	$_SESSION['customer_email'] = $customer_email;
		header('location:profile.php');
	}else{
	// If the login credentials doesn't match, he will be shown with an error message.
	$msg = "Invalid Login Credentials.";
	}
	}

?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Online Shopping</title>
		<link rel="stylesheet" href="css/bootstrap.min.css"/>
		<link rel="stylesheet" type="text/css" href="style.css">
	</head>
<body>
<div class="wait overlay">
	<div class="loader"></div>
</div>
	<div class="navbar navbar-inverse navbar-fixed-top">
		<div class="container-fluid">	
			<div class="navbar-header">
				<a href="index.php" class="navbar-brand">Online Shopping</a>
			</div>
			<ul class="nav navbar-nav">
				<li><a href="index.php"><span class="glyphicon glyphicon-home"></span> Home</a></li>
			</ul>
		</div>
	</div>
	<p><br/></p>
	<p><br/></p>
	<p><br/></p>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-2"></div>
			<div class="col-md-8" id="signup_msg">
				<!--Alert from signup form-->
			</div>
			<div class="col-md-2"></div>
		</div>
		<div class="row">
			<div class="col-md-4"></div>
			<div class="col-md-4">
				<div class="panel panel-primary">
					<div class="panel-heading">Customer Login Form</div>
					<div class="panel-body">
						<!--User Login Form-->
						<p class="txt-center c-red"><?php echo "$msg"; ?></p>
						<form action="" method="post">
							<label for="customer_email">Username or Email</label>
							<input type="customer_email" class="form-control" name="customer_email" id="customer_email" 
							value="<?php if(isset($_COOKIE["customer_email"])) { echo $_COOKIE["customer_email"]; } ?>" />
							<label for="customer_email">Password</label>
							<input type="password" class="form-control" name="customer_password" id="customer_password" value="<?php if(isset($_COOKIE["customer_password"])) { echo $_COOKIE["customer_password"]; } ?>" />
							<p></p>
							<label><input type="checkbox" name="remember" /> Remember </label>
							<p></p>
							<a href="forget_password.php">Forgotten Password</a>
							<input type="submit" class="btn btn-success" name="login" style="float:right;" value="Login" />
							<!--If user dont have an account then he/she will click on create account button-->
							<div><a href="customer_registration.php">Create a new account?</a></div>						
						</form>
				</div>
				<div class="panel-footer"><div id="e_msg"></div></div>
			</div>
		</div>
		<div class="col-md-4"></div>
	</div>
<script src="js/jquery2.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="main.js"></script>
</body>
</html>















