<?php 
session_start();
include("includes/db.php");
include("functions/functions.php");

?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Online Shopping</title>
		<link rel="stylesheet" href="css/bootstrap.min.css"/>
		<link rel="stylesheet" type="text/css" href="css/style.css">
	</head>
<body>
<div class="wait overlay">
	<div class="loader"></div>
</div>
	<div class="navbar navbar-inverse navbar-fixed-top">
		<div class="container-fluid">	
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#collapse" aria-expanded="false">
					<span class="sr-only"> navigation toggle</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a href="index.php" class="navbar-brand">Online Shopping</a>
			</div>
		<div class="collapse navbar-collapse" id="collapse">
			<ul class="nav navbar-nav">
				<li><a href="index.php"><span class="glyphicon glyphicon-home"></span> Home</a></li>
				<li style="width:300px;left:10px;top:10px;">
					<form method="get" action="results.php" enctype="multipart/form-data">
						<input class="search_input" type="text" name="keywords" placeholder="Search a Product...">
						<input class="search_button"type="submit" value="Search" name="search">
					</form>
				</li>
			</ul>
			<ul class="nav navbar-nav navbar-right">
			<li><a href="wishlist.php"><span class="glyphicon glyphicon-heart"></span> Wishlist 
					<span class='badge'><?php echo wishlistItems(); ?></span>
			</a></li>
				<li>
					<a href="cart.php"><span class="glyphicon glyphicon-shopping-cart"></span> Cart
						<span class='badge'><?php echo items(); ?></span>
					</a>
				</li>
				<?php 
					if(isset($_SESSION['customer_email']) == true) {
						echo "<li><a href='login.php' class='dropdown-toggle' data-toggle='dropdown'><span class='glyphicon glyphicon-user'></span>";
					}else{
						
				?>
					<li><a href="login.php"><span class="glyphicon glyphicon-user"></span>  Login
				<?php } ?>
					
				<?php 
					if(isset($_SESSION['customer_email']) == true) {
						echo "Hi, ".$_SESSION["customer_email"];
						
				?>
				</a>
					<ul class="dropdown-menu">
						<li>
							<a href="cart.php"><span class="glyphicon glyphicon-shopping-cart"></span> Cart
								<?php if (isset($_SESSION['customer_email']) == true) { 
									echo "<span class='badge'>";
										items();
									echo "</span>";
								}else{
									echo "";
								}
								?>
							
							</a>
						</li>
						<li class="divider"></li>
						<li><a href="customer/my_account.php" style="text-decoration:none; color:blue;">My Account</a></li>
						<li class="divider"></li>
						<li><a href="customer/change_password.php" style="text-decoration:none; color:blue;">Change Password</a></li>
						<li class="divider"></li>
						<li><a href="logout.php" style="text-decoration:none; color:blue;">Logout</a></li>
					</ul>
					<?php }else{ ?>
					<ul class="dropdown-menu">
						<div style="width:300px;">
							<div class="panel panel-primary">
								<div class="panel-heading">Login</div>
								<div class="panel-heading">
									<form onsubmit="return false" id="login">
										<label for="email">Email</label>
										<input type="email" class="form-control" name="email" id="email" required/>
										<label for="email">Password</label>
										<input type="password" class="form-control" name="password" id="password" required/>
										<p><br/></p>
										<a href="customer_registration.php?register=1" style="color:white; list-style:none;">Create a New Account</a><input type="submit" value="Login" class="btn btn-success" style="float:right;"><br>
										<a href="forget_password.php" style="color:white; list-style:none;">Forgotten Password</a>
									</form>
								</div>
								<div class="panel-footer" id="e_msg"></div>
							</div>
						</div>
					</ul>
					<?php } ?>
					
				</li>
				
			</ul>
		</div>
	</div>
</div>	
	<p><br/></p>
	<p><br/></p>
	<p><br/></p>

	<div class="container-fluid">
		<div class="row">
			<div class="col-md-2"></div>
			<div class="col-md-8">
				<div class="panel panel-primary">
					<div class="panel-heading">Confirm Your Shipping Address</div>
					<div class="panel-body">
						
						<?php 
								
							$customer_email = $_SESSION['customer_email'];
								
							$get_customer = "select * from customers where customer_email='$customer_email'";
								
							$run_customer = mysqli_query($con, $get_customer);
								
							$row=mysqli_fetch_array($run_customer); 
								
							$customer_country = $row['customer_country'];
							
						?>
						<!-- Shipping Address Confirmation -->
						<form action="" id="address_confirm" method="post" enctype="multipart/form-data">
								
								<div class="col-md-6">
									<label for="shipping_address">Address</label>
									<input type="text" id="shipping_address" name="shipping_address"class="form-control" required>
								</div>
								<div class="col-md-6">
									<label for="customer_contact">Contact</label>
									<input type="text" id="customer_contact" name="customer_contact" class="form-control" required>
								</div>
								<div class="col-md-6">
									<label for="customer_address2">City</label>
									<input type="text" id="" name="customer_city" class="form-control" value="">
								</div>
							
								<div class="col-md-6">
									<label for="customer_address2">Country</label><br>
									<select name="customer_country" class="form-control" disabled>
										<option value="<?php echo $customer_country; ?>"><?php echo $customer_country; ?></option>
									</select>
								</div>
								<p><br/></p>
								<div class="col-md-12 mt-20 mb-10">
									<input style="width:100%;" value="Confirm Shipping Address" type="submit" name="address_confirm" class="btn btn-success btn-lg">
								</div>
						</form>
						<!-- Shipping Address Confirmation -->
						
					</div>
					<div class="panel-footer"></div>
				</div>
			</div>
			<div class="col-md-2"></div>
		</div>
	</div>
	
		<?php 
	
		// Check Shipping Address
	if(isset($_POST['address_confirm'])){
		
		$customer_email = $_SESSION['customer_email'];
		$sel_customers = "select * from customers where customer_email='$customer_email'";
		$run_customers = mysqli_query($con, $sel_customers);
		$check_customers = mysqli_num_rows($run_customers);
		
			$customer_address = $check_customers['customer_address'];
			$shipping_address = $check_customers['shipping_address'];
			$customer_contact = $check_customers['customer_contact'];
			$shipping_contact = $check_customers['shipping_contact'];
			$customer_city = $check_customers['customer_city'];	
			$shipping_city = $check_customers['shipping_city'];
			
		if($customer_address==$shipping_address && $customer_contact == $shipping_contact && $customer_city == $shipping_city){
			echo "<script>alert('Your Shipping Address and Billing Address Are Same!')</script>";
			echo "<script>window.open('checkout.php', '_self')</script>";
		}else{
			
			$insert_customer = "insert into customers where customer_email='$customer_email' (shipping_address,shipping_contact,shipping_city) values ('$shipping_address','$shipping_contact','$shipping_city')";
		
			$run_customer = mysqli_query($con, $insert_customer);
			
			echo "<script>window.open('checkout.php', '_self')</script>";
			
		}
		
		}
	
	
	
?>

<script src="js/jquery2.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="main.js"></script>
</body>
</html>