<?php

session_start();

unset($_SESSION["customer_id"]);
unset($_SESSION["customer_name"]);
unset($_SESSION["customer_email"]);
unset($_SESSION["customer_pass"]);

header("location:index.php");

?>