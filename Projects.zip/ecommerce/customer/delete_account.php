<?php 

session_start();
include("../includes/db.php");
include("../functions/functions.php");

if(!(isset ($_SESSION['customer_email'])) && ($_SESSION["customer_pass"]=1)){
	header("location:../index.php");
}

?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Online Shopping</title>
		<link rel="stylesheet" href="../css/bootstrap.min.css"/>
		<link rel="stylesheet" type="text/css" href="../css/style.css"/>
	</head>
<body>
<div class="wait overlay">
	<div class="loader"></div>
</div>
	<div class="navbar navbar-inverse navbar-fixed-top">
		<div class="container-fluid">	
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#collapse" aria-expanded="false">
					<span class="sr-only">navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a href="../index.php" class="navbar-brand">Online Shopping</a>
			</div>
		<div class="collapse navbar-collapse" id="collapse">
			<ul class="nav navbar-nav">
				<li><a href="../index.php"><span class="glyphicon glyphicon-home"></span> Home</a></li>
				<li style="width:300px;left:10px;top:10px;">
					<form method="get" action="../results.php" enctype="multipart/form-data">
						<input class="search_input" type="text" name="keywords" placeholder="Search a Product...">
						<input class="search_button"type="submit" value="Search" name="search">
					</form>
				</li>
			</ul>
			<ul class="nav navbar-nav navbar-right">
			<li><a href="../wishlist.php"><span class="glyphicon glyphicon-heart"></span> Wishlist 
					<?php if (isset($_SESSION['customer_email']) == true) { 
							echo "<span class='badge'>";
								wishlistItems();
							echo "</span>";
						}else{
							echo "";
						}
					?>
			</a></li>
				<li>
					<a href="../cart.php"><span class="glyphicon glyphicon-shopping-cart"></span> Cart
						<?php if (isset($_SESSION['customer_email']) == true) { 
							echo "<span class='badge'>";
								items();
							echo "</span>";
						}else{
							echo "";
						}
						?>
					</a>
				</li>
				<?php 
					if (isset($_SESSION['customer_email']) == true) {
						echo "<li><a href='../login.php' class='dropdown-toggle' data-toggle='dropdown'><span class='glyphicon glyphicon-user'></span>";
					}else{
						
				?>
					<li><a href="../login.php"><span class="glyphicon glyphicon-user"></span>  Login
				<?php } ?>
					
				<?php 
					if (isset($_SESSION['customer_email']) == true) {
						echo "Hi, ".$_SESSION["customer_email"];
						
				?>
				</a>
					<ul class="dropdown-menu">
						<li>
							<a href="../cart.php"><span class="glyphicon glyphicon-shopping-cart"></span> Cart
								<?php if (isset($_SESSION['customer_email']) == true) { 
									echo "<span class='badge'>";
										items();
									echo "</span>";
								}else{
									echo "";
								}
								?>
							
							</a>
						</li>
						<li class="divider"></li>
						<li><a href="my_account.php" style="text-decoration:none; color:blue;">My Account</a></li>
						<li class="divider"></li>
						<li><a href="change_password.php" style="text-decoration:none; color:blue;">Change Password</a></li>
						<li class="divider"></li>
						<li><a href="logout.php" style="text-decoration:none; color:blue;">Logout</a></li>
					</ul>
					<?php }else{ ?>
					<ul class="dropdown-menu">
						<div style="width:300px;">
							<div class="panel panel-primary">
								<div class="panel-heading">Login</div>
								<div class="panel-heading">
									<form onsubmit="return false" id="login">
										<label for="email">Email</label>
										<input type="email" class="form-control" name="email" id="email" required/>
										<label for="email">Password</label>
										<input type="password" class="form-control" name="password" id="password" required/>
										<p><br/></p>
										<a href="../customer_registration.php?register=1" style="color:white; list-style:none;">Create a New Account</a><input type="submit" value="Login" class="btn btn-success" style="float:right;"><br>
										<a href="../forget_password.php" style="color:white; list-style:none;">Forgotten Password</a>
									</form>
								</div>
								<div class="panel-footer" id="e_msg"></div>
							</div>
						</div>
					</ul>
					<?php } ?>
					
				</li>
				
			</ul>
		</div>
	</div>
	</div>
	<p><br/></p>
	<p><br/></p>
	<p><br/></p>
	<div class="container">
		<div class="col-sm-3">
			<div class="nav nav-pills nav-stacked">
				<li class="active"><a href="my_account.php">My Account</a></li>
				<li><a href="my_order.php">My Orders</a></li>
				<li><a href="edit_account.php?edit_account">Edit Account</a></li>
				<li><a href="change_password.php">Change Password</a></li>
				<li><a href="delete_account.php">Delete Account</a></li>
				<li><a href="logout.php">Logout</a></li>			
			</div>
		</div>
		<div class="col-sm-9">
			<form action="" method="post">

				<table align="center" width="600">
					
					<tr align="center">
						<td colspan="2"><h2>Do you really want to delete your account?</h2></td>
					 </tr>
					 
					 <tr align="center">
						<td>
						<input type="submit" name="yes" class="yes" value="Yes, I Want to Delete" />
						<input type="submit" name="no" class="no" value="No, I Do not Want to Delete" />
						</td>
					 </tr>
				</table>

			</form>
		</div>
		<?php 

		$customer_email = $_SESSION['customer_email'];

			if(isset($_POST['yes'])){
				
				$delete_customer = "delete from customers where customer_email='$customer_email'";
				$run_delete = mysqli_query($con, $delete_customer); 
				
				if($run_delete){
					
					session_destroy();
					
					echo "<script>alert('Your Account has been deleted, Good Bye!')</script>";
					echo "<script>window.open('../index.php','_self')</script>";
					}
				
				}
				
				if(isset($_POST['no'])){
					
					echo "<script>window.open('my_account.php','_self')</script>";
					
					
					}
					
		?>

	</div>

<script src="../js/jquery2.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script src="../main.js"></script>
</body>	
</html>