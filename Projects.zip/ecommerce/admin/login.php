<?php 

session_start();
include("../includes/db.php");

if((isset ($_SESSION['username'])) && ($_SESSION["password"]=1)){
	header("location:insert_product.php");
}

	// Remember Password
	if(!empty($_POST["remember"])) {
		setcookie ("username",$_POST["username"],time()+ 3600);
		setcookie ("password",$_POST["password"],time()+ 3600);
	}

	$msg = '';
	if (isset($_POST['login'])){
	// Assigning posted values to variables.
	$username = $_POST['username'];
	$password = md5($_POST['password']);
	// Checking the values are existing in the database or not
	$query = "SELECT * FROM admin_login WHERE username='$username' and password='$password'";
	 
	$result = mysqli_query($con, $query);
	
	$count = mysqli_num_rows($result);
	
	// If the posted values are equal to the database values, then session will be created for the user.
	if ($count == 1){
	$_SESSION['username'] = $username;
		header('location:index.php');
	}else{
	// If the login credentials doesn't match, he will be shown with an error message.
	$msg = "Invalid Login Credentials.";
	}
	}


?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Online Shopping</title>
		<link rel="stylesheet" href="../css/bootstrap.min.css"/>
		<link rel="stylesheet" type="text/css" href="../style.css">
	</head>
<body>
<div class="wait overlay">
	<div class="loader"></div>
</div>
	
	<p><br/></p>
	<p><br/></p>
	<p><br/></p>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-2"></div>
			<div class="col-md-8" id="signup_msg">
				<!--Alert from signup form-->
			</div>
			<div class="col-md-2"></div>
		</div>
		<div class="row">
			<div class="col-md-4"></div>
			<div class="col-md-4">
				<div class="panel panel-primary">
					<div class="panel-heading">Admin Login</div>
					<div class="panel-body">
						<!--User Login Form-->
						<?php echo "$msg"; ?>
						<form action="" method="post">
							<label for="customer_email">Username or Email</label>
							<input type="customer_email" class="form-control" name="username" id="customer_email" 
							value="<?php if(isset($_COOKIE["username"])) { echo $_COOKIE["username"]; } ?>"/>
							<label for="customer_email">Password</label>
							<input type="password" class="form-control" name="password" id="customer_password" value="<?php if(isset($_COOKIE["password"])) { echo $_COOKIE["password"]; } ?>"/>
							<p></p>
							<label><input type="checkbox" name="remember"> Remember </label>
							<p></p>
							<a href="forget_password.php">Forgotten Password</a>
							<input type="submit" class="btn btn-success" name="login" style="float:right;" value="Login">
												
						</form>
				</div>
				<div class="panel-footer"><div id="e_msg"></div></div>
			</div>
		</div>
		<div class="col-md-4"></div>
	</div>
<script src="../js/jquery2.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script src="../main.js"></script>
</body>
</html>















