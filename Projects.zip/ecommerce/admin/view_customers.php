<?php include('dash-header.php'); ?>
<?php include('dash-sidebar.php'); ?>
<?php 

session_start();
include("../includes/db.php");

if(!(isset ($_SESSION['username'])) && ($_SESSION["password"]=1)){
	header("location:login.php");
}

?>
    <main class="app-content">
        </div>
        <div class="col-md-12">
          <div class="tile">
            <table border="2" width="100%">
				<tr align="center">
					<td colspan="6"><h2>All Customers</h2></td>
				</tr>
				<tr align="center">
					<th>S.N</th>
					<th>Name</th>
					<th>Email</th>
					<th>Image</th>
					<th>Country</th>
					<th>Delete</th>
				</tr>
				<?php 
					$get_c = "select * from customers";
					$run_c = mysqli_query($con, $get_c); 
					$i=0;
					while($row_c=mysqli_fetch_array($run_c)){
						$c_id = $row_c['customer_id'];
						$c_name = $row_c['customer_name'];
						$c_email = $row_c['customer_email'];
						$c_image = $row_c['customer_image'];
						$c_country = $row_c['customer_country'];
						$i++;
				?>
				<tr align="center">
					<td><?php echo $i; ?></td>
					<td><?php echo $c_name; ?></td>
					<td><?php echo $c_email; ?></td>
					<td><img src="../customer/customer_photos/<?php echo $c_image; ?>" width="60" height="60"/></td>
					<td><?php echo $c_country; ?></td>
					<td><a href="view_customers.php?delete_c=<?php echo $c_id; ?>">Delete</a></td>
				</tr>
				<?php } ?>
			
			</table>
          </div>
        </div>
      </div>
    </main>
	
<?php 
	if(isset($_GET['delete_c'])){
		
		$delete_id = $_GET['delete_c'];
		$delete_c = "delete from customers where customer_id='$delete_id'";
		$run_delete = mysqli_query($con, $delete_c);
		
		if($run_delete){
			echo "<script>alert('Customer has been deleted!')</script>";
			echo "<script>window.open('view_customers.php?view_customers','_self')</script>";
		}
	}
?>	
<?php include('dash-footer.php'); ?>