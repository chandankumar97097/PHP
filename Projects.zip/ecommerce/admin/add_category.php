<?php include('dash-header.php'); ?>
<?php include('dash-sidebar.php'); ?>
<?php 

session_start();
include("../includes/db.php");

if(!(isset ($_SESSION['username'])) && ($_SESSION["password"]=1)){
	header("location:login.php");
}

?>
    <main class="app-content">
        </div>
        <div class="col-md-12">
          <div class="tile">
            <h3 class="tile-title">Add New Category</h3>
            <form action="add_category.php" name="product_form" method="post" enctype="multipart/form-data">
				<table>
					<input type="text" name="category" class="cat_field">
					<input type="submit" name="add_category" value="Add Product">
				</table>
			</form>
          </div>
        </div>
      </div>
    </main>
	
<?php 
	if(isset($_POST['add_category'])){
		
		//text data variables
		$cat_id = $_POST['cat_id'];
		$cat_title = $_POST['category'];
		
		if($cat_title==''){
			
			echo "<script>alert('Please Fill the Category Name!')</script>";
			exit();
			}
		else {
		
		$insert_cat = "insert into categories (cat_id,cat_title) values ('$cat_id','$cat_title')";
		
		$run_cat = mysqli_query($con, $insert_cat);
		
		if($run_cat){
			
			
			echo "<script>alert('Category inserted successfully')</script>";
			
			echo "<script>window.open('add_category.php','_self')</script>";
		}
		}
	}
?>
	
<?php include('dash-footer.php'); ?>