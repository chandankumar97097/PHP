<?php include('dash-header.php'); ?>
<?php include('dash-sidebar.php'); ?>
<?php 

session_start();
include("../includes/db.php");

if(!(isset ($_SESSION['username'])) && ($_SESSION["password"]=1)){
	header("location:login.php");
}

?>
    <main class="app-content">
        </div>
        <div class="col-md-12">
          <div class="tile">
            <h3 class="tile-title">All Products</h3>
            <form action="all_products.php" name="product_form" method="post" enctype="multipart/form-data">
				<div class="products">
					<div class="col-md-12">
						<div class="panel panel-primary">
								<div class="panel-body">
								<div>
									<div class='row center' style='margin-bottom: 20px;'>
										<div class='col-md-2 col-xs-2'><b>Delete Product</b></div>
										<div class='col-md-2 col-xs-2'><b>Edit Product</b></div>
										<div class='col-md-2 col-xs-2'><b>Product Image</b></div>
										<div class='col-md-2 col-xs-2'><b>Product Name</b></div>
										<div class='col-md-2 col-xs-2'><b>Product Category</b></div>
										<div class='col-md-2 col-xs-2'><b>Product Price</b></div>
										
									</div>
								<?php 
								
									$get_products = "select * from products";
									$run_products = mysqli_query($con, $get_products);
													
										while($row_products = mysqli_fetch_array($run_products)){
											$product_id = $row_products['product_id'];
											$product_title = $row_products['product_title'];
											$product_cat = $row_products['product_cat'];
											$product_img = $row_products['product_img'];
											$product_price = $row_products['product_price'];
											$product_desc = $row_products['product_desc'];
													
											echo "
													<div class='row all_product_list'>
														<div class='col-md-2'>
															<div class='btn-group'>
																<label class='btn btn-default btn-lg toggle-checkbox primary'>
																	<span class='glyphicon glyphicon-trash'></span>
																	<input id='one' name='remove[]' value='$product_id' autocomplete='off' class='' type='checkbox' />
																</label>
															</div>
														</div>
														<div class='col-md-2'><a href='edit_product.php?edit_pro=$product_id'>Edit</a></div>
														<div class='col-md-2'><img src='../product_images/$product_img' height='80' width='80'></div>
														<div class='col-md-2'>$product_title</div>
														<div class='col-md-2'>$product_cat</div>
														<div class='col-md-2'><input type='text' width='100%' class='form-control' value='$.$product_price' disabled></div>
													</div>
												
												";		
										}
									
								?>
								<input type="submit" name="delete_products" value="Delete Products" class="delete"/>
								</div>
							</div>
						</div>
					
				</div>
			</form>
			
<?php 
	
	function delete_products(){
		
		global $con;
	
	if(isset($_POST['delete_products'])){
		foreach($_POST['remove'] as $remove_id){
			 $delete_products = "delete from products where product_id='$remove_id'";
			
			$run_delete = mysqli_query($con, $delete_products); 
			
			if($run_delete){
				echo "<script>window.open('all_products.php','_self')</script>";
				
				}
			
			}
		
		}	
	}
	
	echo @$up_cart = delete_products();
	
	
?>

          </div>
        </div>
      </div>
    </main>
	
<?php include('dash-footer.php'); ?>