<?php include('dash-header.php'); ?>
<?php include('dash-sidebar.php'); ?>
<?php 

session_start();
include("../includes/db.php");

if(!(isset ($_SESSION['username'])) && ($_SESSION["password"]=1)){
	header("location:login.php");
}

?>
			<?php 
				$get_p = "select * from products";
				$run_p = mysqli_query($con, $get_p); 
				while($row_p=mysqli_fetch_array($run_p)){
					$p_sign = $row_p['p_sign'];
			?>
	
			<main class="app-content">
				</div>
				<div class="col-md-12">
				  <div class="tile">
					<h3 class="tile-title">Change Currency</h3>
					<form action="" name="product_form" method="post">
						<select name="price_sign" class="status">
							<option value="<?php echo $p_sign; ?>"><?php echo $p_sign; ?></option>
							<option value="$">$</option>
							<option value="€">€</option>
							<option value="£">£</option>
							<option value="¢">¢</option>
							<option value="₹">₹</option>
						</select>
						<input type="submit" name="update_currency" value="Update Currency">
					</form>
				  </div>
				</div>
			  </div>
			</main>
			
		<?php } ?>
		<?php 
			if(isset($_POST['update_currency'])){
				
				$updated_p_sign = $_POST['price_sign'];
				$update_currency = "update products set p_sign='$updated_p_sign'";
				$run_update = mysqli_query($con, $update_currency);
				if($run_update){
					
					echo "<script>alert('Currency Has been Updated')</script>";
					echo "<script>window.open('change_currency.php','_self')</script>";
					
					}
				}
		?>
          </div>
        </div>
      </div>
    </main>
	
<?php include('dash-footer.php'); ?>