<?php include('dash-header.php'); ?>
<?php include('dash-sidebar.php'); ?>
<?php 

session_start();
include("../includes/db.php");

if(!(isset ($_SESSION['username'])) && ($_SESSION["password"]=1)){
	header("location:login.php");
}

?>

    <main class="app-content">
        <div class="col-sm-12">
			<h2>Admin Panel</h2>
			<br>
			<?php 
				$get_c = "select * from admin_login";
				$run_c = mysqli_query($con, $get_c); 
				while($row_c=mysqli_fetch_array($run_c)){
					$username = $row_c['username'];
					$email = $row_c['email'];
					$password = $row_c['password'];
				?>
			<p>Name: <?php echo $username; ?></p>
			<p>Email ID: <?php echo $email; ?></p>
			<p>Password: <?php echo $password; ?></p>
			<?php } ?>
		</div>
		<br>
		<h4>Change Username & Email </h4>
		<a href="change_email.php">Edit Email</a>
		<br><p></p>
		<h4>Change Password</h4>
		<a href="change_password.php">Edit Password</a>
		<br><p></p>
		<h4>Currency Settings</h4>
		<a href="change_currency.php">Edit Currency</a>
		
    </main>
	

	
<?php include('dash-footer.php'); ?>