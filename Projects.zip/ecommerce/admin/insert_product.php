<?php include('dash-header.php'); ?>
<?php include('dash-sidebar.php'); ?>
<?php 

session_start();
include("../includes/db.php");

if(!(isset ($_SESSION['username'])) && ($_SESSION["password"]=1)){
	header("location:login.php");
}

?>

    <main class="app-content">
        </div>
        <div class="col-md-12">
          <div class="tile">
            <h3 class="tile-title">Add New Product</h3>
            <form action="insert_product.php" name="product_form" method="post" enctype="multipart/form-data">
				<table>
					<div class="col-sm-6">
						<label>Product Name:</label>
						<input type="text" name="product_title">
					</div>
					<div class="col-sm-6">
						<label>Product Price:</label>
						<input type="text" name="product_price">
					</div>
					<div class="col-sm-9"></div>
					<div class="col-sm-3 right">
					<img src="" class="s_product_img"/>
						<label>Product Image:</label>
						<input type="file" id="file" name="product_img" value="<?php echo $p_image; ?>">
					</div>
					<div class="col-sm-6">
						<label>Product Category:</label>
						<select name="product_cat">
							<?php
								$get_cats = "select * from categories";
								$run_cats = mysqli_query($con, $get_cats);
									
								while($row_cats = mysqli_fetch_array($run_cats)){
									$cat_id = $row_cats['cat_id'];
									$cat_title = $row_cats['cat_title'];
										
									echo "<option value='$cat_id'><li>$cat_title</li></option>";
										
								}
									
							?>
						</select>
					</div>
					<div class="col-sm-6">
						<label>Product Description:</label>
						<textarea name="product_desc"></textarea>
						<input type="submit" name="insert_product" value="Add Product">
					</div>
				</table>
			</form>
          </div>
        </div>
      </div>
    </main>
	
<?php 
	if(isset($_POST['insert_product'])){
		
		//text data variables
		$product_title = $_POST['product_title'];
		$product_cat = $_POST['product_cat'];
		$product_price = $_POST['product_price'];
		$product_desc = $_POST['product_desc'];
		
		
		//image names
		$product_img = $_FILES['product_img']['name'];
		
		//Image temp names
		$temp_name = $_FILES['product_img']['tmp_name'];
		
		if($product_title=='' OR $product_cat=='' OR $product_price=='' OR $product_desc=='' OR $product_img==''){
			
			echo "<script>alert('please fill all the fields!')</script>";
			exit();
			}
		else {
		//uploading images to its folder
		move_uploaded_file($temp_name,"product_images/$product_img");
		
		$insert_product = "insert into products (cat_id,product_id,product_title,product_img,product_price,product_desc) values ('$product_cat','$product_id','$product_title','$product_img','$product_price','$product_desc')";
		
		$run_product = mysqli_query($con, $insert_product);
		
		if($run_product){
			
			
			echo "<script>alert('Product inserted successfully')</script>";
			
			echo "<script>window.open('insert_product.php','_self')</script>";
			}
		
		
		}
		
		
		
		}
?>
	
<?php include('dash-footer.php'); ?>