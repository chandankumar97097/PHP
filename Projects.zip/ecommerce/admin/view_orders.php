<?php include('dash-header.php'); ?>
<?php include('dash-sidebar.php'); ?>
<?php 

session_start();
include("../includes/db.php");

if(!(isset ($_SESSION['username'])) && ($_SESSION["password"]=1)){
	header("location:login.php");
}

?>
    <main class="app-content">
        </div>
        <div class="col-md-12">
          <div class="tile">
            <table border="2" width="100%">
				<tr align="center">
					<td colspan="10"><h2>Customer Orders</h2></td>
				</tr>
				<tr align="center">
					<th>Order No.</th>
					<th>Email ID</th>
					<th>Invoice No.</th>
					<th>Price</th>
					<th>Product QTY</th>
					<th>Status</th>
					<th>Action</th>
					<th>Order Date</th>
					<th>Delete</th>
				</tr>
				<?php 
					
					$get_p = "select * from products";
					$run_p = mysqli_query($con, $get_p); 
					$row_p=mysqli_fetch_array($run_p);
					$p_sign = $row_p['p_sign'];
									
					$get_orders = "select * from customer_orders";
					$run_orders = mysqli_query($con, $get_orders); 
					$i=0;
					
					while($row_orders=mysqli_fetch_array($run_orders)){
						
						$order_id = $row_orders['order_id'];
						$c_id = $row_orders['customer_id'];
						$invoice = $row_orders['invoice_no'];
						$amount = $row_orders['due_amount'];
						$qty = $row_orders['total_products'];
						$status = $row_orders['order_status'];
						$date = $row_orders['order_date'];
						$i++;
						
				?>
				<tr align="center">
					<td><?php echo $i; ?></td>
					<td>
						<?php 
							$get_customer = "select * from customers where customer_id='$c_id'";
							$run_customer = mysqli_query($con, $get_customer);
							$row_customer=mysqli_fetch_array($run_customer); 
							$customer_email = $row_customer['customer_email'];
							echo $customer_email;
						?>
					</td>
					<td><?php echo $invoice; ?></td>
					<td><?php echo $p_sign.' '. $amount; ?></td>
					<td><?php echo $qty; ?></td>
					<td><?php echo $status; ?></td>
					<td><a href="edit_order.php?edit_order=<?php echo $order_id; ?>">Edit</a></td>
					<td><?php echo $date; ?></td>
					<td><a href="view_orders.php?delete_order=<?php echo $order_id; ?>">Delete</a></td>
				</tr>
				<?php } ?>
			
			</table>
          </div>
        </div>
      </div>
    </main>
	
<?php 
	if(isset($_GET['delete_order'])){
		
		$delete_id = $_GET['delete_order'];
		$delete_order = "delete from customer_orders where order_id='$delete_id'";
		$run_delete = mysqli_query($con, $delete_order);
		
		if($run_delete){
			echo "<script>alert('Customer has been deleted!')</script>";
			echo "<script>window.open('view_orders.php?view_customers','_self')</script>";
		}
	}
?>		
	
<?php include('dash-footer.php'); ?>