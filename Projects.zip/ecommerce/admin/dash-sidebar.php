<!-- Sidebar menu-->
    <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
    <aside class="app-sidebar">
      <ul class="app-menu">
        <li><a class="app-menu__item active" href="index.php"><i class="app-menu__icon fa fa-dashboard"></i><span class="app-menu__label">Dashboard</span></a></li>
        <li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-laptop"></i><span class="app-menu__label">Add Products</span><i class="treeview-indicator fa fa-angle-right"></i></a>
          <ul class="treeview-menu">
			<li><a class="treeview-item" href="all_products.php"><i class="icon fa fa-circle-o"></i> All Products</a></li>
            <li><a class="treeview-item" href="insert_product.php"><i class="icon fa fa-circle-o"></i> Add Product</a></li>
            <li><a class="treeview-item" href="products_category.php" rel="noopener"><i class="icon fa fa-circle-o"></i> All Categories</a></li>
            <li><a class="treeview-item" href="add_category.php"><i class="icon fa fa-circle-o"></i> Add Category</a></li>
          </ul>
        </li>
		
		<li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-users"></i><span class="app-menu__label">Customers</span><i class="treeview-indicator fa fa-angle-right"></i></a>
          <ul class="treeview-menu">
			<li><a class="treeview-item" href="view_customers.php"><i class="icon fa fa-circle-o"></i> All Customers</a></li>
            <li><a class="treeview-item" href="view_orders.php"><i class="icon fa fa-circle-o"></i> View Orders</a></li>
           </ul>
        </li>
        
      </ul>
    </aside>