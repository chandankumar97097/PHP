<?php include('dash-header.php'); ?>
<?php include('dash-sidebar.php'); ?>
<?php 

session_start();
include("../includes/db.php");

if(!(isset ($_SESSION['username'])) && ($_SESSION["password"]=1)){
	header("location:login.php");
}

?>
    <main class="app-content">
        </div>
        <div class="col-md-12">
          <div class="tile">
            <h3 class="tile-title">All Categories</h3>
            <form action="products_category.php" name="product_form" method="post" enctype="multipart/form-data">
				<div class="products">
					<div class="col-md-8">
				<div class="panel panel-primary">
						<div class="panel-body">
						<div>
							<div class='row center' style='margin-bottom: 20px;'>
								<div class='col-md-3 col-xs-3'><b>Delete Category</b></div>
								<div class='col-md-3 col-xs-3'><b>Edit Category</b></div>
								<div class='col-md-3 col-xs-3'><b>Category Name</b></div>
							</div>
						<?php 
							$get_cat = "select * from categories";
							$run_cat = mysqli_query($con, $get_cat);
											
								while($row_cat = mysqli_fetch_array($run_cat)){
									$cat_id = $row_cat['cat_id'];
									$cat_title = $row_cat['cat_title'];
									
									echo "
											<div class='row' style='margin-bottom: 10px;'>
												<div class='col-md-3'>
													<div class='btn-group'>
														<label class='btn btn-default btn-lg toggle-checkbox primary'>
															<span class='glyphicon glyphicon-trash'></span>
															<input id='one' name='remove[]' value='$cat_id' autocomplete='off' class='' type='checkbox' />
														</label>
													</div>
												</div>
												<div class='col-md-3'><a href='edit_category.php?edit_category=$cat_id'>Edit</a></div>
												<div class='col-md-3'>$cat_title</div>
											</div>
										
										";		
								}
							
						?>
						<input type="submit" name="delete_cat" value="Delete Category" class="update"/>
						</div>
					</div>
				</div>
			</div>
				</div>
			</form>
			
<?php 
	
	function delete_cat(){
		
		global $con;
	
	if(isset($_POST['delete_cat'])){
		foreach($_POST['remove'] as $remove_id){
			 $delete_cat = "delete from categories where cat_id='$remove_id'";
			
			$run_delete = mysqli_query($con, $delete_cat); 
			
			if($run_delete){
				echo "<script>window.open('products_category.php','_self')</script>";
				
				}
			
			}
		
		}	
	}
	
	echo @$up_cart = delete_cat();
	
	
?>

<?php 
		if(isset($_GET['edit_product'])){
			
			$cat_id = $_SESSION['cat_id'];
			$get_cat = "select * from categories where customer_email='$customer_email'";
			$run_cat = mysqli_query($con, $cat_id);
			$row=mysqli_fetch_array($run_cat); 
				
				$cat_id = $row['cat_id']; 
				$cat_title = $row['cat_title']; 
		}
	?>

          </div>
        </div>
      </div>
    </main>
	
<?php include('dash-footer.php'); ?>