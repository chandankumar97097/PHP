<?php include('dash-header.php'); ?>
<?php include('dash-sidebar.php'); ?>
<?php 

session_start();
include("../includes/db.php");

if(!(isset ($_SESSION['username'])) && ($_SESSION["password"]=1)){
	header("location:login.php");
}

?>
    <main class="app-content">
        </div>
        <div class="col-md-12">
          <div class="tile">
		  <form action="" name="order_form" method="post" enctype="multipart/form-data">
            <table border="2" width="100%">
				<tr align="center">
					<td colspan="10"><h3>Change <u>Customer Order</u> Status</h3></td>
				</tr>
				<tr align="center">
					<th>Order No.</th>
					<th>Invoice No.</th>
					<th>Price</th>
					<th>Product QTY</th>
					<th>Product Status</th>
					<th>Update Date</th>
					<th>Update Order</th>
					
				</tr>
				<?php 
					
					if(isset($_GET['edit_order'])){
					$order_id = $_GET['edit_order'];
					$get_orders = "select * from customer_orders  where order_id='$order_id'";
					$run_orders = mysqli_query($con, $get_orders); 
					$i=0;
					
					$row_orders=mysqli_fetch_array($run_orders);
						
						$order_id = $row_orders['order_id'];
						$invoice = $row_orders['invoice_no'];
						$amount = $row_orders['due_amount'];
						$qty = $row_orders['total_products'];
						$status = $row_orders['order_status'];
						$update_date = $row_orders['update_date'];;
						$i++;
					}					
				?>
				
				<tr align="center">
					<td><?php echo $i; ?></td>
					<td><?php echo $invoice; ?></td>
					<td>
						<?php 
							$get_p = "select * from products";
							$run_p = mysqli_query($con, $get_p); 
							$row_p=mysqli_fetch_array($run_p);
								$p_sign = $row_p['p_sign'];	
						?>
						<?php echo $p_sign; ?> 
						<?php echo $amount; ?>
						
					</td>
					<td><?php echo $qty; ?></td>
					<td>
						<select name="status_list" class="form-control status">
							<option value="<?php echo $status; ?>"><?php echo $status; ?></option>
							<option value="Pending">Pending</option>
							<option value="Despatched">Despatched</option>
							<option value="Delivered">Delivered</option>
							<option value="Canceled">Canceled</option>
						</select>
					</td>
					<td><?php echo $update_date; ?></td>
					<td><input type="submit" name="update_order" value="Update"></td>
					
				</tr>
				
			</table>
			</form>
          </div>
        </div>
      </div>
    </main>
		
<?php 
	
	if(isset($_POST['update_order'])){
		
		$updated_status = $_POST['status_list'];
		$update_date = date("Y-m-d H:i:s");
		
		$update_order = "update customer_orders set order_status='$updated_status',update_date='$update_date' where order_id='$order_id'";
		
		$run_update = mysqli_query($con, $update_order); 
		
		if($run_update){
			
			echo "<script>alert('Order Updated Successfully')</script>";
			
			echo "<script>window.open('edit_order.php?edit_order=$order_id','_self')</script>"; 
			}
		
		}
	


?>		
<?php include('dash-footer.php'); ?>