<?php include('dash-header.php'); ?>
<?php include('dash-sidebar.php'); ?>
<?php 

session_start();
include("../includes/db.php");

if(!(isset ($_SESSION['username'])) && ($_SESSION["password"]=1)){
	header("location:login.php");
}

?>
		<?php 
			if(isset($_GET['edit_category'])){
				$cat_id = $_GET['edit_category'];
				$edit_category = "select * from categories where cat_id='$cat_id'";
				$run_edit = mysqli_query($con, $edit_category); 
				$row_edit=mysqli_fetch_array($run_edit);
				$cat_edit_id = $row_edit['cat_id'];
				$cat_title = $row_edit['cat_title'];
			}
		?>
	
			<main class="app-content">
				</div>
				<div class="col-md-12">
				  <div class="tile">
					<h3 class="tile-title">Update Category</h3>
					<form action="" name="product_form" method="post">
						<input type="text" name="category" value="<?php echo $cat_title; ?>">
						<input type="submit" name="update_category" value="Update Category">
					</form>
				  </div>
				</div>
			  </div>
			</main>
			
		<?php 
			if(isset($_POST['update_category'])){
				
				$cat_title123 = $_POST['category'];
				$update_category = "update categories set cat_title='$cat_title123' where cat_id='$cat_edit_id'";
				$run_update = mysqli_query($con, $update_category);
				if($run_update){
					
					echo "<script>alert('Category Has been Updated')</script>";
					echo "<script>window.open('products_category.php','_self')</script>";
					
					}
				}
		?>
          </div>
        </div>
      </div>
    </main>
	
<?php include('dash-footer.php'); ?>