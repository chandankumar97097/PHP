<?php include('dash-header.php'); ?>
<?php include('dash-sidebar.php'); ?>
<?php 

session_start();
include("../includes/db.php");

if(!(isset ($_SESSION['username'])) && ($_SESSION["password"]=1)){
	header("location:login.php");
}

?>
			<?php 
				$get_c = "select * from admin_login";
				$run_c = mysqli_query($con, $get_c); 
				while($row_c=mysqli_fetch_array($run_c)){
					$password = $row_c['password'];
			?>
	
			<main class="app-content">
				<div class="col-md-12">
				  <div class="tile">
					<h3 class="tile-title">Update Password</h3>
					<form action="" name="product_form" method="post">
						<input type="text" name="pass" value="<?php echo $password; ?>">
						<input type="submit" name="update_pass" value="Update">
					</form>
				  </div>
				</div>
			</main>
			
		<?php } ?>
		<?php 
			if(isset($_POST['update_pass'])){
				
				$pass = md5($_POST['pass']);
				$update_pass = "update admin_login set password='$pass'";
				$run_update = mysqli_query($con, $update_pass);
				if($run_update){
					
					echo "<script>alert('Password Has been Updated')</script>";
					echo "<script>window.open('change_password.php','_self')</script>";
					
					}
				}
		?>
          </div>
        </div>
      </div>
    </main>
	
<?php include('dash-footer.php'); ?>