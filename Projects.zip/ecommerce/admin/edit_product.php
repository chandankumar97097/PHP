<?php include('dash-header.php'); ?>
<?php include('dash-sidebar.php'); ?>
<?php 

session_start();
include("../includes/db.php");

if(!(isset ($_SESSION['username'])) && ($_SESSION["password"]=1)){
	header("location:login.php");
}

?>
	<?php 
	
		if(isset($_GET['edit_pro'])){
	
			$edit_id = $_GET['edit_pro'];
			$get_edit = "select * from products where product_id='$edit_id'";
			$run_edit = mysqli_query($con, $get_edit); 
			$row_edit = mysqli_fetch_array($run_edit); 
			$update_id = $row_edit['product_id'];
			$p_title = $row_edit['product_title'];
			$cat_id = $row_edit['cat_id'];
			$p_image = $row_edit['product_img'];
			$p_price = $row_edit['product_price'];
			$p_desc = $row_edit['product_desc'];
			}
			// Getting product related category
			$get_cat = "select * from categories where cat_id='$cat_id'";
			$run_cat = mysqli_query($con, $get_cat); 
			$cat_row = mysqli_fetch_array($run_cat);
			$cat_edit_title = $cat_row['cat_title'];
	
	?>
    <main class="app-content">
        </div>
        <div class="col-md-12">
          <div class="tile">
            <h3 class="tile-title">Update Product</h3>
            <form action="" name="product_form" method="post" enctype="multipart/form-data">
				<table>
					<div class="col-sm-6">
						<label>Product Name:</label>
						<input type="text" name="product_title" value="<?php echo $p_title; ?>">
					</div>
					<div class="col-sm-6">
						<label>Product Price:</label>
						<input type="text" name="product_price" value="<?php echo $p_price; ?>">
					</div>
					<div class="col-sm-9"></div>
					<div class="col-sm-3 right">
					<img src="../product_images/<?php echo $p_image; ?>" class="s_product_img"/>
						<label>Product Image:</label>
						<input type="file" id="file" name="product_img" value="<?php echo $p_image; ?>">
					</div>
					
					<div class="col-sm-6">
						<label>Product Category:</label>
						<select name="product_cat">
							<option value="<?php echo $cat_id; ?>"><?php echo $cat_edit_title; ?></option>
							<?php 
								
								$get_cats = "select * from categories";
								$run_cats = mysqli_query($con, $get_cats);
								while ($row_cats=mysqli_fetch_array($run_cats)){
									$cat_id = $row_cats['cat_id'];
									$cat_title = $row_cats['cat_title'];
								echo "<option value='$cat_id'>$cat_title</option>";
								}
								
							?>
						</select>
					</div>
					<div class="col-sm-6">
						<label>Product Description:</label>
						<textarea name="product_desc"><?php echo $p_desc; ?></textarea>
						<input type="submit" name="update_product" value="Update Product">
					</div>
				</table>
			</form>
          </div>
        </div>
      </div>
    </main>


<?php 
	
	if(isset($_POST['update_product'])){
		
		$product_title = $_POST['product_title'];
		$product_cat = $_POST['product_cat'];
		$product_price = $_POST['product_price'];
		$product_desc = $_POST['product_desc'];
		$product_img = $_FILES['product_img']['name'];
		$temp_name = $_FILES['product_img']['tmp_name'];
		
		if($product_title=='' OR $product_cat=='' OR $product_price=='' OR $product_desc=='' OR $product_img==''){
			
			echo "<script>alert('please fill all the fields!')</script>";
			exit();
			}
		
		else {
		
		//upload images in folder
		move_uploaded_file($temp_name,"../product_images/$product_img");
		
		$update_product = "update products set cat_id='$product_cat',product_title='$product_title',product_img='$product_img',product_price='$product_price',product_desc='$product_desc' where product_id='$update_id'";
		
		$run_update = mysqli_query($con, $update_product); 
		
		if($run_update){
			
			
			echo "<script>alert('Product Updated Successfully')</script>";
			
			echo "<script>window.open('all_products.php','_self')</script>"; 
			}
		
		}
		}


?>	
<?php include('dash-footer.php'); ?>