<?php 
session_start();
include("includes/db.php");
include("functions/functions.php");

if((isset ($_SESSION['customer_email'])) && ($_SESSION["customer_pass"]=1)){
	header("location:login.php");
}

?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Online Shopping</title>
		<link rel="stylesheet" href="css/bootstrap.min.css"/>
		<link rel="stylesheet" type="text/css" href="css/style.css">
	</head>
<body>
<div class="wait overlay">
	<div class="loader"></div>
</div>
	<div class="navbar navbar-inverse navbar-fixed-top">
		<div class="container-fluid">	
			<div class="navbar-header">
				<a href="index.php" class="navbar-brand">Online Shopping</a>
			</div>
			<ul class="nav navbar-nav">
				<li><a href="index.php"><span class="glyphicon glyphicon-home"></span> Home</a></li>
			</ul>
			<ul class="nav navbar-nav navbar-right">
				<li>
					<a href="login.php"><span class="glyphicon glyphicon-user"></span> Login </a>
				</li>
			</ul>
		</div>
	</div>
	<p><br/></p>
	<p><br/></p>
	<p><br/></p>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-2"></div>
			<div class="col-md-8">
				<div class="panel panel-primary">
					<div class="panel-heading">SignUp Form</div>
					<div class="panel-body">
						<form id="customer_registration.php" method="post" enctype="multipart/form-data">
							
								<div class="col-md-6">
									<label for="customer_name">Name</label>
									<input type="text" id="customer_name" name="customer_name" class="form-control" required>
								</div>
								<div class="col-md-6">
									<label for="customer_email">Email</label>
									<input type="email" id="customer_email" name="customer_email"class="form-control" required>
								</div>
								<div class="col-md-6">
									<label for="customer_pass">Password</label>
									<input type="password" id="customer_pass" name="customer_pass"class="form-control" required>
								</div>
								<div class="col-md-6">
									<label for="customer_pass">Confirm Password</label>
									<input type="password" id="customer_confirm_pass" name="customer_confirm_pass"class="form-control" required>
								</div>
								<div class="col-md-6">
									<label for="customer_contact">Contact</label>
									<input type="text" id="customer_contact" name="customer_contact"class="form-control" required>
								</div>
								<div class="col-md-6">
									<label for="customer_address">Address</label>
									<input type="text" id="customer_address" name="customer_address"class="form-control" required>
								</div>
								<div class="col-md-6">
									<label for="customer_address2">Country</label><br>
									<select name="customer_country" class="form-control">
										<option value="" selected hidden disabled>Select a Country</option>
										<option value="India">India</option>
										<option value="Pakistan">Pakistan</option>
										<option value="Japan">Japan</option>
										<option value="United State">United State</option>
										<option value="United Kingdom">United Kingdom</option>
									</select>
								</div>
								<div class="col-md-6">
									<label for="customer_address2">City</label>
									<input type="text" id="" name="customer_city"class="form-control" required>
								</div>
								<div class="col-md-12">
									<label for="customer_address2">Image</label>
									<input type="file" id="" name="customer_image"class="form-control" required>
								</div>
								<p><br/></p>
								<div class="col-md-12 mt-20 mb-10">
									<input style="width:100%;" value="Sign Up" type="submit" name="register" class="btn btn-success btn-lg">
								</div>
						</form>
					</div>
					<div class="panel-footer"></div>
				</div>
			</div>
			<div class="col-md-2"></div>
		</div>
	</div>
<script src="js/jquery2.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="main.js"></script>
</body>
</html>