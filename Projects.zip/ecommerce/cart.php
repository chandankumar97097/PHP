<?php 

session_start();
include("includes/db.php");
include("functions/functions.php");

?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Online Shopping</title>
		<link rel="stylesheet" href="css/bootstrap.min.css"/>
		<link rel="stylesheet" type="text/css" href="css/style.css"/>
	</head>
<body>
<div class="wait overlay">
	<div class="loader"></div>
</div>
	<div class="navbar navbar-inverse navbar-fixed-top">
		<div class="container-fluid">	
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#collapse" aria-expanded="false">
					<span class="sr-only">navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a href="index.php" class="navbar-brand">Online Shopping</a>
			</div>
		<div class="collapse navbar-collapse" id="collapse">
			<ul class="nav navbar-nav">
				<li><a href="index.php"><span class="glyphicon glyphicon-home"></span> Home</a></li>
				<li style="width:300px;left:10px;top:10px;">
					<form method="get" action="results.php" enctype="multipart/form-data">
						<input class="search_input" type="text" name="keywords" placeholder="Search a Product...">
						<input class="search_button"type="submit" value="Search" name="search">
					</form>
				</li>
			</ul>
			<ul class="nav navbar-nav navbar-right">
			<li><a href="wishlist.php"><span class="glyphicon glyphicon-heart"></span> Wishlist 
					<span class='badge'><?php echo wishlistItems(); ?></span>
			</a></li>
				<li>
					<a href="cart.php"><span class="glyphicon glyphicon-shopping-cart"></span> Cart
						<span class='badge'><?php echo items(); ?></span>
					</a>
				</li>
				<?php 
					if (isset($_SESSION['customer_email']) == true) {
						echo "<li><a href='login.php' class='dropdown-toggle' data-toggle='dropdown'><span class='glyphicon glyphicon-user'></span>";
					}else{
						
				?>
					<li><a href="login.php"><span class="glyphicon glyphicon-user"></span>  Login
				<?php } ?>
					
				<?php 
					if (isset($_SESSION['customer_email']) == true) {
						echo "Hi, ".$_SESSION["customer_email"];
						
				?>
				</a>
					<ul class="dropdown-menu">
						<li>
							<a href="cart.php"><span class="glyphicon glyphicon-shopping-cart"></span> Cart
								<?php if (isset($_SESSION['customer_email']) == true) { 
									echo "<span class='badge'>";
										items();
									echo "</span>";
								}else{
									echo "";
								}
								?>
							
							</a>
						</li>
						<li class="divider"></li>
						<li><a href="customer/my_account.php" style="text-decoration:none; color:blue;">My Account</a></li>
						<li class="divider"></li>
						<li><a href="customer/change_password.php" style="text-decoration:none; color:blue;">Change Password</a></li>
						<li class="divider"></li>
						<li><a href="logout.php" style="text-decoration:none; color:blue;">Logout</a></li>
					</ul>
					<?php }else{ ?>
					<ul class="dropdown-menu">
						<div style="width:300px;">
							<div class="panel panel-primary">
								<div class="panel-heading">Login</div>
								<div class="panel-heading">
									<form onsubmit="return false" id="login">
										<label for="email">Email</label>
										<input type="email" class="form-control" name="email" id="email" required/>
										<label for="email">Password</label>
										<input type="password" class="form-control" name="password" id="password" required/>
										<p><br/></p>
										<a href="customer_registration.php?register=1" style="color:white; list-style:none;">Create a New Account</a><input type="submit" value="Login" class="btn btn-success" style="float:right;"><br>
										<a href="forget_password.php" style="color:white; list-style:none;">Forgotten Password</a>
									</form>
								</div>
								<div class="panel-footer" id="e_msg"></div>
							</div>
						</div>
					</ul>
					<?php } ?>
					
				</li>
				
			</ul>
		</div>
	</div>
	</div>
	<p><br/></p>
	<p><br/></p>
	<p><br/></p>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-2"></div>
			<div class="col-md-8" id="cart_msg">
				<!--Cart Message--> 
			</div>
			<div class="col-md-2"></div>
		</div>
		<div class="row">
			<div class="col-md-2"></div>
			<div class="col-md-8">
				<div class="panel panel-primary">
					<div class="panel-heading">Cart Checkout</div>
						<div class="panel-body">
						<form action="cart.php" method="post" enctype="multipart/form-data">
						<div class="row" style="margin-bottom: 20px;">
							<div class="col-md-2 col-xs-2"><b>Remove</b></div>
							<div class="col-md-2 col-xs-2"><b>Product Image</b></div>
							<div class="col-md-4 col-xs-4"><b>Product Name</b></div>
							<div class="col-md-2 col-xs-2"><b>Quantity</b></div>
							<?php 
								$get_p = "select * from products";
								$run_p = mysqli_query($con, $get_p); 
								$row_p=mysqli_fetch_array($run_p);
								$p_sign = $row_p['p_sign'];
							?>
							<div class="col-md-2 col-xs-2"><b>Product Price <?php echo $p_sign; ?></b></div>
						</div>
						
					<?php 
					
						@$customer_session = $_SESSION['customer_email'];
						$get_customer_id = "select * from customers where customer_email='$customer_session'";
						$run_customer = mysqli_query($db, $get_customer_id); 
						$row_customer = mysqli_fetch_array($run_customer); 
						$customer_id = $row_customer['customer_id'];
			
						$ip_add = getRealIpAddr();
						$total = 0;
						//$qty = 1;
						$sel_price = "select * from cart where ip_add='$ip_add' AND customer_id='$customer_id'";
						$run_price = mysqli_query($con, $sel_price); 
						
						while ($record=mysqli_fetch_array($run_price)){
							$pro_id = $record['p_id'];
							$pro_price = "select * from products where product_id='$pro_id'";
							$run_pro_price = mysqli_query($con,$pro_price); 
							
						while($p_price=mysqli_fetch_array($run_pro_price)){
						
							$product_price = array($p_price['product_price']);
							$product_title = $p_price['product_title'];
							$product_image = $p_price['product_img'];
							$only_price = $p_price['product_price'];
							$qty = $record['qty'];
							
							
							$values = array_sum($product_price);
							
							$total +=$values;
					?>
						<div class="row" style="margin-bottom: 10px;">
							<div class="col-md-2">
								<div class="btn-group">
									<label class="btn btn-default btn-lg toggle-checkbox primary">
										<span class="glyphicon glyphicon-trash"></span>
										<input id="one" name="remove[]" value="<?php echo $pro_id; ?>" autocomplete="off" class="" type="checkbox" />
									</label>
								</div>
							</div>
							<div class="col-md-2"><img src="product_images/<?php echo $product_image; ?>" height="80" width="80" id="<?php echo $pro_id;?>"></div>
							<div class="col-md-4" id="<?php echo $pro_id;?>"><?php echo $product_title; ?></div>
							<?php 
								if(isset($_POST['update'])){
									
									$qty = $_POST['qty'];
									
									$insert_qty = "update cart set qty='$qty' where ip_add='$ip_add'";
									
									$run_qty = mysqli_query($con, $insert_qty);
									
									$total = $total*$qty;
									
								}
							
							?>
							<div class="col-md-2"><input type='number' name="qty" class='form-control' value='<?php echo $qty; ?>' id="<?php echo $pro_id;?>"></div>
							
							<div class="col-md-2"><input type='text' class='form-control' value='<?php echo $p_sign.$only_price; ?>' disabled></div>
							
						</div>
						
						
						
						<?php }} ?>
						<div class="row">
						<div class="col-md-5"></div>
							<div class="col-md-4">
								<input type="submit" name="update" value="Update Cart" class="update"/>
							</div>
							<div class="col-md-3">
									<?php 
										$get_p = "select * from products";
										$run_p = mysqli_query($con, $get_p); 
										$row_p=mysqli_fetch_array($run_p);
										$p_sign = $row_p['p_sign'];
									?>
								<b>Total <?php echo $p_sign; ?><?php echo $total; ?></b>
								<a href="address_confirm.php" style="text-decoration:none; color:#000;" class="add_to_cart">Place Order</a>
							</div>
						</div> 
						</form>
<?php 
	
	function updatecart() {
		
		global $con;
	
		if(isset($_POST['update'])){
			
			foreach($_POST['remove'] as $remove_id){
				
				$delete_products = "delete from cart where p_id='$remove_id'";
				
				$run_delete = mysqli_query($con, $delete_products); 
				
				if($run_delete){
					
					echo "<script>window.open('cart.php','_self')</script>";
				}
				
			}	
		}	
		if(isset($_POST['continue'])){
			
				echo "<script>window.open('index.php','_self')</script>";
		}
	}
	
	echo @$up_cart = updatecart();
	
	
?>
					</div>
					<div class="panel-footer"></div>
				</div>
			</div>
			<div class="col-md-2"></div>
			
		</div>
<script src="js/jquery2.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="main.js"></script>
</body>	
</html>