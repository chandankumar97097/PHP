<?php 

session_start();
include("includes/db.php");
include("functions/functions.php");

if(!(isset ($_SESSION['customer_email'])) && ($_SESSION["customer_pass"]=1)){
	header("location:login.php");
}

?>


<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Online Shopping</title>
		<link rel="stylesheet" href="css/bootstrap.min.css"/>
		<link rel="stylesheet" type="text/css" href="css/style.css">
	</head>
<body>
		<div class="container-fluid">
			<div class="col-sm-2"></div>		
			<div class="col-sm-8">
				<a class="panel panel-success">Select Your Payment Method</a>
				<?php
				
					$ip = getRealIpAddr();
					$customer_session = $_SESSION['customer_email'];
					
					$get_customer = "select * from customers where customer_ip='$ip' AND customer_email='$customer_session'";
					
					$run_customer = mysqli_query($con, $get_customer);
					
					$customer = mysqli_fetch_array($run_customer);
					
					$customer_id = $customer['customer_id'];
					
				?>
				<div class="col-sm-6 center">
					<a href="https://www.paypal.com/in/home" target="_blank"><img src="product_images/paypal.png"></a>
					<h4 class="text-center">Pay With Paypal</h4>
				</div>
				<div class="col-sm-6 center">
					<a href="order.php?c_id=<?php echo $customer_id; ?>"><img src="product_images/offline.png"></a>
					<h4 class="text-center">Pay Offline (Cash on Delivery)</h4>
				</div>
			</div>
			<div class="col-sm-2"></div>
		</div>
		
<script src="js/bootstrap.min.js"></script>
</body>
</html>
















































