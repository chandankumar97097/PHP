<?php

// Aggrigation class
	class Aggrigation{
		private $name;
		private $email;
		public function __construct($name,$email){
			$this->name=$name;
			$this->email=$email;
		}
		public function getName(){
			return $this->name;
		}
		public function getEmail(){
			return $this->email;
		}
	} //container class
	class Book{
		private $author;
		private $price;
		private $name;
		public function __construct($author,$price,$name){
			$this->author=$author;
			$this->price=$price;
			$this->name=$name;
		}
		public function getAuthor(){
			return $this->author;
		}
		public function getPrice(){
			return $this->price;
		}
		public function getName(){
			return $this->name;
		}
		
	}

	$obj = new Aggrigation('Chandan','chandankumar@gmail.com');
	echo $obj->getName();
	echo "<br>";
	echo $obj->getEmail();
	echo "<br>";
	echo "<hr>";

	$obj2 = new Book($obj,100,"Book Name");
	echo $obj2->getAuthor()->getName();
	echo "<br>";
	echo $obj2->getAuthor()->getEmail();
	echo "<br>";
	echo $obj2->getPrice();
	echo "<br>";
	echo $obj2->getName();


?>