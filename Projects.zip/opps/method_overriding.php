<?php 

	class Father{
		public function add(){
			echo "Father Class";
		}
	}
	class Son extends Father{
		public function add(){
			echo "Son Class";
		}
	}
	$obj = new Son;
	$obj->add();

?>