<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <div class="row">
    <script>

      //object
      var jsonobj = {
        "FirstName" : "Sonu",
        "LastName" : "Kumar",
        "Age" : 21,
        "Address" : "Gandhi More"
      }

      //Modify FirstName
      jsonobj.FirstName = "Chandan";

      //Add new key value
      jsonobj.Designation = "Developer";

      //Delete LastName
      delete jsonobj.LastName;

      for(abc in jsonobj){
        document.write(jsonobj[abc]+"<br>");
      }


/*
      //Array object
      var obj = {
        "array" : ["Chandan","Kumar"]
      }
      document.write(obj.array[1]);
*/

/*
  //create an object an under that create array an in this array create objects.
    var obj = {
      "array" : [
        {
          "FirstName" : "Sonu",
          "LastName" : "Kumar"
        },
        {
          "Age" : 21
        },
        {
          "Address" : "Gandhi More"
        },
        {
          "Id" : 211783
        }
      ]
    }
    for(all in obj.array){
      for(inner in obj.array[all]){
        document.write(obj.array[all][inner]+"<br>");
      }
      
    }
*/

  var senddata = {name: "Chandan", age: 21};
  var changedata = JSON.stringify(senddata); //conver object in to string
  var jsobj = JSON.parse(changedata); //convert string in to object
  document.write(jsobj.name);


    </script>
  </div>
</div>

</body>
</html>
