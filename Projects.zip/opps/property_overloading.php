<?php

//property overloading with using get and set
	class over{
		private $data = array();
		public function __set($name,$value){
			$this->data[$name] = $value;
			echo "Setting '$name' property to '$value'";
			echo "<br>";
		}
		public function __get($name){
			echo "Getting '$name' property with value";
			if(array_key_exists($name, $this->data)){
				return $this->data[$name];
			}
		}
	}
	$obj = new over();
	$obj->a="Hello";
	echo $obj->a;

?>