<?php

class Foo
{
    private $x;

    public function __set($name, $value)
    {
        $this->x[$name]=str_replace('dog','cat',$value);
    }

    public function __get($name)
    {
        return $this->x[$name];
     }

}

$foo=new Foo;
$foo->a='I have a dog';

echo $foo->a; //prints I have a cat


//////////////////
/*Property Overloading -------- is used to create dynamic properties in object contexsion .A property associated with a class instance and if its not declared within the scope of the class it is considered as overloaded properties. __set() called while initializing overloaded properties __get() called while using overloaded properties with print statement. __isset() __unset()*/

class H{
		private $data = array();
		public $data2 = 1;
		private $hidden = 2;
		public function __set($name, $value){
			echo "Our SET Method";
			$this->data[$name] = $value;
		}
		public function __get($name){
			echo "Our GET Method";
			if(array_key_exists($name, $this->data)){
				return $this->data[$name];
			}
			$t = debug_backtrace();
			return NULL;
		}
		public function __isset($name)
	    {
	        return isset($this->data[$name]);
	    }
	    public function __unset($name){
	    	unset($this->data[$name]);
	    }
	    public function hide(){
	    	return $this->hidden;
	    }
	}
	$obj = new H;
	echo $obj->a=1;
	echo "<br>";
	var_dump(isset($obj->a));
	echo "<br>";

	echo $obj->data2;
	echo "<br>";

	unset($obj->a);
	var_dump(isset($obj->a));
	echo "<br>";

	echo $obj->hide();
	//echo $obj->hidden;
?>