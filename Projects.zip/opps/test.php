<?php 


// $a = random_int(100, 110);
// var_dump($a);


// $a = random_bytes(2);
// print(bin2hex($a));

/*
$x = 10;
$y = 20;
$z = -10;
echo $x+($y-$z);
*/

// declare(strict_types = 1);
// 	function add(float $a, int $b){
// 	 return $a+$b;
// 	}
// 	var_dump (add(2.1, 2));

# Null Coalescing operators --
	// $sum1 = 110;
	// print($sum1)?? "NULL";

# Spaceship operator
// it is used to compare two expressions and return -1,0,1 when var_array() one variable is less than equal to or grater 
// than as compare to other variable

//Return type declaration
	// declare(strict_types = 1);
	// function Check($price, $gst) :int{
	// 	return $price+$gst;
	// }
	// echo Check(11,2);


// $data = array("Chandan Kumar", "Mukesh Kumar", "Rityunjay Kumar", "Vivek Kumar", "Santosh Kumar", "Gopal Dasbairagya", "Niraj Kumar", "Hena Ara", "Deborata", "Ritesh Kumar", "Amit Kumar", "Prince Kumar", "Sourabh Kumar", "Gourav Kumar Saha");
// foreach($data as $alldata){
// 	echo "<pre>";
// 	echo $alldata;
// }



?>