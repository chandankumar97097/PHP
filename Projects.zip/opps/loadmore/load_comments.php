      <?php 

        include('fetch.php');

        $commentNewCount = $_POST['commentNewCount'];
        $sql = "SELECT * FROM employee LIMIT $commentNewCount";
        $result = mysqli_query($conn, $sql);
        if(mysqli_num_rows($result) > 0 ){
          while($row = mysqli_fetch_assoc($result)){
            echo "<p>";
            echo $row['emp_name'];
            echo "<br />";
            echo $row['emp_email'];
            echo "</p>";
          }
        }else{
          echo "There are no comment!";
        }

      ?>