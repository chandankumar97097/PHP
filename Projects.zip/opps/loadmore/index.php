<?php 

include('fetch.php');

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <script>
    $(document).ready(function(){
      var commentCount = 1;
      $("button").click(function(){
        commentCount = commentCount + 1;
        $("#comments").load("load_comments.php", {
          commentNewCount: commentCount
        });
      });
    });
  </script>
</head>
<body>

<div class="container">
  <div class="row">
    <div id="comments">
      <?php 
        $sql = "SELECT * FROM `employee` LIMIT 2";
        $result = mysqli_query($conn, $sql);
        if(mysqli_num_rows($result) > 0 ){
          while($row = mysqli_fetch_assoc($result)){
            echo "<p>";
            echo $row['id'];
            echo "<p>";
            echo $row['emp_name'];
            echo "<br />";
            echo $row['emp_email'];
            echo "</p>";
          }
        }else{
          echo "There are no comment!";
        }

      ?>
    </div>
    <button class="btn btn-success">Load More...</button>
  </div>
</div>

</body>
</html>