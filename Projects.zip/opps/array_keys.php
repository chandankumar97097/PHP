<?php 

// $fees = array("Chandan" => "400", "Rityunjay" => "500", "Mukesh" => "600");
// $keys = array_keys($fees);
// echo $keys[1];


$fees = array("Chandan" => "400", "Rityunjay" => "500", "Mukesh" => "600");
$keys = array_keys($fees);
foreach ($keys as $value) {
	echo $value. "<br />";
}

//$fees = array("Chandan" => "400", "Rityunjay" => "500", "Mukesh" => "600");
//foreach ($fees as $value) {
//    echo $value. "<br />";
//}
