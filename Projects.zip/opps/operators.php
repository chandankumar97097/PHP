<?php


//$a=5;
//echo $a++;
//echo $a;
//////////////
$a=5;
++$a;
echo $a;


?>