<?php 

$data = "This is the data of my website!";
if(preg_match("/data/", $data)){
	echo "Data Matched! this is the data: $data";
}
else{
	echo "No Data Found!";
}
echo "<hr><pre>";

$d = "This is my website and also this is the data of my website!";
if(preg_match_all("/website/", $d, $ar)){
	print_r($ar);
}

?>