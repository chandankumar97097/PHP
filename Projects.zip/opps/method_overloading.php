<?php 


	class Apple{
		public $p;
		public function __call($method,$para){
			if($method == "test"){
				$count = count($para);
				if($count == 1){
					echo "Para One";
				}
				if($count == 2){
					echo "Para Two";
				}
				if($count == 3){
					echo "Para Three";
				}
				if($count == 4){
					echo "Para Four";
				}
			}
		}
	}
	$obj = new Apple;
	$obj->test("Pineapple", "Orange");


?>

