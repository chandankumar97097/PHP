<?php 

	abstract class Father{
		public function disp(){
			echo "Father Class";
		}
	abstract function Absmethod();
	}
	class Son extends Father{
		public function Absmethod(){
			parent::disp();
			echo "<br>";
			echo "Son Class";
		}
	}
	$obj = new Son;
	$obj->Absmethod();



// abstract class absclass{
// 	public function show(){
// 		echo "Hello World";
// 	}
// 	abstract function override();
// }
// class override extends absclass{
// 	public function override(){
// 		echo "Overrided!";
// 		echo "<br>";
// 		parent::show();
// 	}
// }
// $obj = new override;

?>