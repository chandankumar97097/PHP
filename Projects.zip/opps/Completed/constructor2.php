<?php 

// Default Constructor
// class AutoCall{
// 	public function __construct(){
// 		echo "This is Constructor Function!";
// 	}
// }
// $obj = new AutoCall;

// Parameterized Constructor
class AutoCall{
	public function __construct($name,$roll,$id){
		echo "Name: " .$this->name=$name."<br>";
		echo "Roll: " .$this->roll=$roll. "<br>";
		echo "ID: " .$this->id=$id. "<br>";
	}
}
$obj = new AutoCall("Chandan Kumar", "111", "211783");

?>