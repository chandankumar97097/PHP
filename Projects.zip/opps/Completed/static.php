<?php 

//static keyword
function show(){
	static $a = 0;
	$a++;
	echo "<br>";
	echo $a;
}
show();
show();
show();

//2nd eg:
// class Father{
// 	public static function show(){
// 		echo "Hello World!";
// 	}
// }
// Father::show();

?>