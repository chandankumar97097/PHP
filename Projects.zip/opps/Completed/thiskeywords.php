<?php

class show{
	public $price;
	public $products;
	public function showdata(){
		echo "Product: ".$this->products;
		echo "<br />";
		echo "Price: ".$this->price;
	}
}
$obj = new show;
$obj->price=200;
$obj->products="Mango";
$obj->showdata();

/*
class Mobile{
	public $model;
	public function showModel(){
		echo $this->model;
	}
}
$mobile = new Mobile;
$mobile->model="Canvas 1";
$mobile->showModel();
*/

?>