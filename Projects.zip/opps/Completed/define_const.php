<?php 

define("Define", "Hi");
echo Define;

?>