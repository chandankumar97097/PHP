<?php 

// For Loop
// for($i=0; $i<11; $i++){
// 	echo "This is Number ".$i."<br>";
// }

// While Loop
// $i = 0;
// while($i<11){
// 	echo "This is Number ".$i."<br>";
// 	$i++;
// }

// Do While Loop
// $i = 0;
// do{
// 	echo "This is Number ".$i."<br>";
// 	$i++;
// }while($i<11);

// Foreach Loop
$data = array("Chandan Kumar", "Mukesh Kumar", "Rityunjay Kumar", "Vivek Kumar", "Santosh Kumar", "Gopal Dasbairagya", "Niraj Kumar", "Hena Ara", "Deborata", "Ritesh Kumar", "Amit Kumar", "Prince Kumar", "Sourabh Kumar", "Gourav Kumar Saha");
foreach($data as $alldata){
	echo "<pre>";
	echo $alldata;
}

?>