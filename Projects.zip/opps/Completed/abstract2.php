<?php

//abstract class must have atleast one abstract method and abstract class method body must declare in the extended class. 

abstract class Bank{
	public function Bkname(){
		echo "HDFC Bank";
	}
	abstract function BranchName();
}
class Branch extends Bank{
	public function BranchName(){
		echo self::Bkname();
		echo "<br>";
		echo "City Center, Durgapur";
	}
}
$obj = new Branch();
$obj->BranchName();

?>