<?php 

$str = "Chandan;Kundan;Ram";
$s = explode(';', $str);
echo "<pre>";
print_r($s);

?>