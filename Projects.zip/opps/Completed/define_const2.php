<?php 

// define("Key", "This is the body of constant");
// echo Key;

// define("CONSTANT", array("Chandan","Durgapur"));
// echo CONSTANT[0];

define("CONSTANT", array("name" => "Chandan","address" => "Durgapur"));
echo CONSTANT[address];
?>