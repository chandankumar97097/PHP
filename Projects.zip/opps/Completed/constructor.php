<?php

/*1
	//default constructor
	class Students{
		public function __construct(){
			echo "Constructor Called!";
		}
	}

	$obj = new Students;
*/
	//parameterized constructor
	class Students{
		public function __construct($name){
			$this->name=$name; 
			echo "Hello Mr. ". $name ."<br>";

		}
	}
	$obj = new Students('Chandan');
	$obj = new Students('Ram');
	$obj = new Students('Mukesh');

	
?>