<?php 

$a = array("Chandan","Sonu","Bajrangi","Kundan");
$str = implode(',', $a);
echo "<pre>";
echo $str;

?>