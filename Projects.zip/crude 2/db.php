<?php 

$hostname = "localhost";
$username = "root";
$password = "Test_pw9";
$dbname = "chandan_crude2";

// Database Connection
try{
	$conn = new PDO("mysql:host={$hostname};dbname={$dbname}", "$username", "$password");
	$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(PDOException $e){
	echo $e->getMessage();
}

?>