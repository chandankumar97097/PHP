<?php

include('db.php');

if(isset($_GET['edit_id']) &&  !empty($_GET['edit_id'])){
	$id = $_GET['edit_id'];

	$stmt = $conn->prepare('SELECT * FROM employee WHERE id=:id');
	$stmt->execute(array(':id'=>$id));
	$edit_row = $stmt->FETCH(PDO::FETCH_ASSOC);
	extract($edit_row);
}

	if (empty($emp_name)){
		$errMsg = "Name is Required";
	}elseif(empty($emp_id)){
		$errMsg = "Emp ID is Required";
	}elseif(empty($emp_doj)){
		$errMsg = "Date of Joining is Required";
	}elseif(empty($emp_email)){
		$errMsg = "Email is Required";
	}elseif(empty($phone)){
		$errMsg = "Phone No. is Required";
	}elseif(empty($department)){
		$errMsg = "Department is Required";
	}


?>

<html>
	<head>
		<title>Crude Operation Using PDO Connection</title>
		<link rel="stylesheet" type="text/css" href="style.css">
	</head>
	<body>
<div class="cnt">
	<div class="edit_form_section">
		<form action="" method="post">
			<h2>Update Employee </h2>
			<h5>Serial Number: <?php echo $edit_row['id']; ?></h5>
			<div>
				<input type="text" name="emp_name" value="<?php echo $edit_row['emp_name']; ?>" placeholder="Employee Name">
			</div>
			<div>
				<input type="text" name="emp_id" value="<?php echo $edit_row['emp_id']; ?>" placeholder="Employee ID">
			</div>
			<div>
				<input type="text" name="emp_doj" value="<?php echo $edit_row['emp_doj']; ?>" placeholder="Date of Joining">
			</div>
			<div>
				<input type="text" name="emp_email" value="<?php echo $edit_row['emp_email']; ?>" placeholder="Email ID">
			</div>
			<div>
				<input type="text" name="phone" value="<?php echo $edit_row['phone']; ?>" placeholder="Phone No.">
			</div>
			<div>
				<input type="text" name="department" value="<?php echo $edit_row['department']; ?>" placeholder="Department">
			</div>
			<div>
				<a href="index.php" class="cancel_btn">Cancel</a>
				<button type="submit" name="updatedata" class="inser_btn">Update</button>
			</div>

		</form>
	</div>
</div>

<?php 

if(isset($_POST['updatedata'])){
	$emp_name = $_POST['emp_name'];
	$emp_id = $_POST['emp_id'];
	$emp_doj = $_POST['emp_doj'];
	$emp_email = $_POST['emp_email'];
	$phone = $_POST['phone'];
	$department = $_POST['department'];

	$stmt2 = $conn->prepare("UPDATE employee SET emp_name=:emp_name,emp_id=:emp_id,emp_doj=:emp_doj,emp_email=:emp_email,phone=:phone,department=:department WHERE id=:id");
	$stmt2->bindParam(':id',$id);
	$stmt2->bindParam(':emp_name',$emp_name);
	$stmt2->bindParam(':emp_id',$emp_id);
	$stmt2->bindParam(':emp_doj',$emp_doj);
	$stmt2->bindParam(':emp_email',$emp_email);
	$stmt2->bindParam(':phone',$phone);
	$stmt2->bindParam(':department',$department);

	if($stmt2->execute()){
		$successMsg="Data Inserted";
		header("location: index.php");
	}else{
		$errMsg1="Data Not Inserted";
	}
}

?>

	</body>
</html>