<?php 
		
	include('db.php');
	if(isset($_GET['delete_id'])){
		$delete_id = $_GET['delete_id'];
		$select = $conn->prepare("DELETE FROM employee where id='$delete_id'");
		$select->execute();
		header("location: index.php");
	}

?>