<html>
	<head>
		<title>Crude Operation Using PDO Connection</title>
		<link rel="stylesheet" type="text/css" href="style.css">
	</head>
	<body>
    <?php

    include('db.php');

    if(isset($_POST['insertdata'])){
        $emp_name = $_POST['emp_name'];
        $emp_id = $_POST['emp_id'];
        $emp_doj = $_POST['emp_doj'];
        $emp_email = $_POST['emp_email'];
        $phone = $_POST['phone'];
        $department = $_POST['department'];

        if(!empty($emp_name) && !empty($emp_id) && !empty($emp_doj) && !empty($emp_email) && !empty($phone) && !empty($department)){
            $stmt = $conn->prepare('INSERT INTO employee(emp_name,emp_id,emp_doj,emp_email,phone,department) VALUES(:emp_name,:emp_id,:emp_doj,:emp_email,:phone,:department)');
            $stmt->bindParam(':emp_name',$emp_name);
            $stmt->bindParam(':emp_id',$emp_id);
            $stmt->bindParam(':emp_doj',$emp_doj);
            $stmt->bindParam(':emp_email',$emp_email);
            $stmt->bindParam(':phone',$phone);
            $stmt->bindParam(':department',$department);
            $stmt->execute();

            if($stmt == 1){
                header("location: index.php");
            }
        }
    }

    ?>
	<div class="form_section">
		
		<form action="" method="post" enctype="multipart/form-data">
			<h2>Add Employee</h2>
			<div>
				<span class="msg">
					<?php if(empty($emp_name)){ echo "<div class='text_color'>Enter Your Name</div>"; } ?>
				</span>
				<input type="text" name="emp_name" value="<?php if(isset($emp_name)){ echo $emp_name; }?>" placeholder="Employee Name">
			</div>
			<div>
				<span class="msg">
					<?php if(empty($emp_id)){ echo "<div class='text_color'>Enter Employee ID</div>"; } ?>
				</span>
				<input type="text" name="emp_id" value="<?php if(isset($emp_id)){ echo $emp_id; }?>" placeholder="Employee ID">
			</div>
			<div>
				<span class="msg">
					<?php if(empty($emp_doj)){ echo "<div class='text_color'>Enter Date of Joining</div>"; } ?>
				</span>
				<input type="text" name="emp_doj" value="<?php if(isset($emp_doj)){ echo $emp_doj; }?>" placeholder="Date of Joining">
			</div>
			<div>
				<span class="msg">
					<?php if(empty($emp_email)){ echo "<div class='text_color'>Enter Email</div>"; } ?>
				</span>
				<input type="text" name="emp_email" value="<?php if(isset($emp_email)){ echo $emp_email; }?>" placeholder="Email ID">
			</div>
			<div>
				<span class="msg">
					<?php if(empty($phone)){ echo "<div class='text_color'>Enter Phone</div>"; } ?>
				</span>
				<input type="text" name="phone" value="<?php if(isset($phone)){ echo $phone; }?>" placeholder="Phone No.">
			</div>
			<div>
				<span class="msg">
					<?php if(empty($department)){ echo "<div class='text_color'>Enter Department</div>"; } ?>
				</span>
				<input type="text" name="department" value="<?php if(isset($department)){ echo $department; }?>" placeholder="Department">
			</div>
			<div><button type="submit" name="insertdata" class="inser_btn">Submit</button></div><br>
		</form>
	</div>


	<!--- View All Employees --->
	<div class="data_section">
		<h2>List of Employee</h2>
		<table border="1">
			<tr>
				<th>SL No.</th>
				<th>Name</th>
				<th>Emp ID</th>
				<th>DOJ</th>
				<th>Email</th>
				<th>Phone</th>
				<th>Department</th>
				<th>Action</th>
			</tr>
		
		<?php 
			$select = $conn->prepare("SELECT * FROM employee");
			$select->setFetchMode(PDO::FETCH_ASSOC);
			$select->execute();
			while($data=$select->fetch()){
		?>
				<tr>
					<td><?php echo $data['id']; ?></td>
					<td><?php echo $data['emp_name']; ?></td>
					<td><?php echo $data['emp_id']; ?></td>
					<td><?php echo $data['emp_doj']; ?></td>
					<td><?php echo $data['emp_email']; ?></td>
					<td><?php echo $data['phone']; ?></td>
					<td><?php echo $data['department']; ?></td>
					<td>
						<a type="button" href="edit.php?edit_id=<?php echo $data['id']; ?>">Edit</a>
						<a type="button" href="delete.php?delete_id=<?php echo $data['id']; ?>">Delete</a>
					</td>
				</tr>
		<?php } ?>
		</table>
	</div>

	</body>
</html>