<?php

$servername = "localhost";
$username = "root";
$password = "Test_pw9";
$dbname = "chandan_crud1";

//connection 

try{
	$conn = new PDO("mysql:host={$servername}; dbname={$dbname}","$username","$password");
	$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(PDOException $e){
	echo $e->getMessage();
}

?>