<?php 
include('db.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

<?php

if(isset($_POST['submit'])){
  $emp_name = $_POST['emp_name'];
  $emp_id = $_POST['emp_id'];
  $emp_doj = $_POST['emp_doj'];
  $emp_email = $_POST['emp_email'];
  $phone = $_POST['phone'];
  $department = $_POST['department'];

  if(!empty($emp_name) && !empty($emp_id) && !empty($emp_doj) && !empty($emp_email) && !empty($phone) && !empty($department)){
    $stmt = $conn->prepare('INSERT INTO employee(emp_name,emp_id,emp_doj,emp_email,phone,department) VALUES(:emp_name,:emp_id,:emp_doj,:emp_email,:phone,:department)');
    $stmt->bindParam(':emp_name',$emp_name);
    $stmt->bindParam(':emp_id',$emp_id);
    $stmt->bindParam(':emp_doj',$emp_doj);
    $stmt->bindParam(':emp_email',$emp_email);
    $stmt->bindParam(':phone',$phone);
    $stmt->bindParam(':department',$department);
    $stmt->execute();

    if($stmt == 1){
      header("location: index.php");
    }
  }
}


?>


<div class="container-fluid">
  <h2 class="text-center"></h2>
  <div class="col-sm-3">
    <form class="form-horizontal" method="post" action="" enctype="multipart/form-data" class="frm">
      <h2 class="text-center">Registration</h2>
      <div class="form-group">
        <label class="control-label" for="emp_name">Employee Name:</label>
          <input type="text" class="form-control" id="emp_name" placeholder="Enter First Name" name="emp_name" value="<?php if(isset($_POST['emp_name'])){ echo $emp_name; } ?>">
      </div>
      <div class="form-group">
        <label class="control-label" for="emp_id">Employee ID:</label>
          <input type="number" class="form-control" id="emp_id" placeholder="Enter First Name" name="emp_id" value="<?php if(isset($_POST['emp_id'])){ echo $emp_id; } ?>">
      </div>
      <div class="form-group">
        <label class="control-label" for="emp_doj">Date of Joining:</label>
          <input type="text" class="form-control" id="emp_doj" placeholder="Enter First Name" name="emp_doj" value="<?php if(isset($_POST['emp_doj'])){ echo $emp_doj; } ?>">
      </div>
      <div class="form-group">
        <label class="control-label" for="emp_email">Email:</label>
          <input type="text" class="form-control" id="emp_email" placeholder="Enter Email" name="emp_email" value="<?php if(isset($_POST['emp_email'])){ echo $emp_email; } ?>">
      </div>
      <div class="form-group">
        <label class="control-label" for="phone">Phone:</label>
          <input type="tel" class="form-control" id="phone" placeholder="Enter Phone Number" name="phone" value="<?php if(isset($_POST['phone'])){ echo $phone; } ?>">
      </div>
      <div class="form-group">
        <label class="control-label" for="department">Department:</label>          
          <input type="department" class="form-control" id="department" placeholder="Enter department" name="department" value="<?php if(isset($_POST['department'])){ echo $department; } ?>">
      </div>
      <div class="form-group">        
        <button type="submit" name="submit" class="btn btn-default">Submit</button>
      </div>
    </form>
  </div>
  <div class="col-sm-9">
    <table class="table">
    <thead>
      <tr class="info active">
        <th>Employee Name</th>
        <th>Employee ID</th>
        <th>Date of Joining</th>
        <th>Email ID</th>
        <th>Phone No.</th>
        <th>Password</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php
        if(isset($_POST['delete'])){
            $delete_id = $_POST['cid'];
            $select = $conn->prepare("DELETE FROM employee where id='$delete_id'");
            $select->execute();
            // header("location: index.php");
          }
      ?>

      <?php 
        $select = $conn->prepare("SELECT * FROM employee");
        $select->setFetchMode(PDO::FETCH_ASSOC);
        $select->execute();
        while($data=$select->fetch()){
      ?>
        <tr class="active">
          <td><?php echo $data['emp_name'] ?></td>
          <td><?php echo $data['emp_id'] ?></td>
          <td><?php echo $data['emp_doj'] ?></td>
          <td><?php echo $data['emp_email'] ?></td>
          <td><?php echo $data['phone'] ?></td>
          <td><?php echo $data['department'] ?></td>
          <td>
            <form action="" method="post">
              <input type="hidden" name="cid" id="id" value="<?php echo $data['id'] ?>">
              <a href="edit.php?cid=<?php echo $data['id']; ?>" title="Edit" name="edit"><span class="glyphicon glyphicon-edit danger"></span></a> 
              <button type="submit" name="delete" title="Delete">
                <span class="glyphicon glyphicon-trash danger"></span>
              </button>
            </form>
          </td>
        </tr>
      <?php } ?>
    </tbody>
  </table>
  </div>
</div>

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</body>
</html>
