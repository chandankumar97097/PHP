-- phpMyAdmin SQL Dump
-- version 4.6.6deb5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Feb 14, 2020 at 01:13 PM
-- Server version: 5.7.29-0ubuntu0.18.04.1
-- PHP Version: 7.2.26-1+ubuntu18.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `chandan_crud`
--

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `id` int(255) NOT NULL,
  `emp_name` varchar(255) NOT NULL,
  `emp_id` int(255) NOT NULL,
  `emp_doj` varchar(255) NOT NULL,
  `emp_email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `department` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`id`, `emp_name`, `emp_id`, `emp_doj`, `emp_email`, `phone`, `department`) VALUES
(4, 'chandan', 12345, '20/02/2019', 'reactdevck@gmail.com', '985652313', '123'),
(5, 'Mukesh', 12345, '09/01/2019', 'mk@gmail.com', '99999988888', '123'),
(6, 'Melissa Navarro', 1232123, '19-Mar-1995', 'cowidyw@mailinator.net', '+1 (854) 233-1866', '123456'),
(11, 'Axel Edwards', 67, '05-Apr-1997', 'hevekyzoj@mailinator.com', '+1 (483) 623-8633', 'Culpa et molestiae e'),
(14, 'Rajah Malone', 8, '06-Sep-1998', 'sezewiqaf@mailinator.com', '+1 (739) 355-5802', 'Suscipit minima volu'),
(15, 'Palmer Parsons', 37, '29-Mar-1982', 'cylypewuhu@mailinator.com', '+1 (489) 722-1186', 'Veritatis et officii'),
(16, 'Alexandra King', 10, '23-Jun-2005', 'janahi@mailinator.net', '+1 (733) 504-9545', 'Nulla eos qui et re');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
