<?php
define('EMAIL','your@gmail.com');
define('PASS','');
?>