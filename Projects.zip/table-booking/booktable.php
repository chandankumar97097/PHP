<?php 

session_start();
include('header.php');
include("includes/db.php");

	if(!(isset ($_SESSION['username'])) && ($_SESSION["password"]=1)){
		echo "<script>window.location.href='login.php'</script>";
	}

?>
	<!-- Title Page -->
	<section class="flex-c-m p-t-160 p-b-80 p-l-15 p-r-15" style="background-image: url(images/bg-title-page-02.jpg);">
		<h2 class="tit6 t-center">
			Reservation
		</h2>
	</section>


	<!-- Reservation -->
	<section class="section-reservation bg1-pattern p-t-60 p-b-60">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 p-b-30">
					<div class="t-center">
						<span class="tit2 t-center">
							Select Your Table
						</span>
						<p><br></p>
						<h5 class="green"><span></span> &nbsp &nbsp &nbsp Available Seats</h5>
						<h5 class="red"><span></span> &nbsp &nbsp &nbsp Booked Seats</h5>
					</div>
					
					<?php 

						if(isset($_GET['update'])){
							
							$sel_customers = "SELECT * FROM reservation WHERE (customer_id='$customer_id' OR email='$email')";
							$run_customers = mysqli_query($con, $sel_customers);
							$check_customers = mysqli_num_rows($run_customers);
							
							$id = $check_customers['id'];
							$email = $check_customers['email'];
							$table = $check_customers['table_number'];
							
						}

					?>
					
					<form class="wrap-form-reservation size22 m-l-r-auto"  action="" method="POST">
						<div class="row">
							<div class="col-md-12">
								<!-- Date -->
								<img src="images/map.jpg" class="table-img">
								<div class="links">
								
									<?php 
										$ids = array();
										$get_customers = "SELECT * FROM reservation";
										$run_customers = mysqli_query($con, $get_customers); 									
										while($row_customers = mysqli_fetch_array($run_customers)){
											$current_date = date("Y-m-d");
											$date = $row_customers['date'];
											
											$inner_ids = explode(',',$row_customers['table_number']);
											$len = count($inner_ids);
											if($len>0){
												for($k=0; $k<$len; $k++ ){
													$ids[] = $inner_ids[$k];
												}
											}
											
										}
										
											$i = 1;
											while ($i < 19) {
												
												if(in_array($i,$ids)){
													echo "
														<a class='t-$i' value='$i' title='Not available' class='s_n'>
															<span>$i</span>
															<input type='checkbox' name='table[]' value='$i' disabled>
														</a>";
												}else{
													echo "
														<a class='t-$i' value='$i' title='Available' class='s_n'>
															<span>$i</span>
															<input type='checkbox' name='table[]' value='$i'>
														</a>";
												}
												  $i++;
											}
											
									
									?>
								
								</div>
							</div>
						</div>
						<p><br></p>
						<div class="wrap-btn-booking flex-c-m m-t-6">
							<!-- Button3 -->
							<input type="submit" class="btn3 flex-c-m size13 txt11 trans-0-4" name="update" value="Select">
							
						</div>
					</form>
					
	<?php 

		if(isset($_POST['update'])){
			$tables = $_GET['update'];
			$customer_session = $_SESSION['username'];
			$get_customer_id = "SELECT * FROM user_login WHERE table_number='$tables'";
			$run_customer = mysqli_query($con, $get_customer_id); 
			$row_customer = mysqli_fetch_array($run_customer); 
			$customer_id = $row_customer['customer_id'];
			
			
			$get_id = "SELECT * FROM reservation WHERE customer_id='$customer_id'";
			$run_c_id = mysqli_query($con, $get_id); 
			$row_c = mysqli_fetch_array($run_c_id);
			$order_id = $row_c['order_id'];
			$updated_table = implode(',', $_POST['table']);
			
			if(!($updated_table == '')){
			
				$update_customer = "UPDATE reservation SET table_number='$updated_table' WHERE email='$customer_session'";
			
				$run_customer = mysqli_query($con, $update_customer);
				
				if($run_customer){
				// Seat details send to the customer
				$details = mysqli_query($con, "SELECT * FROM reservation WHERE email='$customer_session'");
				$row = mysqli_fetch_assoc($details);
				$fetch_customer_email=$row['email'];
				if($fetch_customer_email){
					$to = $fetch_customer_email;
					$subject = "Table Booked!";
					$txt = "You have booked! Name: .$name. Email: .$email. \n Date: .$date. \n Time: .$time. \n Table Number: .$updated_table. \n Number of People: .$number_of_people. \n ";
					$headers = "From: info@test.com";
						mail($to,$subject,$txt,$headers);
				}
				echo "<script>alert('You have successfully booked table number $updated_table');</script>";
				echo "<script>alert('Please Check Your Email');</script>";
				echo "<script>window.open('booktable.php', '_self')</script>";
			}
			}
			else{
				echo "<script>alert('Please select any one table which is available!');</script>";
				echo "<script>window.open('booktable.php', '_self')</script>";
			}
		}
		
	?>
					
				</div>
			</div>

		</div>
	</section>



<?php include('footer.php'); ?>