<?php

session_start();

unset($_SESSION["id"]);
unset($_SESSION["first_name"]);
unset($_SESSION["last_name"]);
unset($_SESSION["username"]);
unset($_SESSION["phone"]);
unset($_SESSION["password"]);

header("location:index.php");

?>