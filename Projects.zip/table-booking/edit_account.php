<?php 

session_start();
include('header.php');
include("includes/db.php");

	if(!(isset ($_SESSION['username'])) && ($_SESSION["username"]=1)){
		echo "<script>window.location.href='index.php'</script>";
	}
	
?>
	<!-- Title Page -->
	<section class="flex-c-m p-t-160 p-b-80 p-l-15 p-r-15" style="background-image: url(images/bg-title-page-02.jpg);">
		<h2 class="tit6 t-center">
			Edit Account
		</h2>
	</section>


	<!-- Reservation -->
	<section class="section-reservation bg1-pattern p-t-80 p-b-80">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 p-b-30">
					<div class="t-center">
						<span class="tit2 t-center">
							Update Account info
						</span>
						
					</div>
					
		<?php 
			
			
				$email = $_SESSION['username'];
				
				$get_customer = "select * from user_login where username='$email'";
				
				$run_customer = mysqli_query($con, $get_customer);
				
				$row=mysqli_fetch_array($run_customer); 
				
				$id = $row['customer_id']; 
				$first_name = $row['first_name']; 
				$last_name = $row['last_name']; 
				$username = $row['username'];
				$phone = $row['phone'];
				$password = $row['password'];
			
			
		?>
			
			<div class="panel panel-primary">
					<div class="panel-body">
							<p><br/></p>
							<form id="" method="post" enctype="multipart/form-data">
								<div class="col-sm-12">
									<label for="customer_name">First Name</label>
									<input type="text" id="first_name" name="first_name" class="form-control" value="<?php echo $first_name; ?>" required>
								</div>
								<div class="col-sm-12">
									<label for="customer_name">Last Name</label>
									<input type="text" id="last_name" name="last_name" class="form-control" value="<?php echo $last_name; ?>" required>
								</div>
								<div class="col-sm-12">
									<label for="customer_email">Email (username or email will be same)</label>
									<input type="email" id="username" name="username" class="form-control"  placeholder="<?php echo $username; ?>" disabled>
								</div>
								<div class="col-sm-12">
									<label for="customer_name">Phone</label>
									<input type="text" id="phone" name="phone" class="form-control" value="<?php echo $phone; ?>" required>
								</div>
								<div class="col-sm-12">
									<label for="customer_pass">Password</label>
									<input type="password" id="password" name="password" class="form-control"  value="<?php echo $password; ?>" required>
								</div>
								<p><br/></p>
								<div class="col-sm-12">
									<input style="width:100%;" value="Update Account" type="submit" name="update_account" class="btn btn-success btn-lg">
								</div>
							
							</form>
					</div>
					<div class="panel-footer"></div>
				</div>
						
	<?php 
	
		if(isset($_POST['update_account'])){
			
				$update_id = $id;
				$updated_first_name = $_POST['first_name']; 
				$updated_last_name = $_POST['last_name']; 
				$updated_phone = $_POST['phone'];
				$updated_password = md5($_POST['password']);
				
			$update_customer = "update user_login set first_name='$updated_first_name', last_name='$updated_last_name', phone='$updated_phone', password='$updated_password' where customer_id='$update_id'";
			
			$run_customer = mysqli_query($con,$update_customer); 
			
			if($run_customer){
				
				echo "<script>alert('Your account has been updated!')</script>";
				echo "<script>window.open('my_account.php','_self')</script>";
				
				}
			}

	?>


					
	
				</div>
			</div>

		</div>
	</section>



<?php include('footer.php'); ?>
