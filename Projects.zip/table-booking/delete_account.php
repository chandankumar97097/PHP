<?php 

session_start();
include('header.php');
include("includes/db.php");

	if(!(isset ($_SESSION['username'])) && ($_SESSION["username"]=1)){
		echo "<script>window.location.href='index.php'</script>";
	}
	
?>
	<!-- Title Page -->
	<section class="flex-c-m p-t-160 p-b-80 p-l-15 p-r-15" style="background-image: url(images/bg-title-page-02.jpg);">
		<h2 class="tit6 t-center">
			Delete Account
		</h2>
	</section>


	<!-- Reservation -->
	<section class="section-reservation bg1-pattern p-t-80 p-b-80">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 p-b-30">
					<div class="t-center">
						<span class="tit2 t-center">
							Delete Account
						</span>
						
					</div>
					<p><br/></p>
					<div class="container">
		
						<div class="col-sm-12 center">
							<form action="" method="post">
								<h4>Do you really want to delete your account?</h4>
								<input type="submit" name="yes" class="yes" value="Yes" />
								<input type="submit" name="no" class="no" value="No" />
							</form>
						</div>
						<?php 

						$customer_email = $_SESSION['username'];

							if(isset($_POST['yes'])){
								
								$delete_customer = "DELETE FROM user_login WHERE username='$customer_email'";
								$run_delete = mysqli_query($con, $delete_customer); 
								
								if($run_delete){
									
									session_destroy();
									
									echo "<script>alert('Your Account has been deleted, Good Bye!')</script>";
									echo "<script>window.open('index.php','_self')</script>";
									}
								
								}
								
								if(isset($_POST['no'])){
									
									echo "<script>window.open('my_account.php','_self')</script>";
									
									
									}
									
						?>

					</div>
	
				</div>
			</div>

		</div>
	</section>



<?php include('footer.php'); ?>
