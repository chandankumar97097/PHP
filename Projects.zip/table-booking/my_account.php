<?php 

session_start();
include('header.php');
include("includes/db.php");

	if(!(isset ($_SESSION['username'])) && ($_SESSION["username"]=1)){
		echo "<script>window.location.href='index.php'</script>";
	}
	
?>
	<!-- Title Page -->
	<section class="flex-c-m p-t-160 p-b-80 p-l-15 p-r-15" style="background-image: url(images/bg-title-page-02.jpg);">
		<h2 class="tit6 t-center">
			My Account
		</h2>
	</section>


	<!-- Reservation -->
	<section class="section-reservation bg1-pattern p-t-80 p-b-80">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 p-b-30">
					<div class="t-center">
						<p><br /></p>
						<div class="customer_info">
						<?php 
			
							$email = $_SESSION['username'];
							
							$get_customer = "select * from user_login where username='$email'";
							
							$run_customer = mysqli_query($con, $get_customer);
							
							$row=mysqli_fetch_array($run_customer); 
							
							$first_name = $row['first_name']; 
							$last_name = $row['last_name']; 
							$username = $row['username'];
							$phone = $row['phone'];
						
						
						?>
							<span class="tit2 t-center">
								Welcome <?php echo $first_name; ?> <?php echo $last_name; ?>
							</span>
						
							<h5>Email ID: <?php echo $username; ?></h5>
							<h5>Phone: <?php echo $phone; ?></h5>
						</div>
						<p><br /></p>
						<ul class="account-btn">
							<li><a href="order.php">Tables Details</a></li>
							<li><a href="booktable.php">View Tables</a></li>
							<li><a href="edit_account.php">Edit Account</a></li>
							<li><a href="delete_account.php">Delete Account</a></li>
						</ul>
					</div>

					
	
				</div>
			</div>

		</div>
	</section>



<?php include('footer.php'); ?>
