<?php 

include('header.php');


?>

<!-- Slide1 -->
	<section class="section-slide">
		<div class="wrap-slick1">
			<div class="slick1">
			
				<?php 
					$get_slider = "select * from slider";
					$run_slider = mysqli_query($con, $get_slider);
					$i = 1;
					while($row_slider = mysqli_fetch_array($run_slider)){ 
						$heading = $row_slider['heading'];
						$sub_heading = $row_slider['sub_heading'];
						$button_txt = $row_slider['button_txt'];
						$button_link = $row_slider['button_link'];
						$image = $row_slider['image'];
						$i++;
				?>	
				<div class="item-slick1 item1-slick1" style="background-image: url('images/<?php echo $image; ?>');">
					<div class="wrap-content-slide1 sizefull flex-col-c-m p-l-15 p-r-15 p-t-150 p-b-170">
						<span class="caption1-slide1 txt1 t-center animated visible-false m-b-15" data-appear="fadeInDown">
							<?php echo $heading; ?>
						</span>

						<h2 class="caption2-slide1 tit1 t-center animated visible-false m-b-37" data-appear="fadeInUp">
							<?php echo $sub_heading; ?>
						</h2>

						<div class="wrap-btn-slide1 animated visible-false" data-appear="zoomIn">
							<!-- Button1 -->
							<a href="<?php echo $button_link; ?>" class="btn1 flex-c-m size1 txt3 trans-0-4">
								<?php echo $button_txt; ?>
							</a>
						</div>
					</div>
				</div>
				<?php } ?>
				
			</div>
			<div class="wrap-slick1-dots"></div>
		</div>
	</section>


<?php include('footer.php'); ?>