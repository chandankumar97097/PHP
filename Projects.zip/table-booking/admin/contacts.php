<?php 

session_start();
include('header.php'); 
include("../includes/db.php");

	if(!(isset ($_SESSION['username'])) && ($_SESSION["password"]=1)){
		header("location:login.php");
	}
 ?>

			<div class="main-content">
				<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="index.php">Home</a>
							</li>
							<li class="active">Contacts</li>
						</ul><!-- /.breadcrumb -->
					</div>
					<div class="page-content">
						<div class="page-header">
							<h1>
								All Contacts
							</h1>
						</div><!-- /.page-header -->
					</div>
						<main class="app-content">
							<div class="col-sm-10 col-sm-offset-1">
							  <div class="tile">
								<table border="2" width="100%">
									<tr align="center">
										<th>S.N</th>
										<th>Name</th>
										<th>Email</th>
										<th>Image</th>
										<th>Message</th>
										<th>Remove Customers</th>
									</tr>
									<?php 
										$get_c = "select * from contact_form";
										$run_c = mysqli_query($con, $get_c); 
										$i=0;
										while($row_c=mysqli_fetch_array($run_c)){
											$c_id = $row_c['customer_id'];
											$c_name = $row_c['name'];
											$c_email = $row_c['email'];
											$c_phone = $row_c['phone'];
											$c_message = $row_c['message'];
											$i++;
									?>
									<tr align="center">
										<td><?php echo $i; ?></td>
										<td><?php echo $c_name; ?></td>
										<td><?php echo $c_email; ?></td>
										<td><?php echo $c_phone; ?></td>
										<td><?php echo $c_message; ?></td>
										<td><a href="contacts.php?delete_c=<?php echo $c_id; ?>">Delete</a></td>
									</tr>
									<?php } ?>
								
								</table>
							  </div>
							</div>
						  </div>
						</main>
						
					<?php 
						if(isset($_GET['delete_c'])){
								
							$delete_id = $_GET['delete_c'];
							$delete_c = "delete from contact_form where customer_id='$delete_id'";
							$run_delete = mysqli_query($con, $delete_c);
							
							if($run_delete){
								echo "<script>alert('Customer has been deleted!')</script>";
								echo "<script>window.open('contacts.php','_self')</script>";
							}
						}
					?>	
						
						
						
					</div>
					</div>
				
			
<?php include('footer.php'); ?>
