<?php 

session_start();
include('header.php'); 
include("../includes/db.php");

	if(!(isset ($_SESSION['username'])) && ($_SESSION["password"]=1)){
		header("location:login.php");
	}
 ?>


			<div class="main-content">
				<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="index.php">Home</a>
							</li>
							<li class="active">Edit Menu</li>
						</ul><!-- /.breadcrumb -->
					</div>

					<div class="page-content">
						<div class="page-header">
							<h1>
								Update Menu
							</h1>
						</div><!-- /.page-header -->
							<?php 
							
							if(isset($_GET['edit_menu'])){
								$id = $_GET['edit_menu'];
								$get_c = "select * from menu where menu_id='$id'";
								$run_c = mysqli_query($con, $get_c); 
								$row_c=mysqli_fetch_array($run_c);
									$menu_name = $row_c['menu_name'];
									$menu_link = $row_c['menu_link'];
									
							}
							?>
							<form action="" method="post">
								<label class="control-label no-padding-right" for="form-field-1"> 
									Update Menu:
								</label>
								<div class="form-group">
									<div class="col-sm-9 mt10">
										<input type="text" name="menu_name" placeholder="Menu Name" value="<?php echo $menu_name; ?>" class="col-xs-10 col-sm-5"/>
									</div>
									<div class="col-sm-9 mt10">
										<input type="text" name="menu_link" placeholder="Menu Link" value="<?php echo $menu_link; ?>" class="col-xs-10 col-sm-5"/>
									</div>
									
									<div class="col-sm-12 mt-10" style="float:right">
										<button type="submit" name="update_menu" class="btn btn-sm btn-success" >Update Menu
											<i class="ace-icon fa fa-arrow-right icon-on-right bigger-110"></i>
										</button>
									</div>
								</div>
							</form>
							
						<?php 
								if(isset($_POST['update_menu'])){
									$menu_name = $_POST['menu_name'];
									$menu_link = $_POST['menu_link'];
									
									if($menu_name=='' OR $menu_link==''){
			
										echo "<script>alert('Please Enter the Menu Name!')</script>";
										exit();
									
									}else {
										
									$update_menu = "update menu set menu_name='$menu_name', menu_link='$menu_link' where menu_id='$id'";
										
									$run_menu = mysqli_query($con, $update_menu);
										
									if($run_menu){
										echo "<script>alert('Menu Updated!')</script>";
										echo "<script>window.open('menu.php','_self')</script>";
										}
									}
								}
							?>
						
					</div><!-- /.col -->
						</div><!-- /.row -->
					</div><!-- /.page-content -->
				</div>
			</div><!-- /.main-content -->

			
<?php include('footer.php'); ?>
