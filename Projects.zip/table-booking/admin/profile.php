<?php 

session_start();
include('header.php'); 
include("../includes/db.php");

	if(!(isset ($_SESSION['username'])) && ($_SESSION["password"]=1)){
		header("location:login.php");
	}
 ?>


			<div class="main-content">
				<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="index.php">Home</a>
							</li>
							<li class="active">Profile</li>
						</ul><!-- /.breadcrumb -->
					</div>

					<div class="page-content">
						<div class="page-header">
							<h1>
								Admin Area
							</h1>
						</div><!-- /.page-header -->
						
						<main class="app-content">
							<div class="col-sm-12">
								<?php 
									$get_c = "select * from admin_login";
									$run_c = mysqli_query($con, $get_c); 
									while($row_c=mysqli_fetch_array($run_c)){
										$username = $row_c['username'];
										$email = $row_c['email'];
										$password = $row_c['password'];
									?>
								<p>Username: <?php echo $username; ?></p>
								<p>Email ID: <?php echo $email; ?></p>
								<p>Password: <?php echo $password; ?></p>
								<?php } ?>
							</div>
						</main>
						
						<div class="col-sm-12">
							<h4>Change Email & Password</h4>
							<a href="change_email.php">Edit Account</a>
						</div>
						
					</div><!-- /.col -->
						</div><!-- /.row -->
					</div><!-- /.page-content -->
				</div>
			</div><!-- /.main-content -->

			
<?php include('footer.php'); ?>
