<?php 

session_start();
include('header.php'); 
include("../includes/db.php");

	if(!(isset ($_SESSION['username'])) && ($_SESSION["password"]=1)){
		header("location:login.php");
	}
 ?>


			<div class="main-content">
				<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="index.php">Home</a>
							</li>
							<li class="active">Menu</li>
						</ul><!-- /.breadcrumb -->
					</div>

					<div class="page-content">
						<div class="page-header">
							<h1>
								All Menu
							</h1>
						</div><!-- /.page-header -->
						
						<main class="app-content">
							<div class="col-sm-4">
								<ul class="main_menu">
								<?php 
									$get_menu = "select * from menu";
									$run_menu = mysqli_query($con, $get_menu); 
									while($row_menu=mysqli_fetch_array($run_menu)){
										$menu_id = $row_menu['menu_id'];
										$menu_name = $row_menu['menu_name'];
										
								?>
								
									<li><?php echo $menu_name; ?> <a href="menu.php?delete_menu=<?php echo $menu_id; ?>" class="delete">Delete</a> &nbsp <a href="edit_menu.php?edit_menu=<?php echo $menu_id; ?>">Edit</a></li>
								
								<?php } ?>
								
								<?php 
									if(isset($_GET['delete_menu'])){
										$d_id = $_GET['delete_menu'];
										$delete_menu = "delete from menu where menu_id='$d_id'";
										$run_menu = mysqli_query($con, $delete_menu);		
											if($run_menu){
												echo "<script>alert('Menu Deleted!')</script>";
												echo "<script>window.open('menu.php','_self')</script>";
											}
									}
								?>
								</ul>
							</div>
						</main>
						
					</div><!-- /.col -->
						</div><!-- /.row -->
					</div><!-- /.page-content -->
				</div>
			</div><!-- /.main-content -->

			
<?php include('footer.php'); ?>
