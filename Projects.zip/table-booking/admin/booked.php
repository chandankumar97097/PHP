<?php 

session_start();
include('header.php'); 
include("../includes/db.php");

	if(!(isset ($_SESSION['username'])) && ($_SESSION["password"]=1)){
		echo "<script>window.location.href='login.php'</script>";
	}
 ?>

			<div class="main-content">
				<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="index.php">Home</a>
							</li>
							<li class="active">Booked</li>
						</ul><!-- /.breadcrumb -->
					</div>
					<div class="page-content">
						<div class="page-header">
							<h1>
								Reserved Tables
							</h1>
						</div><!-- /.page-header -->
					</div>
						<main class="app-content">
							<div class="col-sm-10 col-sm-offset-1">
							  <div class="tile">
								<table border="2" width="100%">
									<tr align="center">
										<th>Order ID</th>
										<th>Name</th>
										<th>Email</th>
										<th>No. of People</th>
										<th>Date</th>
										<th>Time</th>
										<th>Table No.</th>
										<th>Action</th>
										<th>Status</th>
									</tr>
									<?php 
										$get_c = "select * from reservation";
										$run_c = mysqli_query($con, $get_c); 
										while($row_c=mysqli_fetch_array($run_c)){
											$c_id = $row_c['customer_id'];
											$c_ord_id = $row_c['order_id'];
											$c_name = $row_c['name'];
											$c_email = $row_c['email'];
											$c_no_people = $row_c['number_of_people'];
											$c_date = $row_c['date'];
											$c_time = $row_c['time'];
											$c_table_no = $row_c['table_number'];
											$status = $row_c['status'];
											
									?>
									<tr align="center">
										<td><?php echo $c_ord_id; ?></td>
										<td><?php echo $c_name; ?></td>
										<td><?php echo $c_email; ?></td>
										<td><?php echo $c_no_people; ?></td>
										<td><?php echo $c_date; ?></td>
										<td><?php echo $c_time; ?></td>
										<td><?php echo $c_table_no; ?></td>
										<td><a href="edit_order.php?edit_order=<?php echo $c_ord_id; ?>">Edit Customer</a></td>
										<td><?php echo $status; ?></td>
									</tr>
									<?php } ?>
								
								</table>
							  </div>
							</div>
						  </div>
						</main>
						
					<?php 
						if(isset($_GET['delete_c'])){
							
							$delete_id = $_GET['delete_c'];
							$delete_c = "delete from reservation where order_id='$delete_id'";
							$run_delete = mysqli_query($con, $delete_c);
							
							if($run_delete){
								echo "<script>alert('Order has been deleted!')</script>";
								echo "<script>window.open('booked.php','_self')</script>";
							}
						}
					?>	
						
						
						
					</div>
					</div>
				
			
<?php include('footer.php'); ?>
