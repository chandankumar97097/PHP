<?php 

session_start();
include('header.php'); 
include("../includes/db.php");

	if(!(isset ($_SESSION['username'])) && ($_SESSION["password"]=1)){
		echo "<script>window.location.href='login.php'</script>";
	}
 ?>

			<div class="main-content">
				<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="index.php">Home</a>
							</li>
							<li class="active">Contact Us</li>
						</ul><!-- /.breadcrumb -->
					</div>
					<div class="page-content">
						<div class="page-header">
							<h1>
								Add Contents (Google Map Iframe Script / Address / Phone / Openign Time)
							</h1>
						</div><!-- /.page-header -->
					</div>
					<div class="container">
					<div class="panel panel-primary">
					<div class="panel-body">
					<p><br/></p>
					<?php 
						$get_map = "select * from contact_page";
						$run_map = mysqli_query($con, $get_map); 
						$row_map = mysqli_fetch_array($run_map); 
							$map = $row_map['map'];
							$address = $row_map['address'];
							$phone = $row_map['phone'];
							$time = $row_map['time'];
					?>
					<form action="" method="post" enctype="multipart/form-data">
						<label class="control-label no-padding-right" for="form-field-1"> 
							Add Google Map Script
						</label>
						<div class="row">
							<div class="col-sm-6 mt-10">
								<textarea class="form-control" name="map" placeholder="Add Map Iframe" rows="8" cols="80">
									<?php echo $map; ?>
								</textarea>
							</div>
							<div class="col-sm-6 mt-10">
								<input type="text" name="address" value="<?php echo $address; ?>" placeholder="Add Location" class=""/ required>
							</div>
							<div class="col-sm-6 mt-10">
								<input type="text" name="phone" value="<?php echo $phone; ?>" placeholder="Add Contact" class=""/ required>
							</div>
							<div class="col-sm-6 mt-10">
								<input type="text" name="time" value="<?php echo $time; ?>" placeholder="Opening Hours" class=""/ required>
							</div>
							<div class="col-sm-6 mt-10" style="float:right">
								<p></p>
								<button type="submit" name="update_contact_us" class="btn btn-sm btn-success" >Update Contact Page
									<i class="ace-icon fa fa-arrow-right icon-on-right bigger-110"></i>
								</button>
							</div>
						</div>
					</form>
							
							<?php 
								if(isset($_POST['update_contact_us'])){
									$u_map = $_POST['map'];
									$u_address = $_POST['address'];
									$u_phone = $_POST['phone'];
									$u_time = $_POST['time'];
									
										$update_contact = "update contact_page set map='$u_map',address='$u_address',phone='$u_phone',time='$u_time'";
										$run_contact = mysqli_query($con, $update_contact);
										
										if($run_contact){
											echo "<script>alert('Contact Information updated!')</script>";
											echo "<script>window.open('contact_us.php','_self')</script>";
										}
								}
								
							?>
					</div>
					<div class="panel-footer"></div>
					</div>
					</div>	
					</div>
					</div>
				
			
<?php include('footer.php'); ?>
