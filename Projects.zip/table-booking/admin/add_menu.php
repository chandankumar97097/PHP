<?php 

session_start();
include('header.php'); 
include("../includes/db.php");

	if(!(isset ($_SESSION['username'])) && ($_SESSION["password"]=1)){
		header("location:login.php");
	}
 ?>


			<div class="main-content">
				<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="index.php">Home</a>
							</li>
							<li class="active">Add Menu</li>
						</ul><!-- /.breadcrumb -->
					</div>

					<div class="page-content">
						<div class="page-header">
							<h1>
								Add Menu
							</h1>
						</div><!-- /.page-header -->
							
							<form action="" method="post">
								<label class="control-label no-padding-right" for="form-field-1"> 
									Add New Menu:
								</label>
								<div class="form-group">
									<div class="col-sm-9 mt10">
										<input type="text" name="menu_name" placeholder="Menu Name" class="col-xs-10 col-sm-5"/>
									</div>
									<div class="col-sm-9 mt10">
										<input type="text" name="menu_link" placeholder="Menu Link" class="col-xs-10 col-sm-5"/>
									</div>
									
									<div class="col-sm-12 mt-10" style="float:right">
										<button type="submit" name="add_menu" class="btn btn-sm btn-success" >Add Menu
											<i class="ace-icon fa fa-arrow-right icon-on-right bigger-110"></i>
										</button>
									</div>
								</div>
							</form>
							
						<?php 
								if(isset($_POST['add_menu'])){
									$menu_name = $_POST['menu_name'];
									$menu_link = $_POST['menu_link'];
									
									if($menu_name=='' OR $menu_link==''){
			
										echo "<script>alert('Please Enter the Menu Name!')</script>";
										exit();
									
									}else {
										
									$insert_menu = "insert into menu (menu_name, menu_link) values ('$menu_name', '$menu_link')";
										
									$run_menu = mysqli_query($con, $insert_menu);
										
									if($run_menu){
										echo "<script>alert('Menu Added!')</script>";
										echo "<script>window.open('add_menu.php','_self')</script>";
										}
									}
								}
							?>
						
					</div><!-- /.col -->
						</div><!-- /.row -->
					</div><!-- /.page-content -->
				</div>
			</div><!-- /.main-content -->

			
<?php include('footer.php'); ?>
