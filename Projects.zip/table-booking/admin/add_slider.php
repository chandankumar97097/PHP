<?php 

session_start();
include('header.php'); 
include("../includes/db.php");

	if(!(isset ($_SESSION['username'])) && ($_SESSION["password"]=1)){
		echo "<script>window.location.href='login.php'</script>";
	}
 ?>

			<div class="main-content">
				<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="index.php">Home</a>
							</li>
							<li class="active">Add Slider</li>
						</ul><!-- /.breadcrumb -->
					</div>
					<div class="page-content">
						<div class="page-header">
							<h1>
								Add New Slides
							</h1>
						</div><!-- /.page-header -->
					</div>
					<div class="container">
					<div class="panel panel-primary">
					<div class="panel-body">
							<p><br/></p>
						<form action="" method="post" enctype="multipart/form-data">
								<label class="control-label no-padding-right" for="form-field-1"> 
									Add Slides
								</label>
								<div class="row">
									<div class="col-sm-6 mt-10">
										<input type="text" name="heading" placeholder="Heading" class=""/ required>
									</div>
									<div class="col-sm-6 mt-10">
										<input type="text" name="sub_heading" placeholder="Sub Heading" class=""/ required>
									</div>
									<div class="col-sm-6 mt-10">
										<input type="text" name="button_txt" placeholder="Button Text" class=""/ required>
									</div>
									<div class="col-sm-6 mt-10">
										<input type="text" name="button_link" placeholder="Button Link" class=""/ required>
									</div>
									<div class="col-sm-6 mt-10">
										<label>Add Image</label>
										<input type="file" name="slider_images" class=""/ required>
									</div>
									
									<div class="col-sm-6 mt-10" style="float:right">
										<p></p>
										<button type="submit" name="add_slide" class="btn btn-sm btn-success" >Add Slider
											<i class="ace-icon fa fa-arrow-right icon-on-right bigger-110"></i>
										</button>
									</div>
								</div>
							</form>
							
							<?php 
								if(isset($_POST['add_slide'])){
									$heading = $_POST['heading'];
									$s_heading = $_POST['sub_heading'];
									$btn_txt = $_POST['button_txt'];
									$btn_lnk = $_POST['button_link'];
									$s_img = $_FILES['slider_images']['name'];
									$temp_name = $_FILES['slider_images']['tmp_name'];
									
										move_uploaded_file($temp_name,"../images/$s_img");
									
										$insert_slide = "insert into slider (heading,sub_heading,button_txt,button_link,image) values ('$heading','$s_heading','$btn_txt','$btn_lnk','$s_img')";
											
										$run_slide = mysqli_query($con, $insert_slide);
											
										if($run_slide){
											echo "<script>alert('Slide Added!')</script>";
											echo "<script>window.open('add_slider.php','_self')</script>";
										}
								}
								
							?>
					</div>
					<div class="panel-footer"></div>
					</div>
					</div>	
					</div>
					</div>
				
			
<?php include('footer.php'); ?>
