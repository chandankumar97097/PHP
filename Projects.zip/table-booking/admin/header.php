<!DOCTYPE html>
<html lang="en">
	<head>
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
		<meta charset="utf-8" />
		<title>Login - Restaurent Table Booking</title>
		<meta name="description" content="overview &amp; stats" />
		<meta name="description" content="User login page" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />
		<link rel="stylesheet" href="assets/css/bootstrap.min.css" />
		<link rel="stylesheet" href="assets/font-awesome/4.5.0/css/font-awesome.min.css" />
		<link rel="stylesheet" href="assets/css/fonts.googleapis.com.css" />
		<link rel="stylesheet" href="assets/css/ace.min.css" class="ace-main-stylesheet" id="main-ace-style" />
		<link rel="stylesheet" href="assets/css/ace-skins.min.css" />
		<link rel="stylesheet" href="assets/css/ace-rtl.min.css" />
		<link rel="stylesheet" href="assets/css/main.css" />
		<script src="assets/js/ace-extra.min.js"></script>
	</head>
	
	
	<body class="no-skin">
		<div id="navbar" class="navbar navbar-default ace-save-state">
			<div class="navbar-container ace-save-state" id="navbar-container">
				<button type="button" class="navbar-toggle menu-toggler pull-left" id="menu-toggler" data-target="#sidebar">
					<span class="sr-only">Toggle sidebar</span>

					<span class="icon-bar"></span>

					<span class="icon-bar"></span>

					<span class="icon-bar"></span>
				</button>

				<div class="navbar-header pull-left">
					<a href="index.php" class="navbar-brand">
						<small>
							<i class="fa fa-leaf"></i>
							Restaurent Admin
						</small>
					</a>
				</div>

				<div class="navbar-buttons navbar-header pull-right" role="navigation">
					<ul class="nav ace-nav">
						<li class="light-blue dropdown-modal">
							<a data-toggle="dropdown" href="#" class="dropdown-toggle">
								<img class="nav-user-photo" src="assets/images/avatars/user.jpg" alt="Admin Photo" />
								<span class="user-info">
									<small>Welcome,</small>
									Admin
								</span>

								<i class="ace-icon fa fa-caret-down"></i>
							</a>

							<ul class="user-menu dropdown-menu-right dropdown-menu dropdown-yellow dropdown-caret dropdown-close">
								
								<li>
									<a href="profile.php">
										<i class="ace-icon fa fa-user"></i>
										Profile
									</a>
								</li>

								<li class="divider"></li>

								<li>
									<a href="logout.php">
										<i class="ace-icon fa fa-power-off"></i>
										Logout
									</a>
								</li>
							</ul>
						</li>
					</ul>
				</div>
			</div><!-- /.navbar-container -->
		</div>
		
		

		<div class="main-container ace-save-state" id="main-container">
			
			<div id="sidebar" class="sidebar responsive ace-save-state">
				
				<ul class="nav nav-list">
					<li class="active">
						<a href="#" class="dropdown-toggle">
							<i class="menu-icon fa fa-tachometer"></i>
							<span class="menu-text"> Dashboard </span>
							<b class="arrow fa fa-angle-down"></b>
						</a>
						<b class="arrow"></b>
						<ul class="submenu">
							<li>
								<a href="../index.php" target="_blank">
									<i class="menu-icon fa fa-caret-right"></i>
									Visit Site
								</a>
								<b class="arrow"></b>
							</li>
						</ul>
					</li>

					<li>
						<a href="#" class="dropdown-toggle">
							<i class="menu-icon fa fa-book"></i>
							<span class="menu-text"> Header </span>
							<b class="arrow fa fa-angle-down"></b>
						</a>
						<b class="arrow"></b>
						<ul class="submenu">
							<li>
								<a href="logo.php">
									<i class="menu-icon fa fa-caret-right"></i>
									Logo
								</a>
								<b class="arrow"></b>
							</li>
							<li>
								<a href="menu.php">
									<i class="menu-icon fa fa-caret-right"></i>
									All Menu
								</a>
								<b class="arrow"></b>
							</li>
							<li>
								<a href="add_menu.php">
									<i class="menu-icon fa fa-caret-right"></i>
									Add Menu
								</a>
								<b class="arrow"></b>
							</li>
						</ul>
					</li>
					<li>
						<a href="#" class="dropdown-toggle">
							<i class="menu-icon fa fa-book"></i>
							<span class="menu-text"> Footer </span>
							<b class="arrow fa fa-angle-down"></b>
						</a>
						<b class="arrow"></b>
						<ul class="submenu">
							<li>
								<a href="copyright.php">
									<i class="menu-icon fa fa-caret-right"></i>
									Copyright
								</a>
								<b class="arrow"></b>
							</li>
						</ul>
					</li>
					<li>
						<a href="#" class="dropdown-toggle">
							<i class="menu-icon fa fa-facebook-square"></i>
							<span class="menu-text"> Social Media </span>
							<b class="arrow fa fa-angle-down"></b>
						</a>
						<b class="arrow"></b>
						<ul class="submenu">
							<li>
								<a href="social_media.php">
									<i class="menu-icon fa fa-caret-right"></i>
									Social Media
								</a>
								<b class="arrow"></b>
							</li>
							<li>
								<a href="add_social.php">
									<i class="menu-icon fa fa-caret-right"></i>
									Add Social Media
								</a>
								<b class="arrow"></b>
							</li>
						</ul>
					</li>
					<li>
						<a href="#" class="dropdown-toggle">
							<i class="menu-icon fa fa-slideshare"></i>
							<span class="menu-text"> Slider </span>
							<b class="arrow fa fa-angle-down"></b>
						</a>
						<b class="arrow"></b>
						<ul class="submenu">
							<li>
								<a href="slider.php">
									<i class="menu-icon fa fa-caret-right"></i>
									All Slides
								</a>
								<b class="arrow"></b>
							</li>
							<li>
								<a href="add_slider.php">
									<i class="menu-icon fa fa-caret-right"></i>
									Add New Slide
								</a>
								<b class="arrow"></b>
							</li>
						</ul>
					</li>
					<li>
						<a href="javascript:void();" class="dropdown-toggle">
							<i class="menu-icon fa fa-pencil-square-o"></i>
							<span class="menu-text"> Customers Info </span>
							<b class="arrow fa fa-angle-down"></b>
						</a>

						<b class="arrow"></b>

						<ul class="submenu">
							<li class="">
								<a href="customers.php">
									<i class="menu-icon fa fa-caret-right"></i>
									View Customers
								</a>
								<b class="arrow"></b>
							</li>
							<li class="">
								<a href="booked.php">
									<i class="menu-icon fa fa-caret-right"></i>
									View Booked Tables
								</a>
								<b class="arrow"></b>
							</li>
						</ul>
					</li>

					<li>
						<a href="contacts.php">
							<i class="menu-icon fa fa-users"></i>
							<span class="menu-text">
								Contacts 
								<span class="badge badge-transparent tooltip-error" title="Customer Emails">
									<i class="ace-icon fa fa-exclamation-triangle red bigger-130"></i>
								</span>
							</span>
						</a>
						<b class="arrow"></b>
					</li>
					<li>
						<a href="contact_us.php">
							<i class="menu-icon fa fa-file-text"></i>
							<span class="menu-text">
								Contact Page 
							</span>
						</a>
						<b class="arrow"></b>
					</li>
					
				</ul><!-- /.nav-list -->

				<div class="sidebar-toggle sidebar-collapse" id="sidebar-collapse">
					<i id="sidebar-toggle-icon" class="ace-icon fa fa-angle-double-left ace-save-state" data-icon1="ace-icon fa fa-angle-double-left" data-icon2="ace-icon fa fa-angle-double-right"></i>
				</div>
			</div>