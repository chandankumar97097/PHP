<?php 

session_start();
include('header.php'); 
include("../includes/db.php");

	if(!(isset ($_SESSION['username'])) && ($_SESSION["password"]=1)){
		header("location:login.php");
	}
 ?>


			<div class="main-content">
				<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="index.php">Home</a>
							</li>
							<li class="active">Social Media</li>
						</ul><!-- /.breadcrumb -->
					</div>

					<div class="page-content">
						<div class="page-header">
							<h1>
								All Social Media
							</h1>
						</div><!-- /.page-header -->
						
						<main class="app-content">
							<div class="col-sm-4">
								<ul class="main_menu">
								<?php 
									$get_social = "select * from social_media";
									$run_social = mysqli_query($con, $get_social); 
									while($row_social=mysqli_fetch_array($run_social)){
										$social_id = $row_social['social_id'];
										$social_icon = $row_social['s_icon'];
										$social_link = $row_social['s_link'];
										
								?>
								
									<li><i class="<?php echo $social_icon; ?>"></i> <a href="social_media.php?delete_social=<?php echo $social_id; ?>" class="delete">Delete</a> &nbsp <a href="edit_social.php?edit_social=<?php echo $social_id; ?>">Edit</a></li>
								
								<?php } ?>
								
								<?php 
									if(isset($_GET['delete_social'])){
										$d_id = $_GET['delete_social'];
										$delete_social = "delete from social_media where social_id='$d_id'";
										$run_social = mysqli_query($con, $delete_social);		
											if($run_social){
												echo "<script>alert('Social Media Deleted!')</script>";
												echo "<script>window.open('social_media.php','_self')</script>";
											}
									}
								?>
								</ul>
							</div>
						</main>
						
					</div><!-- /.col -->
						</div><!-- /.row -->
					</div><!-- /.page-content -->
				</div>
			</div><!-- /.main-content -->

			
<?php include('footer.php'); ?>
