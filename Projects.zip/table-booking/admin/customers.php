<?php 

session_start();
include('header.php'); 
include("../includes/db.php");

	if(!(isset ($_SESSION['username'])) && ($_SESSION["password"]=1)){
		echo "<script>window.location.href='login.php'</script>";
	}
 ?>

			<div class="main-content">
				<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="index.php">Home</a>
							</li>
							<li class="active">Customers</li>
						</ul><!-- /.breadcrumb -->
					</div>
					<div class="page-content">
						<div class="page-header">
							<h1>
								All Customers
							</h1>
						</div><!-- /.page-header -->
					</div>
						<main class="app-content">
							<div class="col-sm-10 col-sm-offset-1">
							  <div class="tile">
								<table border="2" width="100%" align="center">
									<tr align="center">
										<th align="center">S.N</th>
										<th>First Name</th>
										<th>Last Name</th>
										<th>Email</th>
										<th>Message</th>
										<th>Remove Customers</th>
									</tr>
									<?php 
										$get_c = "select * from user_login";
										$run_c = mysqli_query($con, $get_c); 
										$i=0;
										while($row_c=mysqli_fetch_array($run_c)){
											$c_id = $row_c['customer_id'];
											$c_fname = $row_c['first_name'];
											$c_lname = $row_c['last_name'];
											$c_email = $row_c['username'];
											$c_phone = $row_c['phone'];
											$i++;
									?>
									<tr align="center">
										<td><?php echo $i; ?></td>
										<td><?php echo $c_fname; ?></td>
										<td><?php echo $c_lname; ?></td>
										<td><?php echo $c_email; ?></td>
										<td><?php echo $c_phone; ?></td>
										<td><a href="customers.php?delete_c=<?php echo $c_id; ?>">Delete</a></td>
									</tr>
									<?php } ?>
								
								</table>
							  </div>
							</div>
						  </div>
						</main>
						
					<?php 
						if(isset($_GET['delete_c'])){
							
							$delete_id = $_GET['delete_c'];
							$delete_c = "delete from user_login where customer_id='$delete_id'";
							$run_delete = mysqli_query($con, $delete_c);
							
							if($run_delete){
								echo "<script>alert('Customer has been deleted!')</script>";
								echo "<script>window.open('customers.php','_self')</script>";
							}
						}
					?>	
						
						
						
					</div>
					</div>
				
			
<?php include('footer.php'); ?>
