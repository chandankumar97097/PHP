<?php 

session_start();
include('header.php'); 
include("../includes/db.php");

	if(!(isset ($_SESSION['username'])) && ($_SESSION["password"]=1)){
		header("location:login.php");
	}
 ?>

			<div class="main-content">
				<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="index.php">Home</a>
							</li>
							<li class="active">Change Email</li>
						</ul><!-- /.breadcrumb -->
					</div>

					<div class="page-content">
						<div class="page-header">
							<h1>
								Admin Area
							</h1>
						</div><!-- /.page-header -->
						<div class="col-sm-9">
						<?php 
							$get_c = "select * from admin_login";
							$run_c = mysqli_query($con, $get_c); 
							while($row_c=mysqli_fetch_array($run_c)){
								$username = $row_c['username'];
								$password = $row_c['password'];
						?>
							<form action="" method="post">
								<div class="form-group">
									<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> 
										Email ID:
									</label>

									<div class="col-sm-9 mt10">
										<input type="text" name="username" value="<?php echo $username; ?>" placeholder="Username" class="col-xs-10 col-sm-5" required/>
									</div>
									
									<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> 
										Password:
									</label>

									<div class="col-sm-9 mt10">
										<input type="password" name="password" value="<?php echo $password; ?>" placeholder="Password" class="col-xs-10 col-sm-5" required/>
									</div>
									<div class="col-sm-9 mt10" style="float:right">
										<button type="submit" name="update_username" class="btn btn-sm btn-success" >Update Account
											<i class="ace-icon fa fa-arrow-right icon-on-right bigger-110"></i>
										</button>
									</div>
								</div>
							</form>
							<?php } ?>
							<?php 
								if(isset($_POST['update_username'])){
									
									$updated_username = $_POST['username'];
									$updated_password = md5($_POST['password']);
									$update_username = "update admin_login set username='$updated_username', password='$updated_password'";
									$run_update = mysqli_query($con, $update_username);
									if($run_update){
										
										echo "<script>alert('Account has been Updated')</script>";
										echo "<script>window.open('change_email.php','_self')</script>";
										
										}
									}
							?>
						</div>
						
						
					</div><!-- /.col -->
						</div><!-- /.row -->
					</div><!-- /.page-content -->
				</div>
			</div><!-- /.main-content -->

			
<?php include('footer.php'); ?>
