<?php 

session_start();
include('header.php'); 
include("../includes/db.php");

	if(!(isset ($_SESSION['username'])) && ($_SESSION["password"]=1)){
		echo "<script>window.location.href='login.php'</script>";
	}
 ?>

			<div class="main-content">
				<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="index.php">Home</a>
							</li>
							<li class="active">Edit Slider</li>
						</ul><!-- /.breadcrumb -->
					</div>
					<div class="page-content">
						<div class="page-header">
							<h1>
								Update Slides
							</h1>
						</div><!-- /.page-header -->
					</div>
					<div class="container">
					<div class="panel panel-primary">
					<div class="panel-body">
							<p><br/></p>
							<?php 
							if(isset($_GET['edit_slider'])){
								$id = $_GET['edit_slider'];
								$get_slider = "select * from slider where id='$id'";
								$run_slider = mysqli_query($con, $get_slider); 
								$row_slider=mysqli_fetch_array($run_slider);
								
									$heading = $row_slider['heading'];
									$s_heading = $row_slider['sub_heading'];
									$btn_txt = $row_slider['button_txt'];
									$btn_lnk = $row_slider['button_link'];
									$s_img = $row_slider['image'];
									
							}
							?>
							<form action="" method="post" enctype="multipart/form-data">
								<label class="control-label no-padding-right" for="form-field-1"> 
									Update Slides
								</label>
								<div class="row">
									<div class="col-sm-6 mt-10">
										<input type="text" name="heading" value="<?php echo $heading; ?>" placeholder="Heading" class=""/ required>
									</div>
									<div class="col-sm-6 mt-10">
										<input type="text" name="sub_heading" value="<?php echo $s_heading; ?>" placeholder="Sub Heading" class=""/ required>
									</div>
									<div class="col-sm-6 mt-10">
										<input type="text" name="button_txt" value="<?php echo $btn_txt; ?>" placeholder="Button Text" class=""/ required>
									</div>
									<div class="col-sm-6 mt-10">
										<input type="text" name="button_link" value="<?php echo $btn_lnk; ?>" placeholder="Button Link" class=""/ required>
									</div>
									<div class="col-sm-6 mt-10">
									<img src="../images/<?php echo $s_img; ?>" class="small_img">
										<label>Add Image</label>
										<input type="file" name="slider_images" value="<?php echo $s_img; ?>" class=""/ required>
									</div>
									
									<div class="col-sm-6 mt-10" style="float:right">
										<p><br /></p>
										<button type="submit" name="update_slide" class="btn btn-sm btn-success" >Update Slider
											<i class="ace-icon fa fa-arrow-right icon-on-right bigger-110"></i>
										</button>
									</div>
								</div>
							</form>
							
							<?php 
								if(isset($_POST['update_slide'])){
									$u_id = $id;
									$heading = $_POST['heading'];
									$s_heading = $_POST['sub_heading'];
									$btn_txt = $_POST['button_txt'];
									$btn_lnk = $_POST['button_link'];
									$s_img = $_FILES['slider_images']['name'];
									$temp_name = $_FILES['slider_images']['tmp_name'];
									
										move_uploaded_file($temp_name,"../images/$s_img");
									
										$update_slide = "update slider set heading='$heading',sub_heading='$s_heading',button_txt='$btn_txt',button_link='$btn_lnk',image='$s_img' where id='$u_id'";
											
										$run_slide = mysqli_query($con, $update_slide);
											
										if($run_slide){
											echo "<script>alert('Slide Updated!')</script>";
											echo "<script>window.open('slider.php','_self')</script>";
										}
								}
								
							?>
					</div>
					<div class="panel-footer"></div>
					</div>
					</div>
					</div>
					</div>
				
			
<?php include('footer.php'); ?>
