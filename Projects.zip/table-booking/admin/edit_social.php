<?php 

session_start();
include('header.php'); 
include("../includes/db.php");

	if(!(isset ($_SESSION['username'])) && ($_SESSION["password"]=1)){
		header("location:login.php");
	}
 ?>


			<div class="main-content">
				<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="index.php">Home</a>
							</li>
							<li class="active">Social Media</li>
						</ul><!-- /.breadcrumb -->
					</div>

					<div class="page-content">
						<div class="page-header">
							<h1>
								Update Social Media
							</h1>
						</div><!-- /.page-header -->
							<?php 
								if(isset($_GET['edit_social'])){
								$id = $_GET['edit_social'];
								$get_social = "select * from social_media where social_id='$id'";
								$run_social = mysqli_query($con, $get_social);
								$row=mysqli_fetch_array($run_social); 
									$social_icon = $row['s_icon']; 
									$social_link = $row['s_link'];
								}
							?>
							<form action="" method="post">
								<label class="control-label no-padding-right" for="form-field-1"> 
									Update Social Media:
								</label>
								<div class="form-group">
									<div class="col-sm-9 mt10">
										<select name="social_icon" class="col-sm-5 mt10">
											<option class="fa fa-facebook" name="social_icon" value="<?php echo $social_icon; ?>"><?php echo $social_icon; ?></option>
											<option class="fa fa-facebook" value="fa fa-facebook">Facebook</option>
											<option class="fa fa-twitter" value="fa fa-twitter">Twitter</option>
											<option class="fa fa-google-plus" value="fa fa-google-plus">Google+</option>
											<option class="fa fa-youtube" value="fa fa-youtube">YouTube</option>
											<option class="fa fa-instagram" value="fa fa-instagram">Instagram</option>
											<option class="fa fa-tumblr" value="fa fa-tumblr">Tumblr</option>
										</select>
									</div>
									<div class="col-sm-9 mt10">
										<input type="text" name="social_link" placeholder="Menu Link" value="<?php echo $social_link; ?>" class="col-xs-10 col-sm-5"/>
									</div>
									
									<div class="col-sm-12 mt-10" style="float:right">
										<button type="submit" name="update_social_media" class="btn btn-sm btn-success" >Update Social Media
											<i class="ace-icon fa fa-arrow-right icon-on-right bigger-110"></i>
										</button>
									</div>
								</div>
							</form>
							
							<?php 
								if(isset($_POST['update_social_media'])){
									$u_id = $id;
									$u_social_icon = $_POST['social_icon'];
									$u_social_link = $_POST['social_link'];
									
									if($u_social_icon=='' OR $u_social_link==''){
			
										echo "<script>alert('Please Enter the Social Media Link!')</script>";
										exit();
									
									}else {
										
									$update_menu = "update social_media set s_icon='$u_social_icon', s_link='$u_social_link' where social_id='$u_id'";
										
									$run_menu = mysqli_query($con, $update_menu);
										
									if($run_menu){
										echo "<script>alert('Social Media Updated!')</script>";
										echo "<script>window.open('social_media.php','_self')</script>";
										}
									}
								}
							?>
						
					</div><!-- /.col -->
						</div><!-- /.row -->
					</div><!-- /.page-content -->
				</div>
			</div><!-- /.main-content -->

			
<?php include('footer.php'); ?>
