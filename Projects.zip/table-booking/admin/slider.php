<?php 

session_start();
include('header.php'); 
include("../includes/db.php");

	if(!(isset ($_SESSION['username'])) && ($_SESSION["password"]=1)){
		echo "<script>window.location.href='login.php'</script>";
	}
 ?>

			<div class="main-content">
				<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="index.php">Home</a>
							</li>
							<li class="active">Slider</li>
						</ul><!-- /.breadcrumb -->
					</div>
					<div class="page-content">
						<div class="page-header">
							<h1>
								All Slides
							</h1>
						</div><!-- /.page-header -->
					</div>
					<div class="container">
					<div class="panel panel-primary">
					<div class="panel">
					<?php 
						$get_edit = "select * from slider";
						$run_edit = mysqli_query($con, $get_edit); 
						$i=0;
						while($row_edit = mysqli_fetch_array($run_edit)){ 
							
							$s_id = $row_edit['id'];
							$s_heading = $row_edit['heading'];
							$s_sub_heding = $row_edit['sub_heading'];
							$btn_txt = $row_edit['button_txt'];
							$btn_lnk = $row_edit['button_link'];
							$s_image = $row_edit['image'];
							$i++;
							
					?>	
							<form id="" method="post" enctype="multipart/form-data">
								<div class="row slide">
									<div class="col-sm-1">
										<span><?php echo $i; ?></span>
									</div>
									<div class="col-sm-8">
										<img src="../images/<?php echo $s_image; ?>" class="img-responsive">
									</div>
									<div class="col-sm-3">
										<ul class="slide">
											<li><a href="add_slider.php">Add Slide</a></li>
											<li><a href="edit_slider.php?edit_slider=<?php echo $s_id; ?>">Edit</a></li>
											<li><a href="slider.php?delete_slider=<?php echo $s_id; ?>">Delete</a></li>
										</ul>
									</div>
								</div>
							</form>
						<?php } ?>
						<?php 
							if(isset($_GET['delete_slider'])){
								$d_id = $_GET['delete_slider'];
								$delete_slider = "delete from slider where id='$d_id'";
								$run_slider = mysqli_query($con, $delete_slider);		
									if($run_slider){
										echo "<script>alert('Slider Deleted!')</script>";
										echo "<script>window.open('slider.php','_self')</script>";
									}
							}
						?>	
					</div>
					<div class="panel-footer"></div>
					</div>
					</div>
						
	<?php 
	
		if(isset($_POST['upload_logo'])){
			
				$update_id = $id;
				$updated_first_name = $_POST['first_name']; 
				$updated_last_name = $_POST['last_name']; 
				$updated_phone = $_POST['phone'];
				$updated_password = md5($_POST['password']);
				
			$update_customer = "update user_login set first_name='$updated_first_name', last_name='$updated_last_name', phone='$updated_phone', password='$updated_password' where customer_id='$update_id'";
			
			$run_customer = mysqli_query($con,$update_customer); 
			
			if($run_customer){
				
				echo "<script>alert('Your account has been updated!')</script>";
				echo "<script>window.open('my_account.php','_self')</script>";
				
				}
			}

	?>
						
						
						
					</div>
					</div>
				
			
<?php include('footer.php'); ?>
