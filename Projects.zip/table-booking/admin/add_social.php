<?php 

session_start();
include('header.php'); 
include("../includes/db.php");

	if(!(isset ($_SESSION['username'])) && ($_SESSION["password"]=1)){
		header("location:login.php");
	}
 ?>


			<div class="main-content">
				<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="index.php">Home</a>
							</li>
							<li class="active">Add Social</li>
						</ul><!-- /.breadcrumb -->
					</div>

					<div class="page-content">
						<div class="page-header">
							<h1>
								Add Social Media
							</h1>
						</div><!-- /.page-header -->
							
							<form action="" method="post">
								<label class="control-label no-padding-right" for="form-field-1"> 
									Add New Social Media:
								</label>
								<div class="form-group">
									<div class="col-sm-9 mt10">
										<select name="social_icon" class="col-sm-5 mt10">
											<option class="fa fa-facebook" value="fa fa-facebook">Facebook</option>
											<option class="fa fa-twitter" value="fa fa-twitter">Twitter</option>
											<option class="fa fa-google-plus" value="fa fa-google-plus">Google+</option>
											<option class="fa fa-youtube" value="fa fa-youtube">YouTube</option>
											<option class="fa fa-instagram" value="fa fa-instagram">Instagram</option>
											<option class="fa fa-tumblr" value="fa fa-tumblr">Tumblr</option>
										</select>
									</div>
									<div class="col-sm-9 mt10">
										<input type="text" name="social_link" placeholder="Social Media Link" class="col-xs-10 col-sm-5"/>
									</div>
									
									<div class="col-sm-12 mt-10" style="float:right">
										<button type="submit" name="add_social_media" class="btn btn-sm btn-success" >Add Social Media
											<i class="ace-icon fa fa-arrow-right icon-on-right bigger-110"></i>
										</button>
									</div>
								</div>
							</form>
							
						<?php 
								if(isset($_POST['add_social_media'])){
									$social_icon = $_POST['social_icon'];
									$social_link = $_POST['social_link'];
									
									if($social_icon=='' OR $social_link==''){
			
										echo "<script>alert('Please Enter the Social Media Link!')</script>";
										exit();
									
									}else {
										
									$insert_menu = "insert into social_media (s_icon, s_link) values ('$social_icon', '$social_link')";
										
									$run_menu = mysqli_query($con, $insert_menu);
										
									if($run_menu){
										echo "<script>alert('Social Media Added!')</script>";
										echo "<script>window.open('add_social.php','_self')</script>";
										}
									}
								}
							?>
						
					</div><!-- /.col -->
						</div><!-- /.row -->
					</div><!-- /.page-content -->
				</div>
			</div><!-- /.main-content -->

			
<?php include('footer.php'); ?>
