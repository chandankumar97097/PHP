<?php 

session_start();
include('header.php'); 
include("../includes/db.php");

	if(!(isset ($_SESSION['username'])) && ($_SESSION["password"]=1)){
		echo "<script>window.location.href='login.php'</script>";
	}
 ?>

			<div class="main-content">
				<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="index.php">Home</a>
							</li>
							<li class="active">Logo</li>
						</ul><!-- /.breadcrumb -->
					</div>
					<div class="page-content">
						<div class="page-header">
							<h1>
								Upload Logo
							</h1>
						</div><!-- /.page-header -->
					</div>
					<div class="container">
					<div class="panel panel-primary">
					<div class="panel-body">
							<p><br/></p>
					<?php 
						$get_edit = "select * from logo";
						$run_edit = mysqli_query($con, $get_edit); 
						$row_edit = mysqli_fetch_array($run_edit); 
						$update_id = $row_edit['id'];
						$logo_image = $row_edit['img_name'];
					?>	
							<form id="" method="post" enctype="multipart/form-data">
								<div class="col-sm-4">
									<label for="customer_name">Add New Logo</label>
									<input type="file" name="logo_img" value="<?php echo $logo_image; ?>">
								</div>
								<div class="col-sm-3">
									<img src="assets/images/logo/<?php echo $logo_image; ?>" class="img-responsive logo" title="Add New Logo" id="logo">
									<button name="remove" onclick="(document.getElementById('logo').src = ''); return false;">Remove</button>
								</div>
								<div class="col-sm-12 mt-14">
									<button type="submit" name="upload_logo" class="btn btn-sm btn-success">Upload Logo
										<i class="ace-icon fa fa-arrow-right icon-on-right bigger-110"></i>
									</button>
								</div>
								
							
							</form>
					<?php 
	
						if(isset($_POST['upload_logo'])){
							
							$run_edit = mysqli_query($con, $get_edit); 
							$row_edit = mysqli_fetch_array($run_edit); 
							$u_logo_id = $row_edit['id'];
							$u_img = $_FILES['logo_img']['name'];
							$temp_name = $_FILES['logo_img']['tmp_name'];
							
							if($u_img==''){
								echo "<script>alert('Please Choose Image!')</script>";
								exit();
							}
							else {
							//upload images in folder
							move_uploaded_file($temp_name,"../images/icons/$u_img");
							
							$upload_logo = "update logo set img_name='$u_img' where id='$u_logo_id'";
							
							$run_update = mysqli_query($con, $upload_logo); 
							
							if($run_update){
								
								
								echo "<script>alert('Logo Uploaded Successfully')</script>";
								
								echo "<script>window.open('logo.php','_self')</script>"; 
								}
							
							}
							}


					?>	
						
					</div>
					<div class="panel-footer"></div>
					</div>
					</div>
						
	<?php 
	
		if(isset($_POST['upload_logo'])){
			
				$update_id = $id;
				$updated_first_name = $_POST['first_name']; 
				$updated_last_name = $_POST['last_name']; 
				$updated_phone = $_POST['phone'];
				$updated_password = md5($_POST['password']);
				
			$update_customer = "update user_login set first_name='$updated_first_name', last_name='$updated_last_name', phone='$updated_phone', password='$updated_password' where customer_id='$update_id'";
			
			$run_customer = mysqli_query($con,$update_customer); 
			
			if($run_customer){
				
				echo "<script>alert('Your account has been updated!')</script>";
				echo "<script>window.open('my_account.php','_self')</script>";
				
				}
			}

	?>
						
						
						
					</div>
					</div>
				
			
<?php include('footer.php'); ?>
