<?php 

session_start();
include('header.php'); 
include("../includes/db.php");

	if(!(isset ($_SESSION['username'])) && ($_SESSION["password"]=1)){
		header("location:login.php");
	}
 ?>


			<div class="main-content">
				<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="index.php">Home</a>
							</li>
							<li class="active">Copyright</li>
						</ul><!-- /.breadcrumb -->
					</div>

					<div class="page-content">
						<div class="page-header">
							<h1>
								Add Copyright Text
							</h1>
						</div><!-- /.page-header -->
							<?php 
								$get_copy = "select * from copyright";
								$run_copy = mysqli_query($con, $get_copy);
								$row=mysqli_fetch_array($run_copy);
									$copyright = $row['copyright']; 
									$company = $row['company'];
									$copyright_link = $row['link'];
								
								
							?>
							<form action="" method="post">
								<label class="control-label no-padding-right" for="form-field-1"> 
									Add Copyright:
								</label>
								<div class="form-group">
									<div class="col-sm-9 mt10">
										<input type="text" name="copyright" value="<?php echo $copyright; ?>" placeholder="Copyright" class="col-xs-10 col-sm-5"/>
									</div>
									<div class="col-sm-9 mt10">
										<input type="text" name="company" value="<?php echo $company; ?>" placeholder="Company Name" class="col-xs-10 col-sm-5"/>
									</div>
									<div class="col-sm-9 mt10">
										<input type="text" name="copyright_link" value="<?php echo $copyright_link; ?>" placeholder="Copyright Link" class="col-xs-10 col-sm-5"/>
									</div>
									
									<div class="col-sm-12 mt-10" style="float:right">
										<button type="submit" name="copyright_update" class="btn btn-sm btn-success" >Update
											<i class="ace-icon fa fa-arrow-right icon-on-right bigger-110"></i>
										</button>
									</div>
								</div>
							</form>
							
						<?php 
								if(isset($_POST['copyright_update'])){
									$copyright = $_POST['copyright'];
									$company = $_POST['company'];
									$c_link = $_POST['copyright_link'];
									
									if($copyright=='' OR $company=='' OR $c_link==''){
			
										echo "<script>alert('Please Enter the Copyright & Company Name!')</script>";
										exit();
									
									}else {
										
									$update_copy = "update copyright set copyright='$copyright', company='$company', link='$c_link'";
										
									$run_copy = mysqli_query($con, $update_copy);
										
									if($run_copy){
										echo "<script>alert('Copyright Updated!')</script>";
										echo "<script>window.open('copyright.php','_self')</script>";
										}
									}
								}
							?>
						
					</div><!-- /.col -->
						</div><!-- /.row -->
					</div><!-- /.page-content -->
				</div>
			</div><!-- /.main-content -->

			
<?php include('footer.php'); ?>
