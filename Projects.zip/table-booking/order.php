<?php 

session_start();
include('header.php');
include("includes/db.php");

	if(!(isset ($_SESSION['username'])) && ($_SESSION["username"]=1)){
		echo "<script>window.location.href='index.php'</script>";
	}

?>
	<!-- Title Page -->
	<section class="flex-c-m p-t-160 p-b-80 p-l-15 p-r-15" style="background-image: url(images/bg-title-page-02.jpg);">
		<h2 class="tit6 t-center">
			Table Details
		</h2>
	</section>


	<!-- Reservation -->
	<section class="section-reservation bg1-pattern p-t-80 p-b-80">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 p-b-30">
					<div class="t-center">
						<span class="tit2 t-center">
							Table Details
						</span>

					</div>
					<p><br/></p>
					
					<table border="2" width="100%">
						<tr align="center">
							<th>Order No.</th>
							<th>Name</th>
							<th>Phone</th>
							<th>Email ID</th>
							<th>Number of persons</th>
							<th>Time</th>
							<th>Date</th>
							<th>Table Number</th>
							<th>Booking Status</th>
						</tr>
						<?php 
							
							$email = $_SESSION['username'];
							$get_customer = "select * from user_login where username='$email'";
							$run_customer = mysqli_query($con, $get_customer);
							$row=mysqli_fetch_array($run_customer); 
								$id = $row['customer_id']; 
							
							$get_orders = "select * from reservation where customer_id='$id'";
							$run_orders = mysqli_query($con, $get_orders); 
							$i=0;
							
							while($row_orders=mysqli_fetch_array($run_orders)){
								
								$name = $row_orders['name'];
								$phone = $row_orders['phone'];
								$username = $row_orders['email'];
								$number = $row_orders['number_of_people'];
								$time = $row_orders['time'];
								$date = $row_orders['date'];
								$table = $row_orders['table_number'];
								$status = $row_orders['status'];
								$i++;
								
						?>
							<tr align="center">
								<td><?php echo $i; ?></td>
								<td><?php echo $name; ?></td>
								<td><?php echo $phone; ?></td>
								<td><?php echo $username; ?></td>
								<td><?php echo $number; ?></td>
								<td><?php echo $time; ?></td>
								<td><?php echo $date; ?></td>
								<td><?php echo $table; ?></td>
								<td><?php echo $status; ?></td>
							</tr>
						<?php } ?>
					</table>
						
				</div>
			</div>

		</div>
	</section>



<?php include('footer.php'); ?>
