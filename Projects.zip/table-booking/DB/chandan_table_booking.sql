-- phpMyAdmin SQL Dump
-- version 4.6.6deb5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Feb 14, 2020 at 01:12 PM
-- Server version: 5.7.29-0ubuntu0.18.04.1
-- PHP Version: 7.2.26-1+ubuntu18.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `chandan_table_booking`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE `admin_login` (
  `id` int(10) NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `email` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`id`, `username`, `password`, `email`) VALUES
(1, 'admin', '202cb962ac59075b964b07152d234b70', 'booking@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `contact_form`
--

CREATE TABLE `contact_form` (
  `customer_id` int(10) NOT NULL,
  `name` text NOT NULL,
  `email` text NOT NULL,
  `phone` text NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact_form`
--

INSERT INTO `contact_form` (`customer_id`, `name`, `email`, `phone`, `message`) VALUES
(1, 'ck', 'ck@gmail.com', '9709713232', 'this is an message'),
(2, 'ck', 'ck@gmail.com', '9709713232', 'this is an message'),
(3, 'ck', 'ck@gmail.com', '9709713232', 'this is an message'),
(4, 'ck', 'ck@gmail.com', '9709713232', 'this is an message'),
(5, 'ck', 'ck@gmail.com', '9709713232', 'this is an message'),
(6, 'ck', 'ck@gmail.com', '9709713232', 'this is an message'),
(7, 'ck', 'ck@gmail.com', '9709713232', 'this is an message'),
(8, 'ck', 'ck@gmail.com', '9709713232', 'this is an message'),
(9, 'ck', 'ck@gmail.com', '9709713232', 'this is an message'),
(10, 'ck', 'ck@gmail.com', '9709713232', 'this is an message'),
(11, 'ck', 'ck@gmail.com', '9709713232', 'this is an message'),
(12, 'ck', 'ck@gmail.com', '9709713232', 'this is an message'),
(13, 'ck', 'ck@gmail.com', '9709713232', 'this is an message'),
(14, 'ck', 'ck@gmail.com', '9709713232', 'this is an message'),
(15, 'ck', 'ck@gmail.com', '9709713232', 'this is an message'),
(16, 'ck', 'ck@gmail.com', '9709713232', 'this is an message'),
(17, 'ck', 'ck@gmail.com', '9709713232', 'this is an message'),
(18, 'ck', 'ck@gmail.com', '9709713232', 'this is an message'),
(19, 'ck', 'ck@gmail.com', '9709713232', 'this is an message'),
(20, 'ck', 'ck@gmail.com', '9709713232', 'this is an message'),
(21, 'ck', 'ck@gmail.com', '9709713232', 'this is an message'),
(22, 'ck', 'ck@gmail.com', '9709713232', 'this is an message'),
(23, 'ck', 'ck@gmail.com', '9709713232', 'this is an message'),
(24, 'ck', 'ck@gmail.com', '9709713232', 'this is an message'),
(25, 'ck', 'ck@gmail.com', '9709713232', 'this is an message'),
(26, 'ck', 'ck@gmail.com', '9709713232', 'this is an message'),
(27, 'ck', 'ck@gmail.com', '9709713232', 'this is an message'),
(28, 'ck', 'ck@gmail.com', '9709713232', 'this is an message'),
(29, 'ck', 'ck@gmail.com', '9709713232', 'this is an message'),
(30, 'ck', 'ck@gmail.com', '9709713232', 'this is an message'),
(31, 'Benjamin Donovan', 'gibeve@mailinator.net', '+1 (668) 282-6219', 'Ipsum rerum ratione'),
(32, 'Mukesh', 'mk@gmail.com', '985652313', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.'),
(33, 'chandan', 'reactdevck@gmail.com', '985652313', 'hkk'),
(34, 'Nyssa Bernard', 'disipul@mailinator.com', '+1 (296) 624-5262', 'Mollitia sit impedi');

-- --------------------------------------------------------

--
-- Table structure for table `contact_page`
--

CREATE TABLE `contact_page` (
  `id` int(10) NOT NULL,
  `map` text NOT NULL,
  `address` text NOT NULL,
  `phone` text NOT NULL,
  `time` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact_page`
--

INSERT INTO `contact_page` (`id`, `map`, `address`, `phone`, `time`) VALUES
(1, '																											<iframe src=\"https://www.google.com/maps/embed?pb=!1m12!1m8!1m3!1d117056.95314491034!2d87.2254041910392!3d23.531431084554384!3m2!1i1024!2i768!4f13.1!2m1!1sgoogle+map!5e0!3m2!1sen!2sin!4v1551270549959\" width=\"100%\" height=\"450\" frameborder=\"0\" style=\"border:0\" allowfullscreen></iframe>																								', 'Something, 379 Hudson St, New York, NY 10011', '91 9709713232', 'Mon-Sat: 09:30 to 11:00 PM Sunday (Closed.)');

-- --------------------------------------------------------

--
-- Table structure for table `copyright`
--

CREATE TABLE `copyright` (
  `id` int(10) NOT NULL,
  `copyright` text NOT NULL,
  `link` text NOT NULL,
  `company` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `copyright`
--

INSERT INTO `copyright` (`id`, `copyright`, `link`, `company`) VALUES
(1, 'Copyright ï¿½ 2019 All rights reserved.', 'https://www.google.com', 'Booking.com');

-- --------------------------------------------------------

--
-- Table structure for table `logo`
--

CREATE TABLE `logo` (
  `id` int(10) NOT NULL,
  `img_name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `logo`
--

INSERT INTO `logo` (`id`, `img_name`) VALUES
(1, 'dummy-logo-png-8.png');

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `menu_id` int(10) NOT NULL,
  `menu_name` text NOT NULL,
  `menu_link` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`menu_id`, `menu_name`, `menu_link`) VALUES
(13, 'Reservation', 'reservation.php'),
(15, 'Contact Us', 'contact.php');

-- --------------------------------------------------------

--
-- Table structure for table `reservation`
--

CREATE TABLE `reservation` (
  `order_id` int(10) NOT NULL,
  `name` text NOT NULL,
  `phone` text NOT NULL,
  `email` text NOT NULL,
  `number_of_people` int(3) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `table_number` text NOT NULL,
  `customer_id` int(10) NOT NULL,
  `status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reservation`
--

INSERT INTO `reservation` (`order_id`, `name`, `phone`, `email`, `number_of_people`, `date`, `time`, `table_number`, `customer_id`, `status`) VALUES
(5, 'Chandan Kumar', '9709713232', 'chandankumar97097@gmail.com', 5, '2019-03-16', '05:00:00', '10,12', 7, 'Despatched');

-- --------------------------------------------------------

--
-- Table structure for table `slider`
--

CREATE TABLE `slider` (
  `id` int(10) NOT NULL,
  `heading` text NOT NULL,
  `sub_heading` text NOT NULL,
  `button_txt` text NOT NULL,
  `button_link` text NOT NULL,
  `image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `slider`
--

INSERT INTO `slider` (`id`, `heading`, `sub_heading`, `button_txt`, `button_link`, `image`) VALUES
(13, 'Welcome to', 'Restaurant Booking', 'Book Table', 'reservation.php', 'slide1-01.jpg'),
(14, 'Welcome to', 'Restaurant Booking', 'Book Table', 'reservation.php', 'slide1-02.jpg'),
(15, 'Welcome to', 'Restaurant Booking', 'Book Table', 'reservation.php', 'slide1-03.jpg'),
(16, 'Heading', 'Sub Heading', 'Submit', 'https://google.com', 'slider2.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `social_media`
--

CREATE TABLE `social_media` (
  `social_id` int(10) NOT NULL,
  `s_icon` text NOT NULL,
  `s_link` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `social_media`
--

INSERT INTO `social_media` (`social_id`, `s_icon`, `s_link`) VALUES
(1, 'fa fa-facebook', 'https://www.facebook.com'),
(4, 'fa fa-twitter', 'https://www.twitter.com'),
(7, 'fa fa-google-plus', 'https://plus.google.com/'),
(8, 'fa fa-instagram', 'https://www.instagram.com'),
(11, 'fa fa-youtube', 'https://www.youtube.com/');

-- --------------------------------------------------------

--
-- Table structure for table `user_login`
--

CREATE TABLE `user_login` (
  `customer_id` int(10) NOT NULL,
  `first_name` text NOT NULL,
  `last_name` text NOT NULL,
  `username` text NOT NULL,
  `phone` text NOT NULL,
  `password` text NOT NULL,
  `ip` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_login`
--

INSERT INTO `user_login` (`customer_id`, `first_name`, `last_name`, `username`, `phone`, `password`, `ip`) VALUES
(9, 'Sontosh', 'kumar', 'santosh@gmail.com', '5522332233', '7363a0d0604902af7b70b271a0b96480', '::1'),
(14, 'Amit', 'kumar', 'amit@gmail.com', '8855223366', '202cb962ac59075b964b07152d234b70', '::1'),
(15, 'Chandan', 'Kumar', 'chandankumar97097@gmail.com', '9709713232', '202cb962ac59075b964b07152d234b70', '::1'),
(16, 'Rityunjay', 'Kumar', 'rt@gmail.com', '+1 (485) 745-8555', '202cb962ac59075b964b07152d234b70', '::1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_login`
--
ALTER TABLE `admin_login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_form`
--
ALTER TABLE `contact_form`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `contact_page`
--
ALTER TABLE `contact_page`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `copyright`
--
ALTER TABLE `copyright`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `logo`
--
ALTER TABLE `logo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`menu_id`);

--
-- Indexes for table `reservation`
--
ALTER TABLE `reservation`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `slider`
--
ALTER TABLE `slider`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `social_media`
--
ALTER TABLE `social_media`
  ADD PRIMARY KEY (`social_id`);

--
-- Indexes for table `user_login`
--
ALTER TABLE `user_login`
  ADD PRIMARY KEY (`customer_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_login`
--
ALTER TABLE `admin_login`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `contact_form`
--
ALTER TABLE `contact_form`
  MODIFY `customer_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
--
-- AUTO_INCREMENT for table `contact_page`
--
ALTER TABLE `contact_page`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `copyright`
--
ALTER TABLE `copyright`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `logo`
--
ALTER TABLE `logo`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `menu_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `reservation`
--
ALTER TABLE `reservation`
  MODIFY `order_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `slider`
--
ALTER TABLE `slider`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `social_media`
--
ALTER TABLE `social_media`
  MODIFY `social_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `user_login`
--
ALTER TABLE `user_login`
  MODIFY `customer_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
