<?php 

session_start();
include('header.php');
include("includes/db.php");

if(!(isset ($_SESSION['username'])) && ($_SESSION["password"]=1)){
		echo "<script>window.location.href='index.php'</script>";
	}

?>
	<!-- Title Page -->
	<section class="flex-c-m p-t-160 p-b-80 p-l-15 p-r-15" style="background-image: url(images/bg-title-page-02.jpg);">
		<h2 class="tit6 t-center">
			Update Order
		</h2>
	</section>


	<!-- Reservation -->
	<section class="section-reservation bg1-pattern p-t-60 p-b-60">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 p-b-30">
					<div class="t-center">
						<span class="tit2 t-center">
							Reservation
						</span>

						<h3 class="tit3 t-center m-b-35 m-t-2">
							Book table
						</h3>
					</div>
					<?php 
						if(isset($_GET['edit_order'])){
				
							$customer_email = $_SESSION['username'];
							
							$get_customer = "select * from reservation where email='$customer_email'";
							
							$run_customer = mysqli_query($con, $get_customer);
							
							$row=mysqli_fetch_array($run_customer); 
							
							$order_id = $row['order_id'];
							$order_date = $row['date']; 
							$order_time = $row['time']; 
							$order_person = $row['number_of_people']; 
							$order_name = $row['name']; 
							$order_phone = $row['phone']; 
							$order_email = $row['email']; 
						}
					?>
					<form action="" method="POST">
						<div class="row">
							<div class="col-md-4">
								<!-- Date -->
								<span class="txt9">
									Date
								</span>

								<div class="txt10 size12 bo2 bo-rad-10 m-t-3 m-b-23">
									<input class="txt10 p-l-20" type="date" name="date" value="<?php echo $order_name; ?>">
								</div>
							</div>

							<div class="col-md-4">
								<!-- Time -->
								<span class="txt9">
									Time
								</span>

								<div class="wrap-inputtime size12 bo2 bo-rad-10 m-t-3 m-b-23">
									<!-- Select2 -->
									<input class="txt10 p-l-20" type="time" name="time" value="<?php echo $order_name; ?>">
								</div>
							</div>

							<div class="col-md-4">
								<!-- People -->
								<span class="txt9">
									People
								</span>

								<div class="wrap-inputpeople size12 bo2 bo-rad-10 m-t-3 m-b-23">
									<!-- Select2 -->
									<select class="selection-1" name="people" value="<?php echo $order_name; ?>">
										<option>1 person</option>
										<option>2 people</option>
										<option>3 people</option>
										<option>4 people</option>
										<option>5 people</option>
										<option>6 people</option>
										<option>7 people</option>
										<option>8 people</option>
										<option>9 people</option>
										<option>10 people</option>
										<option>11 people</option>
										<option>12 people</option>
										<option>13 people</option>
										<option>14 people</option>
										<option>15 people</option>
										<option>16 people</option>
									</select>
								</div>
							</div>
						</div>

						<div class="row">
							<div class="col-md-4">
								<!-- Name -->
								<span class="txt9">
									Name
								</span>

								<div class="wrap-inputname size12 bo2 bo-rad-10 m-t-3 m-b-23">
									<input class="bo-rad-10 sizefull txt10 p-l-20" type="text" name="name" placeholder="Name" value="<?php echo $order_name; ?>" disabled>
								</div>
							</div>

							<div class="col-md-4">
								<!-- Phone -->
								<span class="txt9">
									Phone
								</span>

								<div class="wrap-inputphone size12 bo2 bo-rad-10 m-t-3 m-b-23">
									<input class="bo-rad-10 sizefull txt10 p-l-20" type="text" name="phone" placeholder="Phone" value="<?php echo $order_name; ?>" disabled>
								</div>
							</div>

							<div class="col-md-4">
								<!-- Email -->
								<span class="txt9">
									Email
								</span>

								<div class="wrap-inputemail size12 bo2 bo-rad-10 m-t-3 m-b-23">
									<input class="bo-rad-10 sizefull txt10 p-l-20" type="text" name="email" placeholder="Email" value="<?php echo $order_name; ?>" disabled>
								</div>
							</div>

						</div>
						<div class="wrap-btn-booking flex-c-m m-t-6">
							<!-- Button3 -->
							<input type="submit" class="btn3 flex-c-m size13 txt11 trans-0-4" name="update_order" value="Update Table">
						</div>
					</form>
					
					<?php 
						if(isset($_POST['update_order'])){
							$update_id = $id;
							$c_name = $_POST['name'];
							$c_phone = $_POST['date'];
							$c_date = $_POST['date'];
							$c_time = $_POST['time'];
							
								
							$update_customer = "update reservation set name='$c_name', phone='$c_phone', date='$c_date', time='$c_time' where customer_id='$update_id'";
							
							$run_customer = mysqli_query($con,$update_customer); 
							
							if($run_customer){
								
								echo "<script>alert('Your Order has been updated!')</script>";
								echo "<script>window.open('order.php','_self')</script>";
								
								}
							}

					?>
	
				</div>
			</div>

		</div>
	</section>



<?php include('footer.php'); ?>