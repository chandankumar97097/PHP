<?php 
// Global Connection
$db = mysqli_connect("localhost","root","","booking");

	// function for getting the IP address
	function getRealIpAddr(){
		
		@$http_client_ip = $_SERVER['HTTP_CLIENT_IP'];
		@$http_forwarded_for = $_SERVER['HTTP_X_FORWARDED_FOR'];
		$remote_addr = $_SERVER['REMOTE_ADDR'];
		
		// check ip from internet
		if (!empty($http_client_ip)){
			$ipaddress = $http_client_ip;
		}
		// check ip is pass from proxy and VPN
		elseif (!empty($http_forwarded_for)){
			$ipaddress = $http_forwarded_for;
		}
		// Local Machine ip address
		else{
			$ipaddress = $remote_addr;
		}
		return $ipaddress;
	}
	

	// Customer Contact Form
	if(isset($_POST['contact_us'])){
					
		$customer_name =  mysqli_real_escape_string($con, $_POST['name']);
		$customer_email =  mysqli_real_escape_string($con, $_POST['email']);
		$customer_phone =  mysqli_real_escape_string($con, $_POST['phone']);
		$customer_message = mysqli_real_escape_string($con, $_POST['message']);
					
			if($customer_name=='' OR $customer_email=='' OR $customer_phone=='' OR $customer_message==''){
				echo "<script>alert('Please fill all the fields!')</script>";
			}else{
				$insert_contact_form = "insert into contact_form (name,email,phone,message) values ('$customer_name','$customer_email','$customer_phone','$customer_message')";
					
				$run_customer = mysqli_query($db, $insert_contact_form);
					
				echo "<script>alert('Message send successfully! We will contact you soon.');</script>";
				echo "<script>window.open('index.php', '_self')</script>";
						
			}
	}

	
	
?>