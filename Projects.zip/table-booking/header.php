<?php 


@session_start();
include("includes/db.php");
	
	
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Restaurent Table Booking</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->
	<link rel="icon" type="image/png" href="images/icons/favicon.png"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/themify/themify-icons.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/slick/slick.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/lightbox2/css/lightbox.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>
<body class="animsition">

	<!-- Header -->
	<header>
		<!-- Header desktop -->
		<div class="wrap-menu-header gradient1 trans-0-4">
			<div class="container h-full">
				<div class="wrap_header trans-0-3">
					<!-- Logo -->
					<div class="logo">
					<?php 
						$get_edit = "select * from logo";
						$run_edit = mysqli_query($con, $get_edit); 
						$row_edit = mysqli_fetch_array($run_edit); 
						$logo_image = $row_edit['img_name'];
					?>	
						<a href="index.php">
							<img src="images/icons/<?php echo $logo_image; ?>" alt="IMG-LOGO">
						</a>
					</div>

					<!-- Menu -->
					<div class="wrap_menu p-l-45 p-l-0-xl">
						<nav class="menu">
							<ul class="main_menu">
							
								<?php 
									$get_menus = "select * from menu";
									$run_menus = mysqli_query($con, $get_menus); 
									
									while($row_menus=mysqli_fetch_array($run_menus)){
										
										$menu_name = $row_menus['menu_name'];
										$menu_link = $row_menus['menu_link'];
								?>
									<li>
										<a href="<?php echo $menu_link ?>" style="text-transform: Uppercase"><?php echo $menu_name ?></a>
									</li>
								<?php } ?>
								
							</ul>
						</nav>
					</div>

					<!-- Social -->
					<div class="social flex-w flex-l-m p-r-20">
						<?php 
							$get_social = "select * from social_media";
							$run_social = mysqli_query($con, $get_social); 
								while($row_social=mysqli_fetch_array($run_social)){
									$social_icon = $row_social['s_icon'];
									$social_link = $row_social['s_link'];
										
						?>
							<a href="<?php echo $social_link; ?>" target="_blank"><i class="<?php echo $social_icon; ?> m-l-21" aria-hidden="true"></i></a>
						<?php } ?>
						<button class="btn-show-sidebar m-l-33 trans-0-4"></button>
					</div>
				</div>
			</div>
		</div>
	</header>

	<!-- Sidebar -->
	<aside class="sidebar trans-0-4">
		<!-- Button Hide sidebar -->
		<button class="btn-hide-sidebar ti-close color0-hov trans-0-4"></button>

		<!-- - -->
		<ul class="menu-sidebar p-t-95 p-b-70">
			<?php 
				$get_menus = "select * from menu";
				$run_menus = mysqli_query($con, $get_menus); 
									
					while($row_menus=mysqli_fetch_array($run_menus)){
										
						$menu_name = $row_menus['menu_name'];
						$menu_link = $row_menus['menu_link'];
										
			?>
				<li class="t-center m-b-13">
					<a href="<?php echo $menu_link ?>" style="text-transform: Uppercase"><?php echo $menu_name ?></a>
				</li>
			<?php } ?>
			
			<?php 
				if((isset ($_SESSION['username'])) && ($_SESSION["password"]=1)){
					echo "
						<li class='logout_btn'>
							<a href='logout.php' class='txt19'>Logout</a>
						</li>
					";
				}else{
					echo "
						<li class='login_btn'>
							<a href='login.php' class='txt19'>Login</a>
						</li>
					";
				}
			?>
			<?php 
				if(!(isset ($_SESSION['username'])) && ($_SESSION["password"]=1)){
					echo "
						<li class='login_btn'>
							<a href='register.php' class='txt19'>Register</a>
						</li>
					";
				}
			?>
			<?php 
				if((isset ($_SESSION['username'])) && ($_SESSION["password"]=1)){
					echo "
						<li class='login_btn'>
							<a href='my_account.php' class='txt19'>My Account</a>
						</li>
					";
				}
			?>
			
		</ul>

		<!-- - -->
	
	</aside>
