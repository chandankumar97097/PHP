<?php 

session_start();
include('header.php');
include('functions/functions.php');

?>
	<!-- Title Page -->
	<section class="flex-c-m p-t-160 p-b-80 p-l-15 p-r-15" style="background-image: url(images/bg-title-page-02.jpg);">
		<h2 class="tit6 t-center">
			Register
		</h2>
	</section>


	<!-- Reservation -->
	<section class="section-reservation bg1-pattern p-t-60 p-b-60">
		<div class="container">
			<div class="row">
				<div class="col-lg-8 col-lg-offset-2 p-b-30">
					<div class="t-center">
						<span class="tit2 t-center">
							Register
						</span>
					</div>
					<form action="" method="POST" class="">
						<div class="row">
							<div class="col-md-6">
								<!-- Phone -->
								<span class="txt9">
									First Name
								</span>
								<div class="wrap-inputphone size12 bo2 bo-rad-10 m-t-3 m-b-23">
									<input class="bo-rad-10 sizefull txt10 p-l-20" type="text" name="first_name" placeholder="Enter First Name" required>
								</div>
							</div>

							<div class="col-md-6">
								<!-- Email -->
								<span class="txt9">
									Last Name
								</span>
								<div class="wrap-inputemail size12 bo2 bo-rad-10 m-t-3 m-b-23">
									<input class="bo-rad-10 sizefull txt10 p-l-20" type="text" name="last_name" placeholder="Enter Last Name" required>
								</div>
							</div>
							<div class="col-md-6">
								<!-- Phone -->
								<span class="txt9">
									Phone
								</span>
								<div class="wrap-inputphone size12 bo2 bo-rad-10 m-t-3 m-b-23">
									<input class="bo-rad-10 sizefull txt10 p-l-20" type="text" name="phone" placeholder="Enter Phone" required>
								</div>
							</div>
							<div class="col-md-6">
								<!-- Email -->
								<span class="txt9">
									Email
								</span>
								<div class="wrap-inputemail size12 bo2 bo-rad-10 m-t-3 m-b-23">
									<input class="bo-rad-10 sizefull txt10 p-l-20" type="email" name="email" placeholder="Enter Email" required>
								</div>
							</div>
							<div class="col-md-6">
								<!-- Phone -->
								<span class="txt9">
									Password
								</span>
								<div class="wrap-inputphone size12 bo2 bo-rad-10 m-t-3 m-b-23">
									<input class="bo-rad-10 sizefull txt10 p-l-20" type="password" name="password" placeholder="Enter Password" required>
								</div>
							</div>
							<div class="col-md-6">
								<!-- Phone -->
								<span class="txt9">
									Confirm Password
								</span>
								<div class="wrap-inputphone size12 bo2 bo-rad-10 m-t-3 m-b-23">
									<input class="bo-rad-10 sizefull txt10 p-l-20" type="password" name="confirm_password" placeholder="Enter Confirm Password" required>
								</div>
							</div>
						</div>

						<div class="wrap-btn-booking flex-c-m m-t-6">
							<!-- Button3 -->
							<input type="submit" class="btn3 flex-c-m size13 txt11 trans-0-4" name="register" style="float:right;" value="Register" />
							<p>&nbsp </p>
							<a href="login.php" class="btn3 flex-c-m size13 txt11 trans-0-4">Login</a>
						</div>
					</form>
				</div>

			</div>

		</div>
	</section>

<?php 

	// Customer Registration
	if(isset($_POST['register'])){
		
		$c_ip = getRealIpAddr();
		$first_name = $_POST['first_name'];
		$last_name = $_POST['last_name'];
		$phone = $_POST['phone'];
		$email = $_POST['email'];
		$password = md5($_POST['password']);
		$confirm_password = md5($_POST['confirm_password']);
		
		$sel_customers = "select * from user_login where customer_id='$id' && username='$email'";
		$run_customers = mysqli_query($con, $sel_customers);
		$check_customers = mysqli_num_rows($run_customers);
		
		if($check_customers==1){
			echo "<script>alert('You Are Already Registered! Please Login')</script>";
			echo "<script>window.open('login.php', '_self')</script>";
		}else{
			if($password == $confirm_password){
			$insert_customer = "insert into user_login (first_name,last_name,phone,username,password,ip) values ('$first_name','$last_name','$phone','$email','$password','$c_ip')";
		
			$run_customer = mysqli_query($con, $insert_customer);
	
			echo "<script>alert('You Are Successfully Registered!');</script>";
			echo "<script>window.open('login.php', '_self')</script>";
			
		}else{
			echo "<script>alert('Password and Confirm Password not Match');</script>";
		}
		}
	}

?>

<?php include('footer.php'); ?>