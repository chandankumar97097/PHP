<?php 

session_start();
include('header.php');
include("includes/db.php");
	
	
	if((isset ($_SESSION['username'])) && ($_SESSION["password"]=1)){
		echo "<script>window.location.href='index.php'</script>";
	}
	
	// Login Script
	$msg = '';
	if (isset($_POST['login'])){
	// Assigning posted values to variables.
	$username = $_POST['username'];
	$password = md5($_POST['password']);
	// Checking the values are existing in the database or not
	$query = "SELECT * FROM user_login WHERE username='$username' and password='$password'";
	 
	$result = mysqli_query($con, $query);
	
	$count = mysqli_num_rows($result);
	
	// If the posted values are equal to the database values, then session will be created for the user.
	if ($count == 1){
	$_SESSION['username'] = $username;
		echo "<script>alert('You are successfully logged in please reserve your tables');</script>";
		echo "<script>window.location.href='reservation.php'</script>";
	}else{
	// If the login credentials doesn't match, he will be shown with an error message.
	$msg = "Invalid Login Credentials.";
	}
	}
	

?>
	<!-- Title Page -->
	<section class="flex-c-m p-t-160 p-b-80 p-l-15 p-r-15" style="background-image: url(images/bg-title-page-02.jpg);">
		<h2 class="tit6 t-center">
			Login
		</h2>
	</section>


	<!-- Reservation -->
	<section class="section-reservation bg1-pattern p-t-60 p-b-60">
		<div class="container">
			<div class="row">
				<div class="col-lg-6 col-lg-offset-3 p-b-30">
					<div class="t-center">
						<span class="tit2 t-center">
							Login
						</span>
					</div>
					<p class="txt-center c-red"><?php echo "$msg"; ?></p>
					<form action="" method="POST">
						<div class="row">
							<div class="col-md-12">
								<!-- Phone -->
								<span class="txt9">
									Username or Email
								</span>

								<div class="wrap-inputphone size12 bo2 bo-rad-10 m-t-3 m-b-23">
									<input class="bo-rad-10 sizefull txt10 p-l-20" type="text" name="username" placeholder="Enter Username" value="">
								</div>
							</div>

							<div class="col-md-12">
								<!-- Email -->
								<span class="txt9">
									Password
								</span>

								<div class="wrap-inputemail size12 bo2 bo-rad-10 m-t-3 m-b-23">
									<input class="bo-rad-10 sizefull txt10 p-l-20" type="text" name="password" placeholder="Enter Password" value="">
								</div>
							</div>

						</div>

						<div class="wrap-btn-booking flex-c-m m-t-6">
							<!-- Button3 -->
							<input type="submit" class="btn3 flex-c-m size13 txt11 trans-0-4" name="login" style="float:right;" value="Login" />
							<p>&nbsp </p>
							<a href="register.php" class="btn3 flex-c-m size13 txt11 trans-0-4">Register</a>
						</div>
					</form>
				</div>

			</div>

		</div>
	</section>


<?php include('footer.php'); ?>