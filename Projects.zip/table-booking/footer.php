

	<!-- Footer -->
	<footer class="bg1">
		<div class="end-footer bg2">
			<div class="container">
				<div class="flex-sb-m flex-w p-t-6 p-b-6">
					<div class="p-t-5 p-b-5">
						<?php 
							$get_social = "select * from social_media";
							$run_social = mysqli_query($con, $get_social); 
								while($row_social=mysqli_fetch_array($run_social)){
									$social_icon = $row_social['s_icon'];
									$social_link = $row_social['s_link'];
										
						?>
							<a href="<?php echo $social_link; ?>" class="fs-15 c-white" target="_blank"><i class="<?php echo $social_icon; ?> m-l-18" aria-hidden="true"></i></a>
						<?php } ?>
					</div>

					<div class="txt17 p-r-20 p-t-5 p-b-5">
						<?php 
							$get_copy = "select * from copyright";
							$run_copy = mysqli_query($con, $get_copy); 
								$row_copy=mysqli_fetch_array($run_copy);
									$copy = $row_copy['copyright'];
									$company = $row_copy['company'];
									$copy_link = $row_copy['link'];
										
						?>
						<?php echo $copy; ?> <a href="<?php echo $copy_link; ?>" target="_blank"><?php echo $company; ?></a>
						
					</div>
				</div>
			</div>
		</div>
	</footer>


	<!-- Back to top -->
	<div class="btn-back-to-top bg0-hov" id="myBtn">
		<span class="symbol-btn-back-to-top">
			<i class="fa fa-angle-double-up" aria-hidden="true"></i>
		</span>
	</div>

	<!-- Container Selection1 -->
	<div id="dropDownSelect1"></div>



<!--===============================================================================================-->
	<script type="text/javascript" src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script type="text/javascript" src="vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script type="text/javascript" src="vendor/bootstrap/js/popper.js"></script>
	<script type="text/javascript" src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script type="text/javascript" src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script type="text/javascript" src="vendor/daterangepicker/moment.min.js"></script>
	<script type="text/javascript" src="vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script type="text/javascript" src="vendor/slick/slick.min.js"></script>
	<script type="text/javascript" src="js/slick-custom.js"></script>
<!--===============================================================================================-->
	<script type="text/javascript" src="vendor/parallax100/parallax100.js"></script>
	<script type="text/javascript">
        $('.parallax100').parallax100();
	</script>
<!--===============================================================================================-->
	<script type="text/javascript" src="vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script type="text/javascript" src="vendor/lightbox2/js/lightbox.min.js"></script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>

</body>
</html>
